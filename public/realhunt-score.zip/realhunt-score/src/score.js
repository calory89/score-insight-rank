// RealHunt Score — shared scoring engine (runs in content scripts and the side panel).
// Transparent 0–100 score from the listing the user is viewing. Every point comes with a reason.
// It is an estimate, not an appraisal. Sponsorship never changes a score.
(function (g) {
  const RHS = (g.RHS = g.RHS || {});
  const SQFT = 0.09290304;

  RHS.money = (n, cur) => {
    if (n == null || !isFinite(n)) return "—";
    const sym = { EUR: "€", GBP: "£", USD: "$" }[cur] || "";
    return sym + Math.round(n).toLocaleString("en-GB");
  };
  RHS.num = (s) => {
    if (s == null) return null;
    if (typeof s === "number") return isFinite(s) ? s : null;
    const t = String(s).replace(/ /g, " ");
    const m = t.match(/\d[\d.,\s]*\d|\d/);
    if (!m) return null;
    let x = m[0].replace(/\s/g, "");
    // 1.250.000 / 1,250,000 / 1.250,50 / 85,5
    if (/^\d{1,3}([.,]\d{3})+$/.test(x)) x = x.replace(/[.,]/g, "");
    else if (/,\d{1,2}$/.test(x)) x = x.replace(/\./g, "").replace(",", ".");
    else x = x.replace(/,/g, "");
    const v = parseFloat(x);
    return isFinite(v) ? v : null;
  };
  RHS.sqm = (s) => {
    if (s == null) return null;
    if (typeof s === "number") return s;
    const t = String(s);
    const ft = t.match(/(\d[\d.,]*)\s*(sq\.?\s*ft|sqft|ft²|ft2)/i);
    if (ft) return Math.round(RHS.num(ft[1]) * SQFT);
    const m = t.match(/(\d[\d.,]*)\s*(m²|m2|mq|sqm|sq\.?\s*m)/i);
    return m ? RHS.num(m[1]) : null;
  };

  // Words that point to a problem. Kept short and literal so the reason shown is always the matched word.
  const FLAGS = [
    { k: "occupied", pts: 15, re: /\b(okupa|ocupad[ao]|sin posesi[oó]n|occupied|sitting tenant|tenant in situ|occupato|ocupado)\b/i, label: "Occupied or no possession" },
    { k: "auction", pts: 12, re: /\b(subasta|auction|asta giudiziaria|leilão|leilao)\b/i, label: "Auction sale" },
    { k: "bare", pts: 12, re: /\b(nuda propiedad|nuda propriet[aà]|usufructo|bare ownership)\b/i, label: "Bare ownership / usufruct" },
    { k: "legal", pts: 12, re: /(sin c[eé]dula|sin legalizar|fuera de ordenaci[oó]n|proindiviso|no habitab|abuso edilizio|non a norma|short lease|cladding|ews1)/i, label: "Possible legal or paperwork issue" },
    { k: "renovation", pts: 8, re: /\b(a reformar|para reformar|necesita reforma|needs? (some )?(work|renovation|updating|modernisation|modernization)|fixer|doer[- ]upper|renovation project|da ristrutturare|para recuperar|tlc)\b/i, label: "Needs renovation" },
    { k: "investors", pts: 6, re: /(ideal inversores|solo inversores|investors? only|cash (buyers )?only|ideale per investitori|rentabilidad garantizada)/i, label: "Pitched at investors / cash only" },
    { k: "rented", pts: 6, re: /\b(alquilad[oa] con|con inquilino|actualmente alquilad|tenanted|sold with tenant|affittato|arrendad[oa])\b/i, label: "Sold with a tenant" },
    { k: "rustic", pts: 5, re: /\b(r[uú]stic[oa] no|suelo r[uú]stico|non urbanizable|agricultural land only)\b/i, label: "Rural land status" },
    { k: "vague", pts: 4, re: /(incre[ií]ble oportunidad|no te lo pierdas|must see|won'?t last|chollo|bargain of the year|opportunit[aà] unica)/i, label: "Hype wording, few facts" },
  ];
  const INFO = [
    { k: "floor", re: /(planta|floor|piano|andar|etage|sal)\s*\d|bajo|ground floor|piano terra|r[eé]s[- ]do[- ]ch[aã]o/i, label: "floor" },
    { k: "energy", re: /(certificado energ|energy (rating|certificate|performance)|epc|classe energetica|certificado energético|energim[aæ]rk|clase energ)/i, label: "energy rating" },
    { k: "orientation", re: /(orientaci[oó]n|south[- ]facing|north[- ]facing|esposizione|orienta[cç][aã]o|exterior|interior)/i, label: "orientation" },
    { k: "fees", re: /(comunidad|community fees|service charge|hoa|spese condominiali|condom[ií]nio|ground rent|ejerudgift|f[aæ]llesudgift)/i, label: "community fees" },
    { k: "year", re: /(construid[oa] en|built in|year built|anno di costruzione|\b(18|19|20)\d{2}\b)/i, label: "year built" },
  ];

  RHS.flagsFrom = (text) => {
    const t = String(text || "");
    return FLAGS.filter((f) => f.re.test(t)).map((f) => ({ k: f.k, pts: f.pts, label: f.label, word: (t.match(f.re) || [""])[0] }));
  };

  // features: {price, currency, sqm, rooms, ptype, area, country, desc, photos, days, portal}
  // ctx: {bench: €/m² benchmark, benchN, benchSource: 'area'|'page', profile}
  RHS.score = (f, ctx = {}) => {
    const parts = [];
    const ppsqm = f.price && f.sqm ? f.price / f.sqm : null;
    // 1) Price vs area — 40
    let p1 = 20, why1 = "Not enough comparable listings yet, so price counts as neutral.";
    if (ppsqm && ctx.bench) {
      const r = ppsqm / ctx.bench;
      p1 = Math.max(0, Math.min(40, Math.round(40 * (1.35 - r) / 0.7)));
      const pct = Math.round((r - 1) * 100);
      const src = ctx.benchSource === "area" ? `${ctx.benchN} listings in ${f.area || "this area"} seen by RealHunt users` : `the ${ctx.benchN} listings on this search page`;
      why1 = `${RHS.money(ppsqm, f.currency)}/m² is ${Math.abs(pct)}% ${pct <= 0 ? "below" : "above"} the median of ${src} (${RHS.money(ctx.bench, f.currency)}/m²).`;
    } else if (!ppsqm) {
      p1 = 15; why1 = "No size published, so price per m² can't be checked.";
    }
    parts.push({ k: "price", label: "Price vs area", pts: p1, max: 40, why: why1 });

    // 2) Listing quality — 20
    let p2 = 0; const miss = [];
    const ph = f.photos || 0;
    p2 += ph >= 20 ? 8 : ph >= 10 ? 5 : ph >= 5 ? 3 : 1;
    const dl = (f.desc || "").length;
    p2 += dl >= 600 ? 4 : dl >= 250 ? 2 : 0;
    let info = 0;
    for (const i of INFO) { if (i.re.test(f.desc || "") || (f.extra && f.extra[i.k])) info++; else miss.push(i.label); }
    p2 += Math.round((info / INFO.length) * 8);
    parts.push({ k: "quality", label: "Listing quality", pts: Math.min(20, p2), max: 20,
      why: `${ph || "No"} photos, ${dl > 0 ? dl + " characters of description" : "no description"}${miss.length ? `. Missing: ${miss.join(", ")}.` : ". Key facts are all there."}` });

    // 3) Red flags — 30
    const flags = RHS.flagsFrom(f.desc + " " + (f.title || ""));
    let p3 = 30 - flags.reduce((a, x) => a + x.pts, 0);
    if (f.days != null && f.days > 180) { flags.push({ k: "stale", pts: 5, label: `Listed ${f.days} days ago`, word: "" }); p3 -= 5; }
    p3 = Math.max(0, p3);
    parts.push({ k: "flags", label: "Red flags", pts: p3, max: 30,
      why: flags.length ? flags.map((x) => x.label + (x.word ? ` (“${x.word.trim()}”)` : "")).join("; ") + "." : "No red-flag wording found in the listing." });

    // 4) Fit with your profile — 10 (neutral 5 without a profile)
    let p4 = 5, why4 = "Answer 5 quick questions to score how well it fits you.";
    const pr = ctx.profile;
    if (pr && (pr.budget || (pr.places && pr.places.length) || pr.ptype)) {
      p4 = 0; const w = [];
      if (pr.budget && f.price) { if (f.price <= pr.budget) { p4 += 5; w.push("within your budget"); } else w.push(`${Math.round((f.price / pr.budget - 1) * 100)}% over your budget`); }
      const hay = `${f.area || ""} ${f.country || ""}`.toLowerCase();
      if (pr.places && pr.places.length) { if (pr.places.some((x) => hay.includes(String(x).toLowerCase()))) { p4 += 3; w.push("in a place you want"); } else w.push("outside your places"); }
      if (pr.ptype && f.ptype) { if (String(f.ptype).toLowerCase().includes(pr.ptype === "house" ? "house" : pr.ptype === "flat" ? "flat" : pr.ptype)) { p4 += 2; w.push("your type of home"); } }
      p4 = Math.min(10, p4); why4 = w.length ? w.join(", ") + "." : "Not enough data to compare with your profile.";
    }
    parts.push({ k: "fit", label: "Fit with you", pts: p4, max: 10, why: why4 });

    const score = Math.max(0, Math.min(100, parts.reduce((a, x) => a + x.pts, 0)));
    return { score, parts, flags, ppsqm };
  };
  RHS.tone = (s) => (s >= 75 ? "great" : s >= 60 ? "good" : s >= 45 ? "ok" : "low");
  RHS.color = (s) => ({ great: "#0F6B34", good: "#2E9E5B", ok: "#D39B12", low: "#C2412D" }[RHS.tone(s)]);
  RHS.median = (a) => { const b = a.filter((x) => x > 0).sort((x, y) => x - y); if (!b.length) return null; const m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };
  RHS.hash = async (s) => {
    const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
    return [...new Uint8Array(d)].slice(0, 16).map((x) => x.toString(16).padStart(2, "0")).join("");
  };
})(typeof window !== "undefined" ? window : self);
