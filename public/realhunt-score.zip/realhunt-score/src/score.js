// RealHunt Score — shared scoring engine (runs in content scripts and the side panel).
// Transparent 0–100 score from the listing the user is viewing. Every point comes with a reason.
// It is an estimate, not an appraisal. Sponsorship never changes a score.
(function (g) {
  const RHS = (g.RHS = g.RHS || {});
  const SQFT = 0.09290304;

  RHS.money = (n, cur) => {
    if (n == null || !isFinite(n)) return "—";
    const sym = { EUR: "€", GBP: "£", USD: "$" }[cur] || "";
    if (RHS.lang === "es" && cur === "EUR") return Math.round(n).toLocaleString("es-ES") + " €";
    return sym + Math.round(n).toLocaleString("en-GB");
  };
  RHS.num = (s) => {
    if (s == null) return null;
    if (typeof s === "number") return isFinite(s) ? s : null;
    const t = String(s).replace(/ /g, " ");
    const m = t.match(/\d[\d.,\s]*\d|\d/);
    if (!m) return null;
    let x = m[0].replace(/\s/g, "");
    // 1.250.000 / 1,250,000 / 1.250,50 / 85,5
    if (/^\d{1,3}([.,]\d{3})+$/.test(x)) x = x.replace(/[.,]/g, "");
    else if (/,\d{1,2}$/.test(x)) x = x.replace(/\./g, "").replace(",", ".");
    else x = x.replace(/,/g, "");
    const v = parseFloat(x);
    return isFinite(v) ? v : null;
  };
  RHS.sqm = (s) => {
    if (s == null) return null;
    if (typeof s === "number") return s;
    const t = String(s);
    const ft = t.match(/(\d[\d.,]*)\s*(sq\.?\s*ft|sqft|ft²|ft2)/i);
    if (ft) return Math.round(RHS.num(ft[1]) * SQFT);
    const m = t.match(/(\d[\d.,]*)\s*(m²|m2|mq|sqm|sq\.?\s*m)/i);
    return m ? RHS.num(m[1]) : null;
  };

  // Words that point to a problem. Kept short and literal so the reason shown is always the matched word.
  const FLAGS = [
    { k: "occupied", pts: 15, re: /\b(okupa|ocupad[ao]|sin posesi[oó]n|occupied|sitting tenant|tenant in situ|occupato|ocupado)\b/i, label: "Occupied or no possession" },
    { k: "auction", pts: 12, re: /\b(subasta|auction|asta giudiziaria|leilão|leilao)\b/i, label: "Auction sale" },
    { k: "bare", pts: 12, re: /\b(nuda propiedad|nuda propriet[aà]|usufructo|bare ownership)\b/i, label: "Bare ownership / usufruct" },
    { k: "legal", pts: 12, re: /(sin c[eé]dula|sin legalizar|fuera de ordenaci[oó]n|proindiviso|no habitab|abuso edilizio|non a norma|short lease|cladding|ews1)/i, label: "Possible legal or paperwork issue" },
    { k: "renovation", pts: 8, re: /\b(a reformar|para reformar|necesita reforma|needs? (some )?(work|renovation|updating|modernisation|modernization)|fixer|doer[- ]upper|renovation project|da ristrutturare|para recuperar|tlc)\b/i, label: "Needs renovation" },
    { k: "investors", pts: 6, re: /(ideal inversores|solo inversores|investors? only|cash (buyers )?only|ideale per investitori|rentabilidad garantizada)/i, label: "Pitched at investors / cash only" },
    { k: "rented", pts: 6, re: /\b(alquilad[oa] con|con inquilino|actualmente alquilad|tenanted|sold with tenant|affittato|arrendad[oa])\b/i, label: "Sold with a tenant" },
    { k: "rustic", pts: 5, re: /\b(r[uú]stic[oa] no|suelo r[uú]stico|non urbanizable|agricultural land only)\b/i, label: "Rural land status" },
    { k: "vague", pts: 4, re: /(incre[ií]ble oportunidad|no te lo pierdas|must see|won'?t last|chollo|bargain of the year|opportunit[aà] unica)/i, label: "Hype wording, few facts" },
  ];
  const INFO = [
    { k: "floor", re: /(planta|floor|piano|andar|etage|sal)\s*\d|bajo|ground floor|piano terra|r[eé]s[- ]do[- ]ch[aã]o/i, label: "floor" },
    { k: "energy", re: /(certificado energ|energy (rating|certificate|performance)|epc|classe energetica|certificado energético|energim[aæ]rk|clase energ)/i, label: "energy rating" },
    { k: "orientation", re: /(orientaci[oó]n|south[- ]facing|north[- ]facing|esposizione|orienta[cç][aã]o|exterior|interior)/i, label: "orientation" },
    { k: "fees", re: /(comunidad|community fees|service charge|hoa|spese condominiali|condom[ií]nio|ground rent|ejerudgift|f[aæ]llesudgift)/i, label: "community fees" },
    { k: "year", re: /(construid[oa] en|built in|year built|anno di costruzione|\b(18|19|20)\d{2}\b)/i, label: "year built" },
  ];

  RHS.flagsFrom = (text) => {
    const t = String(text || "");
    return FLAGS.filter((f) => f.re.test(t)).map((f) => ({ k: f.k, pts: f.pts, label: f.label, word: (t.match(f.re) || [""])[0] }));
  };

  // ---------------------------------------------------------------- Reasons in the reader's language. Columns: English pattern → es, da, de, it, pt.
  RHS.lang = (() => { try { return (chrome.i18n.getUILanguage() || "en").slice(0, 2); } catch { return (typeof navigator !== "undefined" ? navigator.language : "en").slice(0, 2); } })();
  const COL = { es: 1, da: 2, de: 3, it: 4, pt: 5 };
  const TR = [
    ["Occupied or no possession", "Okupada o sin posesión", "Beboet eller ingen overtagelse", "Bewohnt oder keine Übergabe", "Occupato o senza possesso", "Ocupada ou sem posse"],
    ["Auction sale", "Venta en subasta", "Tvangsauktion", "Versteigerung", "Vendita all'asta", "Venda em leilão"],
    ["Bare ownership / usufruct", "Nuda propiedad / usufructo", "Ejerskab uden brugsret", "Nießbrauch belastet", "Nuda proprietà / usufrutto", "Nua propriedade / usufruto"],
    ["Possible legal or paperwork issue", "Posible problema legal o de papeles", "Mulig juridisk eller papirproblem", "Mögliches rechtliches Problem", "Possibile problema legale o di documenti", "Possível problema legal ou de papéis"],
    ["Needs renovation", "Necesita reforma", "Kræver renovering", "Renovierungsbedürftig", "Da ristrutturare", "Precisa de obras"],
    ["Pitched at investors / cash only", "Dirigida a inversores o solo al contado", "Rettet mod investorer / kun kontant", "Für Investoren / nur bar", "Per investitori / solo contanti", "Para investidores / só a pronto"],
    ["Sold with a tenant", "Se vende con inquilino", "Sælges med lejer", "Vermietet verkauft", "Venduto con inquilino", "Vendida com inquilino"],
    ["Rural land status", "Suelo rústico", "Landbrugsjord", "Außenbereich / Agrarland", "Terreno agricolo", "Solo rústico"],
    ["Hype wording, few facts", "Mucho bombo y pocos datos", "Mange superlativer, få fakta", "Viel Werbung, wenig Fakten", "Molti slogan, pochi dati", "Muita publicidade, poucos dados"],
    ["Other risk", "Otro riesgo", "Anden risiko", "Anderes Risiko", "Altro rischio", "Outro risco"],
    [/[Oo]n the market for (\d+) days/g, "$1 días en venta", "$1 dage til salg", "$1 Tage auf dem Markt", "$1 giorni in vendita", "$1 dias à venda"],
    ["energy rating", "certificado energético", "energimærke", "Energieausweis", "classe energetica", "certificado energético"],
    ["community fees", "gastos de comunidad", "fællesudgifter", "Hausgeld", "spese condominiali", "condomínio"],
    ["year built", "año de construcción", "byggeår", "Baujahr", "anno di costruzione", "ano de construção"],
    ["orientation", "orientación", "orientering", "Ausrichtung", "esposizione", "orientação"],
    [/\bfloor\b/g, "planta", "etage", "Etage", "piano", "andar"],
    ["terrace or balcony", "terraza o balcón", "terrasse eller altan", "Terrasse oder Balkon", "terrazzo o balcone", "terraço ou varanda"],
    ["renovated or new", "reformada o nueva", "renoveret eller ny", "renoviert oder neu", "ristrutturata o nuova", "renovada ou nova"],
    ["air conditioning", "aire acondicionado", "aircondition", "Klimaanlage", "aria condizionata", "ar condicionado"],
    ["storage room", "trastero", "depotrum", "Abstellraum", "cantina", "arrecadação"],
    ["lots of light", "mucha luz", "masser af lys", "viel Licht", "molta luce", "muita luz"],
    [/\blift\b/g, "ascensor", "elevator", "Aufzug", "ascensore", "elevador"], [/\bparking\b/g, "garaje", "parkering", "Stellplatz", "posto auto", "estacionamento"],
    [/\bpool\b/g, "piscina", "pool", "Pool", "piscina", "piscina"], [/\bgarden\b/g, "jardín", "have", "Garten", "giardino", "jardim"], [/\bviews\b/g, "vistas", "udsigt", "Aussicht", "vista", "vista"],
    ["Checking what's within a walk on the map…", "Mirando en el mapa qué hay a pie…", "Tjekker kortet for hvad der er i gåafstand…", "Prüfe auf der Karte, was zu Fuß erreichbar ist…", "Controllo sulla mappa cosa c'è a piedi…", "A ver no mapa o que há a pé…"],
    ["The listing doesn't publish a map location, so location counts as neutral.", "El anuncio no publica su ubicación en el mapa, así que la ubicación cuenta como neutral.", "Annoncen viser ingen placering på kort, så beliggenhed tæller neutralt.", "Die Anzeige zeigt keinen Kartenpunkt, die Lage zählt neutral.", "L'annuncio non pubblica la posizione, quindi conta come neutra.", "O anúncio não publica a localização, por isso conta como neutra."],
    ["Within a 10-minute walk: ", "A 10 minutos andando: ", "Inden for 10 minutters gang: ", "In 10 Minuten zu Fuß: ", "A 10 minuti a piedi: ", "A 10 minutos a pé: "],
    ["Nothing useful within a 10-minute walk.", "Nada útil a 10 minutos andando.", "Intet nyttigt inden for 10 minutters gang.", "Nichts Nützliches in 10 Minuten zu Fuß.", "Niente di utile a 10 minuti a piedi.", "Nada útil a 10 minutos a pé."],
    [" None nearby: ", " Nada cerca: ", " Intet i nærheden: ", " Nichts in der Nähe: ", " Niente vicino: ", " Nada perto: "],
    [" Source: OpenStreetMap.", " Fuente: OpenStreetMap.", " Kilde: OpenStreetMap.", " Quelle: OpenStreetMap.", " Fonte: OpenStreetMap.", " Fonte: OpenStreetMap."],
    ["transport stops", "paradas de transporte", "stoppesteder", "Haltestellen", "fermate", "paragens"], ["transport stop", "parada de transporte", "stoppested", "Haltestelle", "fermata", "paragem"],
    ["food shops", "tiendas de alimentación", "dagligvarebutikker", "Lebensmittelläden", "negozi di alimentari", "mercearias"], ["food shop", "tienda de alimentación", "dagligvarebutik", "Lebensmittelladen", "negozio di alimentari", "mercearia"],
    ["schools", "colegios", "skoler", "Schulen", "scuole", "escolas"], ["school", "colegio", "skole", "Schule", "scuola", "escola"],
    ["pharmacies or doctors", "farmacias o médicos", "apoteker eller læger", "Apotheken oder Ärzte", "farmacie o medici", "farmácias ou médicos"], ["pharmacy or doctor", "farmacia o médico", "apotek eller læge", "Apotheke oder Arzt", "farmacia o medico", "farmácia ou médico"],
    ["parks", "parques", "parker", "Parks", "parchi", "parques"], [/\bpark\b/g, "parque", "park", "Park", "parco", "parque"],
    ["a beach within 2 km", "una playa a menos de 2 km", "en strand inden for 2 km", "ein Strand im Umkreis von 2 km", "una spiaggia entro 2 km", "uma praia a menos de 2 km"],
    ["Not enough comparable homes nearby yet, so price counts as neutral. It gets sharper with every search.", "Aún no hay suficientes casas comparables cerca, así que el precio cuenta como neutral. Mejora con cada búsqueda.", "Endnu ikke nok sammenlignelige boliger i nærheden, så prisen tæller neutralt. Det bliver bedre med hver søgning.", "Noch nicht genug vergleichbare Objekte in der Nähe, der Preis zählt neutral. Wird mit jeder Suche genauer.", "Non ci sono ancora abbastanza case simili vicine, il prezzo conta come neutro. Migliora a ogni ricerca.", "Ainda não há casas comparáveis suficientes perto, por isso o preço conta como neutro. Melhora a cada pesquisa."],
    ["No size published, so price per m² can't be checked.", "No publica los m², así que no se puede comparar el precio por m².", "Ingen størrelse oplyst, så m²-prisen kan ikke tjekkes.", "Keine Größe angegeben, Preis pro m² nicht prüfbar.", "Superficie non indicata, impossibile confrontare il prezzo al m².", "Sem área publicada, não dá para comparar o preço por m²."],
    [/is (\d+)% below the median of/g, "está un $1% por debajo de la mediana de", "er $1% under medianen af", "liegt $1% unter dem Median von", "è il $1% sotto la mediana di", "está $1% abaixo da mediana de"],
    [/is (\d+)% above the median of/g, "está un $1% por encima de la mediana de", "er $1% over medianen af", "liegt $1% über dem Median von", "è il $1% sopra la mediana di", "está $1% acima da mediana de"],
    ["is exactly at the median of", "está justo en la mediana de", "ligger præcis på medianen af", "liegt genau auf dem Median von", "è esattamente sulla mediana di", "está exatamente na mediana de"],
    [/(\d+) comparable homes within (\d) km/g, "$1 casas comparables a menos de $2 km", "$1 sammenlignelige boliger inden for $2 km", "$1 vergleichbaren Objekten im Umkreis von $2 km", "$1 case simili entro $2 km", "$1 casas comparáveis a menos de $2 km"],
    [/the (\d+) homes on your search page/g, "las $1 casas de tu búsqueda", "de $1 boliger i din søgning", "den $1 Objekten deiner Suche", "le $1 case della tua ricerca", "as $1 casas da tua pesquisa"],
    [/(\d+) homes in /g, "$1 casas en ", "$1 boliger i ", "$1 Objekten in ", "$1 case a ", "$1 casas em "],
    ["No red-flag wording found in the listing.", "El anuncio no tiene palabras de alerta.", "Annoncen har ingen advarselsord.", "Keine Warnwörter in der Anzeige.", "Nessuna parola d'allarme nell'annuncio.", "O anúncio não tem palavras de alerta."],
    [/(^|\. )Has /g, "$1Tiene ", "$1Har ", "$1Hat ", "$1Ha ", "$1Tem "], [/\bNo photos/g, "Sin fotos", "Ingen billeder", "Keine Fotos", "Nessuna foto", "Sem fotos"], [/(\d+) photos/g, "$1 fotos", "$1 billeder", "$1 Fotos", "$1 foto", "$1 fotos"],
    ["characters of description", "caracteres de descripción", "tegn beskrivelse", "Zeichen Beschreibung", "caratteri di descrizione", "caracteres de descrição"], ["no description", "sin descripción", "ingen beskrivelse", "keine Beschreibung", "nessuna descrizione", "sem descrição"],
    [". Missing: ", ". Falta: ", ". Mangler: ", ". Fehlt: ", ". Manca: ", ". Falta: "], ["Key facts are all there.", "Tiene todos los datos clave.", "Alle vigtige fakta er der.", "Alle wichtigen Fakten sind da.", "Ci sono tutti i dati chiave.", "Tem todos os dados importantes."],
    ["Answer 5 quick questions to score how well it fits you.", "Responde 5 preguntas rápidas para saber si encaja contigo.", "Svar på 5 hurtige spørgsmål for at se om den passer dig.", "Beantworte 5 kurze Fragen, um zu sehen, ob es passt.", "Rispondi a 5 domande per sapere se fa per te.", "Responde a 5 perguntas rápidas para saber se combina contigo."],
    ["within your budget", "dentro de tu presupuesto", "inden for dit budget", "im Budget", "nel tuo budget", "dentro do teu orçamento"], ["% over your budget", "% por encima de tu presupuesto", "% over dit budget", "% über Budget", "% sopra il budget", "% acima do orçamento"],
    ["in a place you want", "en un sitio que buscas", "et sted du ønsker", "an einem Wunschort", "in una zona che cerchi", "num sítio que procuras"], ["outside your places", "fuera de tus zonas", "uden for dine områder", "außerhalb deiner Orte", "fuori dalle tue zone", "fora das tuas zonas"],
    ["your type of home", "tu tipo de casa", "din boligtype", "dein Objekttyp", "il tuo tipo di casa", "o teu tipo de casa"], ["Not enough data to compare with your profile.", "No hay datos suficientes para compararla con tu perfil.", "Ikke nok data til at sammenligne med din profil.", "Zu wenig Daten für deinen Profilvergleich.", "Dati insufficienti per confrontarla con il tuo profilo.", "Sem dados suficientes para comparar com o teu perfil."],
    [/(\d+)% cheaper than similar homes/g, "$1% más barata que casas similares", "$1% billigere end lignende boliger", "$1% günstiger als ähnliche Objekte", "$1% più economica di case simili", "$1% mais barata que casas semelhantes"],
    [/(\d+)% below similar homes/g, "$1% por debajo de casas similares", "$1% under lignende boliger", "$1% unter ähnlichen Objekten", "$1% sotto case simili", "$1% abaixo de casas semelhantes"],
    ["priced like similar homes", "al precio de casas similares", "prissat som lignende boliger", "Preis wie ähnliche Objekte", "prezzo in linea con case simili", "ao preço de casas semelhantes"],
    [/(\d+)% above similar homes/g, "$1% por encima de casas similares", "$1% over lignende boliger", "$1% über ähnlichen Objekten", "$1% sopra case simili", "$1% acima de casas semelhantes"],
    [/(\d+)% more expensive than similar homes/g, "$1% más cara que casas similares", "$1% dyrere end lignende boliger", "$1% teurer als ähnliche Objekte", "$1% più cara di case simili", "$1% mais cara que casas semelhantes"],
    [/(\d+)% below the official average/g, "$1% por debajo de la media oficial", "$1% under det officielle gennemsnit", "$1% unter dem amtlichen Schnitt", "$1% sotto la media ufficiale", "$1% abaixo da média oficial"],
    [/(\d+)% above the official average/g, "$1% por encima de la media oficial", "$1% over det officielle gennemsnit", "$1% über dem amtlichen Schnitt", "$1% sopra la media ufficiale", "$1% acima da média oficial"],
    ["everything within a walk", "todo a mano andando", "alt i gåafstand", "alles zu Fuß erreichbar", "tutto a piedi", "tudo a pé"], ["isolated, you'll need a car", "aislada, necesitarás coche", "isoleret, du får brug for bil", "abgelegen, Auto nötig", "isolata, serve l'auto", "isolada, vais precisar de carro"],
    ["no red flags", "sin alertas", "ingen advarsler", "keine Warnsignale", "nessun allarme", "sem alertas"],
    ["Description read by AI: ", "Descripción leída por IA: ", "Beskrivelse læst af AI: ", "Beschreibung von KI gelesen: ", "Descrizione letta dall'IA: ", "Descrição lida por IA: "],
    [/No comparable homes nearby yet\. Official appraisal average in (.+?): (.+?)\/m² \(Ministry of Housing, (.+?)\)\. This home: (.+?)\/m²\. Asking prices usually sit above appraisals, so price counts as neutral until there are comparables\./g,
      "Aún no hay casas comparables cerca. Valor tasado medio oficial en $1: $2/m² (Ministerio de Vivienda, $3). Esta casa: $4/m². Los precios de oferta suelen estar por encima de la tasación, así que el precio cuenta como neutral hasta tener comparables.",
      "Endnu ingen sammenlignelige boliger. Officiel gennemsnitsvurdering i $1: $2/m² (Boligministeriet, $3). Denne bolig: $4/m². Udbudspriser ligger typisk over vurderinger, så prisen tæller neutralt indtil der er sammenligninger.",
      "Noch keine Vergleichsobjekte. Amtlicher Durchschnittsschätzwert in $1: $2/m² (Wohnungsministerium, $3). Dieses Objekt: $4/m². Angebotspreise liegen meist über Schätzwerten, daher zählt der Preis neutral, bis es Vergleiche gibt.",
      "Ancora nessuna casa simile vicina. Valore medio di perizia ufficiale a $1: $2/m² (Ministero della Casa, $3). Questa casa: $4/m². I prezzi richiesti di solito superano le perizie, quindi il prezzo conta come neutro finché non ci sono confronti.",
      "Ainda não há casas comparáveis perto. Valor médio oficial de avaliação em $1: $2/m² (Ministério da Habitação, $3). Esta casa: $4/m². Os preços pedidos costumam ficar acima da avaliação, por isso o preço conta como neutro até haver comparáveis."],
  ];
  RHS.tr = (s) => { const c = COL[RHS.lang]; if (!c || !s) return s; let o = String(s); for (const row of TR) { const a = row[0], b = row[c]; o = typeof a === "string" ? o.split(a).join(b) : o.replace(a, b); } return o; };

  // Things buyers pay more for. Shown as highlights; they add to listing quality and to the one-line verdict.
  const PLUS = [
    { k: "terrace", re: /(terraza|terrace|balc[oó]n|balcony|terrazzo|varanda|altan|roof ?garden)/i, label: "terrace or balcony" },
    { k: "lift", re: /(ascensor|lift|elevator|ascensore|elevador|elevador)/i, label: "lift" },
    { k: "parking", re: /(garaje|parking|plaza de aparcamiento|garage|box auto|posto auto|estacionamento|carport)/i, label: "parking" },
    { k: "pool", re: /(piscina|swimming pool|\bpool\b)/i, label: "pool" },
    { k: "garden", re: /(jard[ií]n|garden|giardino|jardim|have\b)/i, label: "garden" },
    { k: "renovated", re: /(reformad[oa]|renovated|refurbished|ristrutturat[oa]|remodelad[oa]|newly (fitted|built)|obra nueva|new build)/i, label: "renovated or new" },
    { k: "view", re: /(vistas al mar|sea views?|ocean views?|vista mare|vista mar|havudsigt|vistas despejadas|panoramic)/i, label: "views" },
    { k: "ac", re: /(aire acondicionado|air[- ]?con|climatizzat|ar condicionado)/i, label: "air conditioning" },
    { k: "light", re: /(muy luminos|bright|luminos[oa]|soleggiat|lots of (natural )?light)/i, label: "lots of light" },
    { k: "storage", re: /(trastero|storage room|cantina|arrecadação|loft storage)/i, label: "storage room" },
  ];
  RHS.plusFrom = (text) => { const t = String(text || ""); return PLUS.filter((x) => x.re.test(t)).map((x) => ({ k: x.k, label: x.label })); };

  // Location: counts of places within a short walk (from OpenStreetMap), see background.js.
  // loc = { transit, shop, school, health, park, beach } (counts within 800 m; beach within 2 km) | null (no coordinates) | undefined (still loading)
  RHS.locScore = (loc) => {
    if (loc === undefined) return { pts: 10, why: "Checking what's within a walk on the map…", pending: true };
    if (!loc) return { pts: 10, why: "The listing doesn't publish a map location, so location counts as neutral." };
    let pts = 0; const have = [], lack = [];
    const add = (n, full, max, one, many) => { if (n > 0) have.push(`${n >= 10 ? "10+" : n} ${n === 1 ? one : many}`); else lack.push(many); return n >= full ? max : n > 0 ? Math.ceil(max / 2) : 0; };
    pts += add(loc.transit, 3, 6, "transport stop", "transport stops");
    pts += add(loc.shop, 2, 4, "food shop", "food shops");
    pts += add(loc.school, 1, 4, "school", "schools");
    pts += add(loc.health, 1, 3, "pharmacy or doctor", "pharmacies or doctors");
    pts += add(loc.park, 1, 3, "park", "parks");
    if (loc.beach > 0) { pts += 2; have.push("a beach within 2 km"); }
    pts = Math.min(20, pts);
    const why = (have.length ? `Within a 10-minute walk: ${have.join(", ")}.` : "Nothing useful within a 10-minute walk.") + (lack.length && have.length ? ` None nearby: ${lack.join(", ")}.` : "") + " Source: OpenStreetMap.";
    return { pts, why, rural: have.length <= 1 };
  };

  // features: {price, currency, sqm, rooms, ptype, area, country, desc, photos, days, portal, lat, lng}
  // ctx: {bench: €/m² benchmark, benchN, benchSource: 'near'|'area'|'page', benchKm, profile, loc}
  // Weights: price 35 · location 20 · red flags 20 · listing 15 · fit 10 = 100
  RHS.score = (f, ctx = {}) => {
    const parts = [];
    const ppsqm = f.price && f.sqm ? f.price / f.sqm : null;
    const text = (f.desc || "") + " " + (f.title || "");
    // 1) Price vs comparable homes — 35
    let p1 = 17, why1 = "Not enough comparable homes nearby yet, so price counts as neutral. It gets sharper with every search.", pct = null;
    if (ppsqm && ctx.bench) {
      const r = ppsqm / ctx.bench;
      p1 = Math.max(0, Math.min(35, Math.round(35 * (1.35 - r) / 0.7)));
      pct = Math.round((r - 1) * 100);
      const src = ctx.benchSource === "near" ? `${ctx.benchN} comparable homes within ${ctx.benchKm || 2} km` : ctx.benchSource === "area" ? `${ctx.benchN} homes in ${f.area || "this area"}` : `the ${ctx.benchN} homes on your search page`;
      why1 = `${RHS.money(ppsqm, f.currency)}/m² is ${pct === 0 ? "exactly at" : Math.abs(pct) + "% " + (pct < 0 ? "below" : "above")} the median of ${src} (${RHS.money(ctx.bench, f.currency)}/m²).`;
    } else if (!ppsqm) { p1 = 12; why1 = "No size published, so price per m² can't be checked."; }
    let opct = null;
    if (pct == null && ppsqm && ctx.official && ctx.official.ppsqm) {
      const o = ctx.official; opct = Math.round((ppsqm / o.ppsqm - 1) * 100);
      why1 = `No comparable homes nearby yet. Official appraisal average in ${o.place}: ${RHS.money(o.ppsqm, f.currency)}/m² (Ministry of Housing, ${o.period}). This home: ${RHS.money(ppsqm, f.currency)}/m². Asking prices usually sit above appraisals, so price counts as neutral until there are comparables.`;
    }
    parts.push({ k: "price", label: "Price vs comparable homes", pts: p1, max: 35, why: why1 });

    // 2) Location — 20
    const L = RHS.locScore(ctx.loc);
    parts.push({ k: "location", label: "Location", pts: L.pts, max: 20, why: L.why, pending: !!L.pending });

    // 3) Red flags — 20
    const flags = RHS.flagsFrom(text);
    const ai = ctx.ai || null;
    if (ai && ai.flags) for (const x of ai.flags) {
      if (flags.some((y) => y.k === x.k && x.k !== "other")) continue;
      const base = FLAGS.find((y) => y.k === x.k);
      flags.push({ k: x.k, pts: base ? base.pts : 5, label: base ? base.label : "Other risk" + (x.note ? ": " + x.note : ""), word: x.quote || "", ai: true });
    }
    let p3 = 20 - flags.reduce((a, x) => a + Math.round(x.pts * 0.75), 0);
    if (f.days != null && f.days > 180) { flags.push({ k: "stale", pts: 4, label: `On the market for ${f.days} days`, word: "" }); p3 -= 4; }
    p3 = Math.max(0, p3);
    parts.push({ k: "flags", label: "Red flags", pts: p3, max: 20,
      why: flags.length ? flags.map((x) => RHS.tr(x.label) + (x.word ? ` (${x.ai ? "AI: " : ""}“${x.word.trim()}”)` : "")).join("; ") + "." : "No red-flag wording found in the listing." });

    // 4) Listing — 15: photos, description, key facts, and what the home has
    let p2 = 0; const miss = [];
    const ph = f.photos || 0;
    p2 += ph >= 20 ? 4 : ph >= 10 ? 3 : ph >= 5 ? 2 : ph > 0 ? 1 : 0;
    const dl = (f.desc || "").length;
    p2 += dl >= 600 ? 2 : dl >= 250 ? 1 : 0;
    let info = 0;
    for (const i of INFO) { if (i.re.test(f.desc || "") || (f.extra && f.extra[i.k])) info++; else miss.push(i.label); }
    p2 += Math.round((info / INFO.length) * 4);
    const plus = RHS.plusFrom(text);
    if (ai && ai.plus) for (const x of ai.plus) {
      if (plus.some((y) => y.k === x.k && x.k !== "other")) continue;
      const base = PLUS.find((y) => y.k === x.k);
      plus.push({ k: x.k, label: base ? base.label : (x.note || x.quote || "").toLowerCase(), ai: true });
    }
    p2 += Math.min(5, plus.length);
    if (f.partial) p2 = Math.max(p2, 8); // search cards show little; don't punish a home for what the card hides
    parts.push({ k: "quality", label: "The home and the listing", pts: Math.min(15, p2), max: 15,
      why: `${ai && ai.summary ? "Description read by AI: " + ai.summary + " " : ""}${plus.length ? "Has " + plus.map((x) => x.label).join(", ") + ". " : ""}${ph || "No"} photos, ${dl > 0 ? dl + " characters of description" : "no description"}${miss.length ? `. Missing: ${miss.join(", ")}.` : ". Key facts are all there."}` });

    // 5) Fit with your profile — 10 (neutral 5 without a profile)
    let p4 = 5, why4 = "Answer 5 quick questions to score how well it fits you.";
    const pr = ctx.profile;
    if (pr && (pr.budget || (pr.places && pr.places.length) || pr.ptype)) {
      p4 = 0; const w = [];
      if (pr.budget && f.price) { if (f.price <= pr.budget) { p4 += 5; w.push("within your budget"); } else w.push(`${Math.round((f.price / pr.budget - 1) * 100)}% over your budget`); }
      const hay = `${f.area || ""} ${f.country || ""} ${({ ES: "spain", PT: "portugal", IT: "italy", GB: "united kingdom", US: "united states" })[f.country] || ""}`.toLowerCase();
      if (pr.places && pr.places.length) { if (pr.places.some((x) => hay.includes(String(x).toLowerCase()))) { p4 += 3; w.push("in a place you want"); } else w.push("outside your places"); }
      if (pr.ptype && pr.ptype !== "any" && f.ptype) { if (String(f.ptype).toLowerCase().match(pr.ptype === "house" ? /house|casa|chalet|villa|detached|semi|terraced|bungalow|cottage|single family|townhouse/ : /flat|piso|apartment|apartamento|condo|appartamento|studio|estudio|ático|atico/)) { p4 += 2; w.push("your type of home"); } }
      else if (pr.ptype === "any") p4 += 2;
      p4 = Math.min(10, p4); why4 = w.length ? w.join(", ") + "." : "Not enough data to compare with your profile.";
    }
    parts.push({ k: "fit", label: "Fit with you", pts: p4, max: 10, why: why4 });

    const score = Math.max(0, Math.min(100, parts.reduce((a, x) => a + x.pts, 0)));
    const verdict = RHS.verdict({ pct, opct, flags, plus, L, ppsqm });
    for (const p of parts) p.why = RHS.tr(p.why);
    for (const x of flags) x.label = RHS.tr(x.label);
    for (const x of plus) x.label = RHS.tr(x.label);
    return { score, parts, flags, plus, ppsqm, pct, opct, ai: !!ai, pending: !!L.pending, verdict };
  };

  // One honest line a person can read in two seconds.
  RHS.verdict = ({ pct, opct, flags, plus, L }) => {
    const bits = [];
    if (pct != null) bits.push(pct <= -15 ? `${-pct}% cheaper than similar homes` : pct < -4 ? `${-pct}% below similar homes` : pct <= 4 ? "priced like similar homes" : pct < 15 ? `${pct}% above similar homes` : `${pct}% more expensive than similar homes`);
    if (pct == null && opct != null) bits.push(opct <= 0 ? `${-opct}% below the official average` : `${opct}% above the official average`);
    if (L && !L.pending && L.pts >= 15) bits.push("everything within a walk"); else if (L && !L.pending && L.rural) bits.push("isolated, you'll need a car");
    const W = { es: ["con ", " y "], da: ["med ", " og "], de: ["mit ", " und "], it: ["con ", " e "], pt: ["com ", " e "] }[RHS.lang] || ["with ", " and "];
    const done = [];
    if (flags && flags.length) done.push("⚠ " + RHS.tr(flags[0].label).toLowerCase());
    else if (plus && plus.length) done.push(W[0] + plus.slice(0, 2).map((x) => RHS.tr(x.label)).join(W[1]));
    else bits.push("no red flags");
    const s = bits.map((b) => RHS.tr(b)).concat(done).join(" · ");
    return s.charAt(0).toUpperCase() + s.slice(1);
  };
  RHS.tone = (s) => (s >= 75 ? "great" : s >= 60 ? "good" : s >= 45 ? "ok" : "low");
  RHS.grade = (s) => (s >= 85 ? "A+" : s >= 75 ? "A" : s >= 65 ? "B" : s >= 55 ? "C" : s >= 45 ? "D" : "E");
  RHS.km = (a, b, c, d) => { const R = 6371, x = (c - a) * Math.PI / 180, y = (d - b) * Math.PI / 180; const h = Math.sin(x / 2) ** 2 + Math.cos(a * Math.PI / 180) * Math.cos(c * Math.PI / 180) * Math.sin(y / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
  RHS.color = (s) => ({ great: "#0F6B34", good: "#2E9E5B", ok: "#D39B12", low: "#C2412D" }[RHS.tone(s)]);
  RHS.median = (a) => { const b = a.filter((x) => x > 0).sort((x, y) => x - y); if (!b.length) return null; const m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };
  RHS.hash = async (s) => {
    const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
    return [...new Uint8Array(d)].slice(0, 16).map((x) => x.toString(16).padStart(2, "0")).join("");
  };
})(typeof window !== "undefined" ? window : self);
