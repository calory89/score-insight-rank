// RealHunt Score — shared scoring engine (runs in content scripts and the side panel).
// Transparent 0–100 score from the listing the user is viewing. Every point comes with a reason.
// It is an estimate, not an appraisal. Sponsorship never changes a score.
(function (g) {
  const RHS = (g.RHS = g.RHS || {});
  const SQFT = 0.09290304;

  RHS.money = (n, cur) => {
    if (n == null || !isFinite(n)) return "—";
    const sym = { EUR: "€", GBP: "£", USD: "$" }[cur] || "";
    if (RHS.lang === "es" && cur === "EUR") return Math.round(n).toLocaleString("es-ES") + " €";
    return sym + Math.round(n).toLocaleString("en-GB");
  };
  RHS.num = (s) => {
    if (s == null) return null;
    if (typeof s === "number") return isFinite(s) ? s : null;
    const t = String(s).replace(/ /g, " ");
    const m = t.match(/\d[\d.,\s]*\d|\d/);
    if (!m) return null;
    let x = m[0].replace(/\s/g, "");
    // 1.250.000 / 1,250,000 / 1.250,50 / 85,5
    if (/^\d{1,3}([.,]\d{3})+$/.test(x)) x = x.replace(/[.,]/g, "");
    else if (/,\d{1,2}$/.test(x)) x = x.replace(/\./g, "").replace(",", ".");
    else x = x.replace(/,/g, "");
    const v = parseFloat(x);
    return isFinite(v) ? v : null;
  };
  RHS.sqm = (s) => {
    if (s == null) return null;
    if (typeof s === "number") return s;
    const t = String(s);
    const ft = t.match(/(\d[\d.,]*)\s*(sq\.?\s*ft|sqft|ft²|ft2)/i);
    if (ft) return Math.round(RHS.num(ft[1]) * SQFT);
    const m = t.match(/(\d[\d.,]*)\s*(m²|m2|mq|sqm|sq\.?\s*m)/i);
    return m ? RHS.num(m[1]) : null;
  };

  // Words that point to a problem. Kept short and literal so the reason shown is always the matched word.
  const FLAGS = [
    { k: "occupied", pts: 15, re: /\b(okupa|ocupad[ao]|sin posesi[oó]n|occupied|sitting tenant|tenant in situ|occupato|ocupado)\b/i, label: "Occupied or no possession" },
    { k: "auction", pts: 12, re: /\b(subasta|auction|asta giudiziaria|leilão|leilao)\b/i, label: "Auction sale" },
    { k: "bare", pts: 12, re: /\b(nuda propiedad|nuda propriet[aà]|usufructo|bare ownership)\b/i, label: "Bare ownership / usufruct" },
    { k: "legal", pts: 12, re: /(sin c[eé]dula|sin legalizar|fuera de ordenaci[oó]n|proindiviso|no habitab|abuso edilizio|non a norma|short lease|cladding|ews1)/i, label: "Possible legal or paperwork issue" },
    { k: "renovation", pts: 8, re: /\b(a reformar|para reformar|necesita reforma|needs? (some )?(work|renovation|updating|modernisation|modernization)|fixer|doer[- ]upper|renovation project|da ristrutturare|para recuperar|tlc)\b/i, label: "Needs renovation" },
    { k: "investors", pts: 6, re: /(ideal inversores|solo inversores|investors? only|cash (buyers )?only|ideale per investitori|rentabilidad garantizada)/i, label: "Pitched at investors / cash only" },
    { k: "rented", pts: 6, re: /\b(alquilad[oa] con|con inquilino|actualmente alquilad|tenanted|sold with tenant|affittato|arrendad[oa])\b/i, label: "Sold with a tenant" },
    { k: "rustic", pts: 5, re: /\b(r[uú]stic[oa] no|suelo r[uú]stico|non urbanizable|agricultural land only)\b/i, label: "Rural land status" },
    { k: "vague", pts: 4, re: /(incre[ií]ble oportunidad|no te lo pierdas|must see|won'?t last|chollo|bargain of the year|opportunit[aà] unica)/i, label: "Hype wording, few facts" },
  ];
  const INFO = [
    { k: "floor", re: /(planta|floor|piano|andar|etage|sal)\s*\d|bajo|ground floor|piano terra|r[eé]s[- ]do[- ]ch[aã]o/i, label: "floor" },
    { k: "energy", re: /(certificado energ|energy (rating|certificate|performance)|epc|classe energetica|certificado energético|energim[aæ]rk|clase energ)/i, label: "energy rating" },
    { k: "orientation", re: /(orientaci[oó]n|south[- ]facing|north[- ]facing|esposizione|orienta[cç][aã]o|exterior|interior)/i, label: "orientation" },
    { k: "fees", re: /(comunidad|community fees|service charge|hoa|spese condominiali|condom[ií]nio|ground rent|ejerudgift|f[aæ]llesudgift)/i, label: "community fees" },
    { k: "year", re: /(construid[oa] en|built in|year built|anno di costruzione|\b(18|19|20)\d{2}\b)/i, label: "year built" },
  ];

  RHS.flagsFrom = (text) => {
    const t = String(text || "");
    return FLAGS.filter((f) => f.re.test(t)).map((f) => ({ k: f.k, pts: f.pts, label: f.label, word: (t.match(f.re) || [""])[0] }));
  };

  // ---------------------------------------------------------------- Spanish wording (the main market). Other languages keep English reasons for now.
  RHS.lang = (() => { try { return (chrome.i18n.getUILanguage() || "en").slice(0, 2); } catch { return (typeof navigator !== "undefined" ? navigator.language : "en").slice(0, 2); } })();
  const ES = [
    ["Occupied or no possession", "Okupada o sin posesión"], ["Auction sale", "Venta en subasta"], ["Bare ownership / usufruct", "Nuda propiedad / usufructo"],
    ["Possible legal or paperwork issue", "Posible problema legal o de papeles"], ["Needs renovation", "Necesita reforma"], ["Pitched at investors / cash only", "Dirigida a inversores o solo al contado"],
    ["Sold with a tenant", "Se vende con inquilino"], ["Rural land status", "Suelo rústico"], ["Hype wording, few facts", "Mucho bombo y pocos datos"],
    [/On the market for (\d+) days/g, "$1 días en venta"], [/on the market for (\d+) days/g, "$1 días en venta"],
    ["energy rating", "certificado energético"], ["community fees", "gastos de comunidad"], ["year built", "año de construcción"], ["orientation", "orientación"], [/\bfloor\b/g, "planta"],
    ["terrace or balcony", "terraza o balcón"], ["renovated or new", "reformada o nueva"], ["air conditioning", "aire acondicionado"], ["storage room", "trastero"],
    [/\blift\b/g, "ascensor"], [/\bparking\b/g, "garaje"], [/\bpool\b/g, "piscina"], [/\bgarden\b/g, "jardín"], [/\bviews\b/g, "vistas"], ["lots of light", "mucha luz"],
    ["Checking what's within a walk on the map…", "Mirando en el mapa qué hay a pie…"],
    ["The listing doesn't publish a map location, so location counts as neutral.", "El anuncio no publica su ubicación en el mapa, así que la ubicación cuenta como neutral."],
    ["Within a 10-minute walk: ", "A 10 minutos andando: "], ["Nothing useful within a 10-minute walk.", "Nada útil a 10 minutos andando."], [" None nearby: ", " Nada cerca: "], [" Source: OpenStreetMap.", " Fuente: OpenStreetMap."],
    ["transport stops", "paradas de transporte"], ["transport stop", "parada de transporte"], ["food shops", "tiendas de alimentación"], ["food shop", "tienda de alimentación"],
    ["schools", "colegios"], ["school", "colegio"], ["pharmacies or doctors", "farmacias o médicos"], ["pharmacy or doctor", "farmacia o médico"], ["parks", "parques"], [/\bpark\b/g, "parque"], ["a beach within 2 km", "una playa a menos de 2 km"],
    ["Not enough comparable homes nearby yet, so price counts as neutral. It gets sharper with every search.", "Aún no hay suficientes casas comparables cerca, así que el precio cuenta como neutral. Mejora con cada búsqueda."],
    ["No size published, so price per m² can't be checked.", "No publica los m², así que no se puede comparar el precio por m²."],
    [/is (\d+)% below the median of/g, "está un $1% por debajo de la mediana de"], [/is (\d+)% above the median of/g, "está un $1% por encima de la mediana de"], ["is exactly at the median of", "está justo en la mediana de"],
    [/(\d+) comparable homes within (\d) km/g, "$1 casas comparables a menos de $2 km"], [/the (\d+) homes on your search page/g, "las $1 casas de tu búsqueda"], [/(\d+) homes in /g, "$1 casas en "],
    ["No red-flag wording found in the listing.", "El anuncio no tiene palabras de alerta."],
    [/^Has /, "Tiene "], [/\bNo photos/g, "Sin fotos"], [/(\d+) photos/g, "$1 fotos"], ["characters of description", "caracteres de descripción"], ["no description", "sin descripción"], [". Missing: ", ". Falta: "], ["Key facts are all there.", "Tiene todos los datos clave."],
    ["Answer 5 quick questions to score how well it fits you.", "Responde 5 preguntas rápidas para saber si encaja contigo."], ["within your budget", "dentro de tu presupuesto"], ["% over your budget", "% por encima de tu presupuesto"],
    ["in a place you want", "en un sitio que buscas"], ["outside your places", "fuera de tus zonas"], ["your type of home", "tu tipo de casa"], ["Not enough data to compare with your profile.", "No hay datos suficientes para compararla con tu perfil."],
    [/(\d+)% cheaper than similar homes/g, "$1% más barata que casas similares"], [/(\d+)% below similar homes/g, "$1% por debajo de casas similares"], ["priced like similar homes", "al precio de casas similares"],
    [/(\d+)% above similar homes/g, "$1% por encima de casas similares"], [/(\d+)% more expensive than similar homes/g, "$1% más cara que casas similares"],
    ["everything within a walk", "todo a mano andando"], ["isolated, you'll need a car", "aislada, necesitarás coche"], ["no red flags", "sin alertas"],
  ];
  RHS.tr = (s) => { if (RHS.lang !== "es" || !s) return s; let o = String(s); for (const [a, b] of ES) o = typeof a === "string" ? o.split(a).join(b) : o.replace(a, b); return o; };

  // Things buyers pay more for. Shown as highlights; they add to listing quality and to the one-line verdict.
  const PLUS = [
    { k: "terrace", re: /(terraza|terrace|balc[oó]n|balcony|terrazzo|varanda|altan|roof ?garden)/i, label: "terrace or balcony" },
    { k: "lift", re: /(ascensor|lift|elevator|ascensore|elevador|elevador)/i, label: "lift" },
    { k: "parking", re: /(garaje|parking|plaza de aparcamiento|garage|box auto|posto auto|estacionamento|carport)/i, label: "parking" },
    { k: "pool", re: /(piscina|swimming pool|\bpool\b)/i, label: "pool" },
    { k: "garden", re: /(jard[ií]n|garden|giardino|jardim|have\b)/i, label: "garden" },
    { k: "renovated", re: /(reformad[oa]|renovated|refurbished|ristrutturat[oa]|remodelad[oa]|newly (fitted|built)|obra nueva|new build)/i, label: "renovated or new" },
    { k: "view", re: /(vistas al mar|sea views?|ocean views?|vista mare|vista mar|havudsigt|vistas despejadas|panoramic)/i, label: "views" },
    { k: "ac", re: /(aire acondicionado|air[- ]?con|climatizzat|ar condicionado)/i, label: "air conditioning" },
    { k: "light", re: /(muy luminos|bright|luminos[oa]|soleggiat|lots of (natural )?light)/i, label: "lots of light" },
    { k: "storage", re: /(trastero|storage room|cantina|arrecadação|loft storage)/i, label: "storage room" },
  ];
  RHS.plusFrom = (text) => { const t = String(text || ""); return PLUS.filter((x) => x.re.test(t)).map((x) => ({ k: x.k, label: x.label })); };

  // Location: counts of places within a short walk (from OpenStreetMap), see background.js.
  // loc = { transit, shop, school, health, park, beach } (counts within 800 m; beach within 2 km) | null (no coordinates) | undefined (still loading)
  RHS.locScore = (loc) => {
    if (loc === undefined) return { pts: 10, why: "Checking what's within a walk on the map…", pending: true };
    if (!loc) return { pts: 10, why: "The listing doesn't publish a map location, so location counts as neutral." };
    let pts = 0; const have = [], lack = [];
    const add = (n, full, max, one, many) => { if (n > 0) have.push(`${n >= 10 ? "10+" : n} ${n === 1 ? one : many}`); else lack.push(many); return n >= full ? max : n > 0 ? Math.ceil(max / 2) : 0; };
    pts += add(loc.transit, 3, 6, "transport stop", "transport stops");
    pts += add(loc.shop, 2, 4, "food shop", "food shops");
    pts += add(loc.school, 1, 4, "school", "schools");
    pts += add(loc.health, 1, 3, "pharmacy or doctor", "pharmacies or doctors");
    pts += add(loc.park, 1, 3, "park", "parks");
    if (loc.beach > 0) { pts += 2; have.push("a beach within 2 km"); }
    pts = Math.min(20, pts);
    const why = (have.length ? `Within a 10-minute walk: ${have.join(", ")}.` : "Nothing useful within a 10-minute walk.") + (lack.length && have.length ? ` None nearby: ${lack.join(", ")}.` : "") + " Source: OpenStreetMap.";
    return { pts, why, rural: have.length <= 1 };
  };

  // features: {price, currency, sqm, rooms, ptype, area, country, desc, photos, days, portal, lat, lng}
  // ctx: {bench: €/m² benchmark, benchN, benchSource: 'near'|'area'|'page', benchKm, profile, loc}
  // Weights: price 35 · location 20 · red flags 20 · listing 15 · fit 10 = 100
  RHS.score = (f, ctx = {}) => {
    const parts = [];
    const ppsqm = f.price && f.sqm ? f.price / f.sqm : null;
    const text = (f.desc || "") + " " + (f.title || "");
    // 1) Price vs comparable homes — 35
    let p1 = 17, why1 = "Not enough comparable homes nearby yet, so price counts as neutral. It gets sharper with every search.", pct = null;
    if (ppsqm && ctx.bench) {
      const r = ppsqm / ctx.bench;
      p1 = Math.max(0, Math.min(35, Math.round(35 * (1.35 - r) / 0.7)));
      pct = Math.round((r - 1) * 100);
      const src = ctx.benchSource === "near" ? `${ctx.benchN} comparable homes within ${ctx.benchKm || 2} km` : ctx.benchSource === "area" ? `${ctx.benchN} homes in ${f.area || "this area"}` : `the ${ctx.benchN} homes on your search page`;
      why1 = `${RHS.money(ppsqm, f.currency)}/m² is ${pct === 0 ? "exactly at" : Math.abs(pct) + "% " + (pct < 0 ? "below" : "above")} the median of ${src} (${RHS.money(ctx.bench, f.currency)}/m²).`;
    } else if (!ppsqm) { p1 = 12; why1 = "No size published, so price per m² can't be checked."; }
    parts.push({ k: "price", label: "Price vs comparable homes", pts: p1, max: 35, why: why1 });

    // 2) Location — 20
    const L = RHS.locScore(ctx.loc);
    parts.push({ k: "location", label: "Location", pts: L.pts, max: 20, why: L.why, pending: !!L.pending });

    // 3) Red flags — 20
    const flags = RHS.flagsFrom(text);
    let p3 = 20 - flags.reduce((a, x) => a + Math.round(x.pts * 0.75), 0);
    if (f.days != null && f.days > 180) { flags.push({ k: "stale", pts: 4, label: `On the market for ${f.days} days`, word: "" }); p3 -= 4; }
    p3 = Math.max(0, p3);
    parts.push({ k: "flags", label: "Red flags", pts: p3, max: 20,
      why: flags.length ? flags.map((x) => x.label + (x.word ? ` (“${x.word.trim()}”)` : "")).join("; ") + "." : "No red-flag wording found in the listing." });

    // 4) Listing — 15: photos, description, key facts, and what the home has
    let p2 = 0; const miss = [];
    const ph = f.photos || 0;
    p2 += ph >= 20 ? 4 : ph >= 10 ? 3 : ph >= 5 ? 2 : ph > 0 ? 1 : 0;
    const dl = (f.desc || "").length;
    p2 += dl >= 600 ? 2 : dl >= 250 ? 1 : 0;
    let info = 0;
    for (const i of INFO) { if (i.re.test(f.desc || "") || (f.extra && f.extra[i.k])) info++; else miss.push(i.label); }
    p2 += Math.round((info / INFO.length) * 4);
    const plus = RHS.plusFrom(text);
    p2 += Math.min(5, plus.length);
    if (f.partial) p2 = Math.max(p2, 8); // search cards show little; don't punish a home for what the card hides
    parts.push({ k: "quality", label: "The home and the listing", pts: Math.min(15, p2), max: 15,
      why: `${plus.length ? "Has " + plus.map((x) => x.label).join(", ") + ". " : ""}${ph || "No"} photos, ${dl > 0 ? dl + " characters of description" : "no description"}${miss.length ? `. Missing: ${miss.join(", ")}.` : ". Key facts are all there."}` });

    // 5) Fit with your profile — 10 (neutral 5 without a profile)
    let p4 = 5, why4 = "Answer 5 quick questions to score how well it fits you.";
    const pr = ctx.profile;
    if (pr && (pr.budget || (pr.places && pr.places.length) || pr.ptype)) {
      p4 = 0; const w = [];
      if (pr.budget && f.price) { if (f.price <= pr.budget) { p4 += 5; w.push("within your budget"); } else w.push(`${Math.round((f.price / pr.budget - 1) * 100)}% over your budget`); }
      const hay = `${f.area || ""} ${f.country || ""} ${({ ES: "spain", PT: "portugal", IT: "italy", GB: "united kingdom", US: "united states" })[f.country] || ""}`.toLowerCase();
      if (pr.places && pr.places.length) { if (pr.places.some((x) => hay.includes(String(x).toLowerCase()))) { p4 += 3; w.push("in a place you want"); } else w.push("outside your places"); }
      if (pr.ptype && pr.ptype !== "any" && f.ptype) { if (String(f.ptype).toLowerCase().match(pr.ptype === "house" ? /house|casa|chalet|villa|detached|semi|terraced|bungalow|cottage|single family|townhouse/ : /flat|piso|apartment|apartamento|condo|appartamento|studio|estudio|ático|atico/)) { p4 += 2; w.push("your type of home"); } }
      else if (pr.ptype === "any") p4 += 2;
      p4 = Math.min(10, p4); why4 = w.length ? w.join(", ") + "." : "Not enough data to compare with your profile.";
    }
    parts.push({ k: "fit", label: "Fit with you", pts: p4, max: 10, why: why4 });

    const score = Math.max(0, Math.min(100, parts.reduce((a, x) => a + x.pts, 0)));
    const verdict = RHS.verdict({ pct, flags, plus, L, ppsqm });
    for (const p of parts) p.why = RHS.tr(p.why);
    for (const x of flags) x.label = RHS.tr(x.label);
    for (const x of plus) x.label = RHS.tr(x.label);
    return { score, parts, flags, plus, ppsqm, pct, pending: !!L.pending, verdict };
  };

  // One honest line a person can read in two seconds.
  RHS.verdict = ({ pct, flags, plus, L }) => {
    const bits = [];
    if (pct != null) bits.push(pct <= -15 ? `${-pct}% cheaper than similar homes` : pct < -4 ? `${-pct}% below similar homes` : pct <= 4 ? "priced like similar homes" : pct < 15 ? `${pct}% above similar homes` : `${pct}% more expensive than similar homes`);
    if (L && !L.pending && L.pts >= 15) bits.push("everything within a walk"); else if (L && !L.pending && L.rural) bits.push("isolated, you'll need a car");
    const es = RHS.lang === "es";
    if (flags && flags.length) bits.push("⚠ " + RHS.tr(flags[0].label).toLowerCase());
    else if (plus && plus.length) bits.push((es ? "con " : "with ") + plus.slice(0, 2).map((x) => RHS.tr(x.label)).join(es ? " y " : " and "));
    else bits.push("no red flags");
    const s = bits.map((b) => (b.startsWith("⚠") || b.startsWith("con ") ? b : RHS.tr(b))).join(" · ");
    return s.charAt(0).toUpperCase() + s.slice(1);
  };
  RHS.tone = (s) => (s >= 75 ? "great" : s >= 60 ? "good" : s >= 45 ? "ok" : "low");
  RHS.grade = (s) => (s >= 85 ? "A+" : s >= 75 ? "A" : s >= 65 ? "B" : s >= 55 ? "C" : s >= 45 ? "D" : "E");
  RHS.km = (a, b, c, d) => { const R = 6371, x = (c - a) * Math.PI / 180, y = (d - b) * Math.PI / 180; const h = Math.sin(x / 2) ** 2 + Math.cos(a * Math.PI / 180) * Math.cos(c * Math.PI / 180) * Math.sin(y / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
  RHS.color = (s) => ({ great: "#0F6B34", good: "#2E9E5B", ok: "#D39B12", low: "#C2412D" }[RHS.tone(s)]);
  RHS.median = (a) => { const b = a.filter((x) => x > 0).sort((x, y) => x - y); if (!b.length) return null; const m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };
  RHS.hash = async (s) => {
    const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
    return [...new Uint8Array(d)].slice(0, 16).map((x) => x.toString(16).padStart(2, "0")).join("");
  };
})(typeof window !== "undefined" ? window : self);
