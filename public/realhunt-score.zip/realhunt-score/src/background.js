// RealHunt Score — service worker. The only place that talks to the RealHunt backend.
// No API keys beyond the public (anon) Supabase key; all writes go through security-definer RPCs that accept
// derived listing features only. Nothing is sent before the user gives consent.
const API = "https://nylmhdtlshhtjkuvfbms.supabase.co/rest/v1/rpc/";
const ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im55bG1oZHRsc2hodGprdXZmYm1zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE2MTg3MzMsImV4cCI6MjA4NzE5NDczM30.KHhGDOexuJeD-i4yyFWi7FInTfA2DIeAs8lpjD1f0Yc";
const FREE_REPORTS_PER_DAY = 3;
const CONSENT_VERSION = "v1-2026-10";

async function rpc(fn, body) {
  try {
    const r = await fetch(API + fn, { method: "POST", headers: { apikey: ANON, Authorization: "Bearer " + ANON, "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (!r.ok) return null;
    const t = await r.text(); return t ? JSON.parse(t) : null;
  } catch { return null; }
}
const L = (k) => chrome.storage.local.get(k).then((o) => o[k]);
const S = (o) => chrome.storage.local.set(o);
const today = () => new Date().toISOString().slice(0, 10);

async function deviceId() { let d = await L("device_id"); if (!d) { d = crypto.randomUUID(); await S({ device_id: d }); } return d; }
async function state() {
  const [consent, token, email, profile, quota] = await Promise.all([L("consent"), L("token"), L("email"), L("profile"), L("quota")]);
  const used = quota && quota.day === today() ? quota.used.length : 0;
  return { consent: !!consent, token: token || null, email: email || null, profile: profile || null, quotaLeft: email ? 999 : Math.max(0, FREE_REPORTS_PER_DAY - used) };
}
async function track(kind, extra = {}) {
  const st = await state(); if (!st.consent) return; // no analytics before consent
  rpc("ext_track", { p: { token: st.token, device_id: await deviceId(), kind, ...extra } });
}

chrome.runtime.onInstalled.addListener(async (d) => {
  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch {}
  if (d.reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
});

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    const st = await state();
    switch (m.t) {
      case "state": return reply(st);
      case "consent": {
        const r = await rpc("ext_consent", { p: { consent: true, token: st.token, device_id: await deviceId(), lang: chrome.i18n.getUILanguage().slice(0, 2), version: CONSENT_VERSION } });
        await S({ consent: true, consent_at: new Date().toISOString(), token: r && r.token ? r.token : st.token });
        track("install");
        return reply({ ok: true });
      }
      case "revoke": { await chrome.storage.local.clear(); return reply({ ok: true }); }
      case "pageBench": { await chrome.storage.session.set({ ["bench:" + m.key]: { bench: m.bench, n: m.n } }); return reply(true); }
      case "detail": {
        const pb = (await chrome.storage.session.get("bench:" + m.areaKey))["bench:" + m.areaKey] || null;
        let server = null;
        if (st.consent && st.token) {
          // lookup only (no hash = nothing stored); the listing itself is stored once, with its score, in "report"
          server = await rpc("ext_listing_seen", { p: { token: st.token, portal: m.f.portal, area: m.f.area, currency: m.f.currency } });
        }
        return reply({ ...(server || {}), page_bench: pb });
      }
      case "report": {
        const tabId = sender.tab && sender.tab.id;
        if (tabId != null) await chrome.storage.session.set({ ["report:" + tabId]: m.report, lastReport: m.report });
        const R = m.report;
        if (st.consent && st.token) rpc("ext_listing_seen", { p: { token: st.token, hash: R.hash, portal: R.portal, url: R.url, country: R.country, area: R.area, price: R.price, currency: R.currency, sqm: R.sqm, ppsqm: R.ppsqm ? Math.round(R.ppsqm) : null, rooms: R.rooms, ptype: R.ptype, days: R.days, score: R.score, flags: R.flags } });
        return reply(true);
      }
      case "useReport": {
        let q = (await L("quota")) || { day: today(), used: [] };
        if (q.day !== today()) q = { day: today(), used: [] };
        if (!q.used.includes(m.hash)) {
          if (!st.email && q.used.length >= FREE_REPORTS_PER_DAY) { track("quota_hit"); return reply({ quotaLeft: 0 }); }
          q.used.push(m.hash); await S({ quota: q });
        }
        track("report", { hash: m.hash });
        return reply({ quotaLeft: st.email ? 999 : Math.max(0, FREE_REPORTS_PER_DAY - q.used.length) });
      }
      case "openPanel": {
        try { await chrome.sidePanel.open({ tabId: sender.tab.id }); return reply(true); } catch { return reply(false); }
      }
      case "track": { await track(m.kind, { hash: m.hash, price: m.price, meta: m.meta }); return reply(true); }
      case "signup": {
        if (!st.consent || !st.token) return reply({ error: "consent" });
        const r = await rpc("ext_signup", { p: { token: st.token, email: m.email, phone: m.phone, marketing: !!m.marketing } });
        if (r && r.ok) await S({ email: m.email.trim().toLowerCase() });
        return reply(r || { error: "network" });
      }
      case "profile": {
        await S({ profile: m.profile });
        if (st.consent && st.token) await rpc("ext_profile_save", { p: { token: st.token, ...m.profile } });
        return reply({ ok: true });
      }
      case "recommend": {
        if (!st.consent || !st.token) return reply([]);
        return reply((await rpc("ext_recommend", { p_token: st.token })) || []);
      }
      case "deleteMe": {
        if (st.token) await rpc("ext_delete_me", { p_token: st.token });
        await chrome.storage.local.clear(); await chrome.storage.session.clear();
        return reply({ ok: true });
      }
      default: return reply(null);
    }
  })();
  return true;
});
