// RealHunt Score — service worker. The only place that talks to the RealHunt backend.
// No API keys beyond the public (anon) Supabase key; all writes go through security-definer RPCs that accept
// derived listing features only. Nothing is sent before the user gives consent.
const API = "https://nylmhdtlshhtjkuvfbms.supabase.co/rest/v1/rpc/";
const ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im55bG1oZHRsc2hodGprdXZmYm1zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE2MTg3MzMsImV4cCI6MjA4NzE5NDczM30.KHhGDOexuJeD-i4yyFWi7FInTfA2DIeAs8lpjD1f0Yc";
const FREE_REPORTS_PER_DAY = 3;
const CONSENT_VERSION = "v1-2026-10";

async function rpc(fn, body) {
  try {
    const r = await fetch(API + fn, { method: "POST", headers: { apikey: ANON, Authorization: "Bearer " + ANON, "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (!r.ok) return null;
    const t = await r.text(); return t ? JSON.parse(t) : null;
  } catch { return null; }
}
const L = (k) => chrome.storage.local.get(k).then((o) => o[k]);
const S = (o) => chrome.storage.local.set(o);
const today = () => new Date().toISOString().slice(0, 10);

async function deviceId() { let d = await L("device_id"); if (!d) { d = crypto.randomUUID(); await S({ device_id: d }); } return d; }
async function state() {
  const [consent, token, email, profile, quota] = await Promise.all([L("consent"), L("token"), L("email"), L("profile"), L("quota")]);
  const used = quota && quota.day === today() ? quota.used.length : 0;
  return { consent: !!consent, token: token || null, email: email || null, profile: profile || null, quotaLeft: email ? 999 : Math.max(0, FREE_REPORTS_PER_DAY - used) };
}
async function track(kind, extra = {}) {
  const st = await state(); if (!st.consent) return; // no analytics before consent
  rpc("ext_track", { p: { token: st.token, device_id: await deviceId(), kind, ...extra } });
}

// ---------------------------------------------------------------- comparable homes, kept in this browser
// Every search page the user opens adds its homes (derived numbers only) to a local pool. A listing is then
// compared with homes within 2 km (5 km if needed), else the same neighbourhood, else the last search page.
const POOL_MAX = 800;
async function poolGet() { return (await chrome.storage.local.get("pool")).pool || []; }
async function poolAdd(items) {
  const now = Date.now(); const pool = (await poolGet()).filter((x) => now - x.t < 30 * 864e5);
  const idx = new Map(pool.map((x, i) => [x.h, i]));
  for (const it of items) { if (!it.h || !(it.pp > 0)) continue; const row = { ...it, t: now }; if (idx.has(it.h)) pool[idx.get(it.h)] = row; else { idx.set(it.h, pool.length); pool.push(row); } }
  await chrome.storage.local.set({ pool: pool.slice(-POOL_MAX) });
}
const kmBetween = (a, b, c, d) => { const R = 6371, x = (c - a) * Math.PI / 180, y = (d - b) * Math.PI / 180; const h = Math.sin(x / 2) ** 2 + Math.cos(a * Math.PI / 180) * Math.cos(c * Math.PI / 180) * Math.sin(y / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
const medianOf = (a) => { const b = a.filter((x) => x > 0).sort((x, y) => x - y); if (!b.length) return null; const m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };
async function localComps(f, hash) {
  // similar homes only: same portal and currency, and between half and double the size
  const pool = (await poolGet()).filter((x) => x.h !== hash && x.cur === f.currency && x.portal === f.portal && (!f.sqm || !x.sqm || (x.sqm >= f.sqm / 2 && x.sqm <= f.sqm * 2)));
  if (f.lat != null && f.lng != null) {
    for (const km of [1, 2, 5]) {
      const near = pool.filter((x) => x.lat != null && kmBetween(f.lat, f.lng, x.lat, x.lng) <= km);
      if (near.length >= 5) return { bench: Math.round(medianOf(near.map((x) => x.pp))), n: near.length, source: "near", km };
    }
  }
  const a = String(f.area || "").toLowerCase();
  if (a) { const same = pool.filter((x) => String(x.area || "").toLowerCase() === a); if (same.length >= 5) return { bench: Math.round(medianOf(same.map((x) => x.pp))), n: same.length, source: "area" }; }
  return null;
}

// ---------------------------------------------------------------- what's within a walk (OpenStreetMap, cached 30 days)
const OVERPASS = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"];
async function nearby(lat, lng) {
  if (lat == null || lng == null || !isFinite(lat) || !isFinite(lng)) return null;
  const key = `loc:${lat.toFixed(3)},${lng.toFixed(3)}`;
  const c = (await chrome.storage.local.get(key))[key];
  if (c && Date.now() - c.t < 30 * 864e5) return c.v;
  const A = (r) => `(around:${r},${lat},${lng})`;
  const q = `[out:json][timeout:12];(nwr${A(800)}[highway=bus_stop];nwr${A(800)}[railway~"^(station|halt|tram_stop|subway_entrance)$"];);out count;` +
    `nwr${A(800)}[shop~"^(supermarket|convenience|greengrocer|bakery|butcher)$"];out count;` +
    `nwr${A(800)}[amenity~"^(school|kindergarten)$"];out count;` +
    `nwr${A(800)}[amenity~"^(pharmacy|doctors|clinic|hospital)$"];out count;` +
    `nwr${A(800)}[leisure~"^(park|playground)$"];out count;` +
    `nwr${A(2000)}[natural=beach];out count;`;
  for (const u of OVERPASS) {
    try {
      const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 9000);
      const r = await fetch(u, { method: "POST", body: "data=" + encodeURIComponent(q), headers: { "Content-Type": "application/x-www-form-urlencoded" }, signal: ctl.signal });
      clearTimeout(to);
      if (!r.ok) continue;
      const n = (await r.json()).elements.map((e) => +((e.tags || {}).total || 0));
      if (n.length < 6) continue;
      const v = { transit: n[0], shop: n[1], school: n[2], health: n[3], park: n[4], beach: n[5] };
      await chrome.storage.local.set({ [key]: { t: Date.now(), v } });
      return v;
    } catch { /* try the next mirror */ }
  }
  return null;
}

chrome.runtime.onInstalled.addListener(async (d) => {
  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch {}
  if (d.reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
});

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    const st = await state();
    switch (m.t) {
      case "state": return reply(st);
      case "consent": {
        const r = await rpc("ext_consent", { p: { consent: true, token: st.token, device_id: await deviceId(), lang: chrome.i18n.getUILanguage().slice(0, 2), version: CONSENT_VERSION } });
        await S({ consent: true, consent_at: new Date().toISOString(), token: r && r.token ? r.token : st.token });
        track("install");
        return reply({ ok: true });
      }
      case "revoke": { await chrome.storage.local.clear(); return reply({ ok: true }); }
      case "cards": {
        // search page: remember the page median (for listings opened from it) and add its homes to the local pool
        await chrome.storage.session.set({ ["page:" + m.portal]: { bench: m.bench, n: m.n, t: Date.now(), area: m.area } });
        await poolAdd(m.items || []);
        if (st.consent && st.token && (m.items || []).length) rpc("ext_cards_seen", { p: { token: st.token, items: m.items.slice(0, 60) } });
        return reply(true);
      }
      case "detail": {
        const f = m.f;
        let comps = await localComps(f, m.hash);
        if ((!comps || comps.n < 8) && st.consent && st.token) {
          const s2 = await rpc("ext_comps", { p: { token: st.token, hash: m.hash, portal: f.portal, currency: f.currency, area: f.area, lat: f.lat, lng: f.lng, sqm: f.sqm } });
          if (s2 && s2.bench && (!comps || s2.n > comps.n)) comps = s2;
        }
        if (!comps) {
          const pg = (await chrome.storage.session.get("page:" + f.portal))["page:" + f.portal];
          if (pg && pg.bench && pg.n >= 5 && Date.now() - pg.t < 3 * 3600e3) comps = { bench: pg.bench, n: pg.n, source: "page" };
        }
        return reply(comps || {});
      }
      case "nearby": return reply(await nearby(m.lat, m.lng));
      case "report": {
        const tabId = sender.tab && sender.tab.id;
        if (tabId != null) await chrome.storage.session.set({ ["report:" + tabId]: m.report, lastReport: m.report });
        const R = m.report;
        if (st.consent && st.token) rpc("ext_listing_seen", { p: { token: st.token, hash: R.hash, portal: R.portal, url: R.url, country: R.country, area: R.area, lat: R.lat, lng: R.lng, price: R.price, currency: R.currency, sqm: R.sqm, ppsqm: R.ppsqm ? Math.round(R.ppsqm) : null, rooms: R.rooms, ptype: R.ptype, days: R.days, score: R.score, flags: R.flags } });
        return reply(true);
      }
      case "useReport": {
        let q = (await L("quota")) || { day: today(), used: [] };
        if (q.day !== today()) q = { day: today(), used: [] };
        if (!q.used.includes(m.hash)) {
          if (!st.email && q.used.length >= FREE_REPORTS_PER_DAY) { track("quota_hit"); return reply({ quotaLeft: 0 }); }
          q.used.push(m.hash); await S({ quota: q });
        }
        track("report", { hash: m.hash });
        return reply({ quotaLeft: st.email ? 999 : Math.max(0, FREE_REPORTS_PER_DAY - q.used.length) });
      }
      case "openPanel": {
        try { await chrome.sidePanel.open({ tabId: sender.tab.id }); return reply(true); } catch { return reply(false); }
      }
      case "track": { await track(m.kind, { hash: m.hash, price: m.price, meta: m.meta }); return reply(true); }
      case "signup": {
        if (!st.consent || !st.token) return reply({ error: "consent" });
        const r = await rpc("ext_signup", { p: { token: st.token, email: m.email, phone: m.phone, marketing: !!m.marketing } });
        if (r && r.ok) await S({ email: m.email.trim().toLowerCase() });
        return reply(r || { error: "network" });
      }
      case "profile": {
        await S({ profile: m.profile });
        if (st.consent && st.token) await rpc("ext_profile_save", { p: { token: st.token, ...m.profile } });
        return reply({ ok: true });
      }
      case "recommend": {
        if (!st.consent || !st.token) return reply([]);
        return reply((await rpc("ext_recommend", { p_token: st.token })) || []);
      }
      case "deleteMe": {
        if (st.token) await rpc("ext_delete_me", { p_token: st.token });
        await chrome.storage.local.clear(); await chrome.storage.session.clear();
        return reply({ ok: true });
      }
      default: return reply(null);
    }
  })();
  return true;
});
