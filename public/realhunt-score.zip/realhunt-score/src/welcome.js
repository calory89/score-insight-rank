const T = (k) => chrome.i18n.getMessage(k) || k;
for (const [id, k] of [["t", "welcome_title"], ["b", "welcome_body"], ["ct", "consent_title"], ["cb", "consent_body"], ["ok", "allow"], ["no", "not_now"], ["pv", "privacy"], ["try", "try_it"]]) document.getElementById(id).textContent = T(k);
document.getElementById("ok").onclick = () => chrome.runtime.sendMessage({ t: "consent" }, () => { document.getElementById("ok").textContent = "✓"; });
document.getElementById("no").onclick = () => window.close();
