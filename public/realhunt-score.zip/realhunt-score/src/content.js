// RealHunt Score — content script. Runs only on the supported portals (see manifest host list).
(function () {
  const RHS = window.RHS;
  const A = RHS.adapterFor(location.hostname);
  if (!A || window.__rhsLoaded) return;
  window.__rhsLoaded = true;
  const T = (k, subs) => { try { return chrome.i18n.getMessage(k, subs) || k; } catch { return k; } };
  const send = (msg) => new Promise((res) => { try { chrome.runtime.sendMessage(msg, (r) => res(chrome.runtime.lastError ? null : r)); } catch { res(null); } });

  const CSS = `
  :host{all:initial}
  .b{font:700 12px/1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;display:inline-flex;align-items:center;gap:5px;padding:5px 8px;border-radius:999px;color:#fff;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.18);margin:6px 0;user-select:none}
  .b small{font-weight:600;opacity:.85;font-size:10px}
  .c{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:320px;max-height:78vh;overflow:auto;background:#fff;color:#14181c;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.28);font:14px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  .h{display:flex;gap:12px;align-items:center;padding:14px 14px 10px}
  .s{width:58px;height:58px;border-radius:16px;display:grid;place-items:center;color:#fff;font:800 26px/1 system-ui}
  .t b{display:block;font-size:15px}.t small{color:#5b636b}
  .x{margin-left:auto;align-self:flex-start;border:0;background:none;font-size:18px;cursor:pointer;color:#8a9098}
  .p{padding:0 14px 6px}
  .r{margin:8px 0}.r .l{display:flex;justify-content:space-between;font-weight:700;font-size:13px}.r .bar{height:6px;border-radius:4px;background:#eef0f2;margin:4px 0}.r .bar i{display:block;height:100%;border-radius:4px}
  .r p{margin:0;color:#4f5a55;font-size:12.5px}
  .f{padding:10px 14px 14px;display:flex;gap:8px;flex-wrap:wrap}
  button.k{border:0;border-radius:10px;padding:9px 12px;font:700 13px system-ui;cursor:pointer;background:#0F6B34;color:#fff}
  button.k.s2{background:#eef0f2;color:#14181c}
  .n{font-size:11px;color:#8a9098;padding:0 14px 12px}
  .b i{font-style:normal;font-weight:800;font-size:10.5px;background:rgba(255,255,255,.22);border-radius:999px;padding:2px 5px}
  .s{flex-direction:column}
  .s small{display:block;font:800 11px/1 system-ui;opacity:.9;margin-top:3px;color:#fff}
  .v{padding:0 14px 8px;font-weight:700;font-size:13.5px;line-height:1.35}
  .mini{padding:0 14px 6px;display:grid;gap:5px}
  .mini .row{display:grid;grid-template-columns:128px 1fr 38px;gap:8px;align-items:center;font-size:12px;color:#4f5a55}
  .mini .bar{height:6px;border-radius:4px;background:#eef0f2}.mini .bar i{display:block;height:100%;border-radius:4px}
  .mini b{font-size:12px;color:#14181c;text-align:right}
  .pend{opacity:.55}
  .ai{font:800 9.5px/1 system-ui;background:#111;color:#fff;border-radius:6px;padding:3px 5px;vertical-align:2px;margin-left:4px}
  .free{display:inline-block;font:800 10px/1 system-ui;background:#FFE14D;color:#14181c;border-radius:6px;padding:3px 6px;letter-spacing:.04em}
  .nudge{margin:2px 14px 6px;padding:9px 11px;border-radius:12px;background:#14181c;color:#fff;font:700 12.5px/1.35 system-ui;cursor:pointer}
  .in{width:100%;box-sizing:border-box;margin-top:8px;padding:10px 11px;border:1px solid #cfd6d1;border-radius:10px;font:15px system-ui;background:#fff;color:#14181c}
  .ck{display:flex;gap:6px;align-items:flex-start;font-size:11.5px;color:#4f5a55;margin-top:7px}
  .fine{font-size:10.5px;color:#7a837e;margin-top:6px}.err{color:#C2412D;font-size:12px;margin-top:4px}
  .x+.x{margin-left:0}
  .pill{position:fixed;right:16px;bottom:16px;z-index:2147483646;display:flex;align-items:center;gap:8px;padding:8px 14px 8px 8px;border-radius:999px;color:#fff;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.25);font:700 12px/1 system-ui}
  .pill b{background:rgba(255,255,255,.22);border-radius:999px;padding:7px 9px;font:800 16px/1 system-ui}
  .fab{position:fixed;left:16px;bottom:16px;z-index:2147483645;display:flex;align-items:center;gap:8px;padding:10px 16px 10px 10px;border-radius:999px;background:#14181c;color:#fff;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.28);font:700 13px/1.1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  .fab b{background:#FFE14D;color:#14181c;border-radius:999px;width:28px;height:28px;display:grid;place-items:center;font:800 15px/1 system-ui}
  .fab small{display:block;font-weight:600;opacity:.7;font-size:11px;margin-top:2px}
  .rk{position:fixed;left:16px;top:16px;bottom:16px;z-index:2147483646;width:400px;max-width:calc(100vw - 32px);display:flex;flex-direction:column;background:#fff;color:#14181c;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.3);font:13px/1.35 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;overflow:hidden}
  .rk-h{padding:14px 14px 8px;border-bottom:1px solid #eef0f2}
  .rk-h .top{display:flex;align-items:center;gap:8px}.rk-h .top b{font-size:15px}
  .rk-h .st{color:#5b636b;font-size:12px;margin-top:4px}
  .rk-bar{height:4px;background:#eef0f2;border-radius:3px;margin-top:8px;overflow:hidden}.rk-bar i{display:block;height:100%;background:#0F6B34;transition:width .3s}
  .rk-bar.run i{background:linear-gradient(90deg,#0F6B34,#2E9E5B,#0F6B34);background-size:200% 100%;animation:rkm 1.2s linear infinite}
  @keyframes rkm{from{background-position:0 0}to{background-position:200% 0}}
  .rk-tools{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
  .rk-tools button{border:0;border-radius:999px;padding:6px 10px;font:700 12px system-ui;cursor:pointer;background:#eef0f2;color:#14181c}
  .rk-tools button.on{background:#14181c;color:#fff}
  .rk-l{overflow:auto;flex:1;padding:4px 0}
  .rk-r{display:grid;grid-template-columns:26px 44px 1fr;gap:8px;align-items:center;padding:8px 14px;border-bottom:1px solid #f3f4f6;text-decoration:none;color:inherit}
  .rk-r:hover{background:#F4FAF5}
  .rk-r .n{color:#8a9098;font-weight:700;font-size:12px;padding:0;text-align:right}
  .rk-r .sc{width:44px;height:36px;border-radius:10px;display:grid;place-items:center;color:#fff;font:800 16px/1 system-ui}
  .rk-r .d{min-width:0}.rk-r .d b{font-size:13.5px}.rk-r .d span{display:block;color:#5b636b;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .rk-r .d i{font-style:normal;font-weight:800;font-size:11px;padding:1px 5px;border-radius:6px;margin-left:4px}
  .rk-f{padding:8px 14px 12px;font-size:10.5px;color:#7a837e;border-top:1px solid #eef0f2}
  .gate{background:#F4FAF5;border:1px solid #D7EBDC;border-radius:12px;padding:10px;margin:8px 0;font-size:13px}
  `;
  const host = (tag = "span") => { const h = document.createElement(tag); h.setAttribute("data-rhs", "1"); const sh = h.attachShadow({ mode: "open" }); const st = document.createElement("style"); st.textContent = CSS; sh.appendChild(st); return { h, sh }; };
  const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  const SYM = { EUR: "€", GBP: "£", USD: "$", DKK: "kr", SEK: "kr", NOK: "kr", CHF: "CHF", PLN: "zł", CZK: "Kč", HUF: "Ft", JPY: "¥", INR: "₹", AUD: "A$", CAD: "C$", NZD: "NZ$", BRL: "R$", MXN: "MX$", AED: "AED", TRY: "₺", ILS: "₪", ZAR: "R", SGD: "S$", HKD: "HK$", THB: "฿", KRW: "₩" };
  const sym = (c) => SYM[c] || c || "€";
  let state = null;
  async function getState() { state = (await send({ t: "state" })) || { consent: false, quotaLeft: 3, profile: null, email: null }; return state; }

  // ---------------------------------------------------------------- search result pages: one badge per card
  const sent = new Set();
  async function scanCards() {
    const cards = A.cards();
    showFab(cards.length);
    if (!cards.length) return;
    const pp = cards.map((c) => (c.f.price && c.f.sqm ? c.f.price / c.f.sqm : null)).filter(Boolean);
    const bench = RHS.median(pp);
    // Remember these homes (derived numbers only) so any listing opened later has comparables on day one.
    const items = [];
    for (const c of cards) {
      let path = ""; try { path = new URL(c.url).pathname; } catch { continue; }
      if (sent.has(path)) continue; sent.add(path);
      items.push({ h: await RHS.hash(`${A.id}:${path}`), portal: A.id, pp: c.f.price && c.f.sqm ? Math.round(c.f.price / c.f.sqm) : null, cur: c.f.currency,
        lat: c.f.lat ?? null, lng: c.f.lng ?? null, area: c.f.area || "", price: c.f.price, sqm: c.f.sqm, url: c.url.split("?")[0], country: c.f.country });
    }
    if (items.length || (bench && pp.length >= 5)) send({ t: "cards", portal: A.id, bench: pp.length >= 5 ? Math.round(bench) : null, n: pp.length, area: A.areaKey(), items: items.filter((x) => x.pp) });
    for (const c of cards) {
      if (c.el.querySelector("[data-rhs]")) continue; // React may re-render a card and drop our badge: re-add it
      const r = RHS.score({ ...c.f, partial: true }, { bench: pp.length >= 5 ? bench : null, benchN: pp.length, benchSource: "page", profile: state.profile, loc: null });
      const { h, sh } = host();
      const b = document.createElement("span"); b.className = "b"; b.style.background = RHS.color(r.score);
      b.innerHTML = `${r.score}<small>RealHunt</small>${r.pct != null && Math.abs(r.pct) >= 3 ? `<i>${r.pct < 0 ? "−" : "+"}${Math.abs(r.pct)}% ${sym(c.f.currency)}/m²</i>` : ""}`;
      b.title = r.verdict + "\n\n" + r.parts.filter((p) => p.k !== "location").map((p) => `${T("part_" + p.k) || p.label}: ${p.pts}/${p.max}`).join("\n") + "\n" + T("badge_hint") + "\n" + T("disclaimer");
      b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); window.open(c.url, "_blank"); });
      sh.appendChild(b);
      try { (c.mount || c.el).prepend(h); } catch { c.el.prepend(h); }
    }
    if (!scanCards.tracked) { scanCards.tracked = true; send({ t: "track", kind: "badge", meta: { portal: A.id, n: cards.length } }); }
  }

  // ---------------------------------------------------------------- listing pages: score card
  let card = null, cur = null;
  async function showDetail() {
    const f = A.detail();
    if (!f) return;
    if (f.flagsExtra) f.desc = (f.desc || "") + f.flagsExtra;
    const url = location.href.split("?")[0];
    const hash = await RHS.hash(`${A.id}:${location.pathname}`);
    const comps = (await send({ t: "detail", f: { ...f, desc: undefined, title: undefined }, hash })) || {};
    const hasGeo = f.lat != null && f.lng != null;
    const me = (cur = { url, hash, f, ctx: { profile: state.profile, bench: comps.bench, benchN: comps.n, benchSource: comps.source, benchKm: comps.km, official: comps.official, loc: hasGeo ? undefined : null, ai: null }, expanded: false, gate: null });
    const rescore = () => { if (cur !== me) return; me.r = RHS.score(f, me.ctx); renderCard(); };
    rescore();
    const jobs = [];
    if (hasGeo) jobs.push(send({ t: "nearby", lat: f.lat, lng: f.lng }).then((loc) => {
      me.ctx.loc = loc || null; rescore();
      if (!loc) { const p = me.r.parts.find((x) => x.k === "location"); if (p) p.why = T("loc_unavailable"); renderCard(); }
    }));
    if (state.consent && (f.desc || "").length > 60) jobs.push(send({ t: "analyze", hash, text: f.desc, lang: RHS.lang }).then((ai) => { if (ai) { me.ctx.ai = ai; rescore(); } }));
    const report = (first) => { const r = me.r; send({ t: "report", report: { first, hash, url, portal: A.id, price: f.price, currency: f.currency, sqm: f.sqm, rooms: f.rooms, area: f.area, country: f.country, ptype: f.ptype, days: f.days,
      lat: f.lat, lng: f.lng, score: r.score, grade: RHS.grade(r.score), verdict: r.verdict, parts: r.parts, flags: r.flags.map((x) => x.label), plus: r.plus.map((x) => x.label), ppsqm: r.ppsqm, ai: r.ai, final: !r.pending } }); };
    // The side panel and the server get only derived features and the score, never photos or the description.
    report(true); // right away, so saving and the panel work at once
    await Promise.all(jobs);
    if (cur !== me) return;
    report(); // again with location and AI included
  }

  const FREE = { es: "GRATIS", da: "GRATIS", de: "GRATIS", it: "GRATIS", pt: "GRÁTIS" }[RHS.lang] || "FREE";
  function gateHtml(g) {
    if (g.step === "code") return `<div class="gate"><b>${esc(T("code_title"))}</b><br><span>${esc(T("code_sent", [g.email]))}</span>
      <input class="in" id="rh-code" inputmode="numeric" maxlength="6" placeholder="123456" autocomplete="one-time-code">
      <button class="k" data-a="code" style="margin-top:6px">${esc(T("code_cta"))}</button> <button class="k s2" data-a="back" style="margin-top:6px">${esc(T("change_email"))}</button>
      <div class="err">${esc(g.err || "")}</div></div>`;
    return `<div class="gate"><span class="free">${FREE}</span> <b>${esc(T("unlock_title"))}</b><br><span>${esc(T("unlock_body"))}</span>
      <input class="in" id="rh-email" type="email" placeholder="you@email.com" autocomplete="email" value="${esc(g.email || "")}">
      <label class="ck"><input type="checkbox" id="rh-mk" ${g.mk ? "checked" : ""}> ${esc(T("marketing_ok"))}</label>
      <button class="k" data-a="email" style="margin-top:6px;width:100%">${esc(T("unlock_cta"))}</button>
      <div class="fine">${esc(T("unlock_fine"))}</div><div class="err">${esc(g.err || "")}</div></div>`;
  }

  function renderCard() {
    const me = cur; if (!me || !me.r) return;
    const { f, r, hash } = me;
    const keepFocus = card && card.shadowRoot && card.shadowRoot.activeElement && card.shadowRoot.activeElement.id;
    const typed = {}; if (card && card.shadowRoot) for (const id of ["rh-email", "rh-code"]) { const el = card.shadowRoot.getElementById(id); if (el) typed[id] = el.value; }
    if (card) card.remove();
    const { h, sh } = host("div"); card = h;
    const quotaOk = state.email || me.allowed || state.quotaLeft > 0;
    const mini = r.parts.map((p) => `<div class="row${p.pending ? " pend" : ""}"><span>${esc(T("part_" + p.k) || p.label)}</span><div class="bar"><i style="width:${Math.round((p.pts / p.max) * 100)}%;background:${RHS.color((p.pts / p.max) * 100)}"></i></div><b>${p.pending ? "…" : p.pts + "/" + p.max}</b></div>`).join("");
    const rows = me.expanded && quotaOk ? r.parts.map((p) => `<div class="r"><div class="l"><span>${esc(T("part_" + p.k) || p.label)}</span><span>${p.pending ? "…" : p.pts + "/" + p.max}</span></div><p>${esc(p.why)}</p></div>`).join("") : "";
    const gate = me.gate ? gateHtml(me.gate) : (me.expanded && !quotaOk ? gateHtml({}) : "");
    const consentAsk = !state.consent && !me.gate ? `<div class="gate">${esc(T("consent_short"))}<br><button class="k" data-a="consent" style="margin-top:8px">${esc(T("allow"))}</button></div>` : "";
    const nudge = state.consent && !state.email && !me.gate ? `<div class="nudge" data-a="open-gate"><span class="free">${FREE}</span> ${esc(T("nudge"))} →</div>` : "";
    if (state.min && !me.open) {
      const pill = document.createElement("div"); pill.className = "pill"; pill.style.background = RHS.color(r.score);
      pill.innerHTML = `<b>${r.score}</b><span>${RHS.grade(r.score)} · RealHunt</span>`; pill.title = r.verdict;
      pill.addEventListener("click", () => { me.open = true; renderCard(); });
      sh.appendChild(pill); document.documentElement.appendChild(h); return;
    }
    const div = document.createElement("div"); div.className = "c";
    div.innerHTML = `<div class="h"><div class="s" style="background:${RHS.color(r.score)}">${r.score}<small>${RHS.grade(r.score)}</small></div><div class="t"><b>RealHunt Score${r.ai ? ` <span class="ai">AI</span>` : ""}</b><small>${esc(RHS.money(f.price, f.currency))}${f.sqm ? " · " + f.sqm + " m²" : ""}${r.ppsqm ? " · " + RHS.money(r.ppsqm, f.currency) + "/m²" : ""}</small></div><button class="x" data-a="min" aria-label="Minimise" title="Minimise">–</button><button class="x" data-a="close" aria-label="Close">×</button></div>
      <div class="v">${esc(r.verdict)}</div>
      <div class="mini">${mini}</div>
      <div class="p">${rows}${gate}${consentAsk}</div>
      ${nudge}
      <div class="f">${me.expanded ? "" : `<button class="k" data-a="why">${esc(T("see_why"))}</button>`}<button class="k s2" data-a="panel">${esc(T("open_panel"))}</button><button class="k s2" data-a="save">${esc(T("save"))}</button><button class="k s2" data-a="share">${esc(T("share_short"))}</button></div>
      <div class="n">${esc(T("disclaimer"))}</div>`;
    div.addEventListener("click", async (e) => {
      const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return;
      const $ = (id) => sh.getElementById(id);
      if (a === "close") { card.remove(); card = null; cur && (cur.closed = true); }
      if (a === "min") { state.min = true; me.open = false; send({ t: "pref", min: true }); renderCard(); }
      if (a === "why") { const q = await send({ t: "useReport", hash }); state.quotaLeft = q ? q.quotaLeft : state.quotaLeft; me.expanded = true; me.allowed = !!(q && q.allowed); if (!state.email && !me.allowed) { me.gate = { step: "email" }; send({ t: "track", kind: "email_prompt" }); } renderCard(); }
      if (a === "open-gate") { me.gate = { step: "email" }; send({ t: "track", kind: "email_prompt" }); renderCard(); }
      if (a === "panel") { const ok = await send({ t: "openPanel" }); if (!ok) { me.expanded = true; renderCard(); } }
      if (a === "save") { await send({ t: "track", kind: "save", hash, price: f.price }); e.target.textContent = T("saved"); }
      if (a === "share") { await send({ t: "openPanel" }); }
      if (a === "consent") { await send({ t: "consent" }); await getState(); showDetail(); }
      if (a === "back") { me.gate = { step: "email", email: me.gate.email }; renderCard(); }
      if (a === "email") {
        const email = ($("rh-email").value || "").trim(), mk = $("rh-mk").checked;
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { me.gate = { step: "email", email, mk, err: T("bad_email") }; return renderCard(); }
        if (!state.consent) { await send({ t: "consent" }); await getState(); }
        e.target.disabled = true; e.target.textContent = "…";
        const res = await send({ t: "verifyStart", email, lang: RHS.lang });
        me.gate = res && res.ok ? { step: "code", email, mk } : { step: "email", email, mk, err: res && res.error === "wait" ? T("wait_code") : T("try_again") };
        renderCard();
      }
      if (a === "code") {
        const code = ($("rh-code").value || "").replace(/\D/g, "");
        const res = await send({ t: "verifyCheck", code, marketing: !!me.gate.mk });
        if (res && res.ok) { await getState(); me.gate = null; me.expanded = true; renderCard(); send({ t: "track", kind: "lead" }); }
        else { me.gate = { ...me.gate, err: res && res.error === "expired" ? T("code_expired") : T("code_wrong") }; renderCard(); }
      }
    });
    div.addEventListener("keydown", (e) => { if (e.key === "Enter") { const id = e.target.id; if (id === "rh-email") div.querySelector('[data-a="email"]').click(); if (id === "rh-code") div.querySelector('[data-a="code"]').click(); } e.stopPropagation(); });
    sh.appendChild(div);
    document.documentElement.appendChild(h);
    for (const id in typed) { const el = sh.getElementById(id); if (el && !el.value) el.value = typed[id]; }
    if (keepFocus) sh.getElementById(keepFocus)?.focus();
  }


  // ---------------------------------------------------------------- rank the whole search: one click, reads page after page (up to 500)
  const RANK_MAX = 500;
  let rk = null, fab = null;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function showFab(n) {
    if (rk || A.isDetail() || n < 3) { if (fab && (rk || A.isDetail())) { fab.remove(); fab = null; } return; }
    if (fab && fab.isConnected) return;
    const { h, sh } = host("div"); fab = h;
    const b = document.createElement("div"); b.className = "fab";
    b.innerHTML = `<b>⚡</b><div>${esc(T("rank_cta"))}<small>${esc(T("rank_sub"))}</small></div>`;
    b.addEventListener("click", () => { fab.remove(); fab = null; startRank(); });
    sh.appendChild(b); document.documentElement.appendChild(h);
  }
  const keyOf = (u) => { try { const x = new URL(u, location.href); return x.hostname + x.pathname.replace(/\/$/, ""); } catch { return u; } };
  function addItems(list) {
    let fresh = 0;
    for (const c of list) { if (!c || !c.url || !c.f || !c.f.price) continue; const k = keyOf(c.url); if (rk.items.has(k)) continue; rk.items.set(k, { url: c.url.split("#")[0], f: c.f, page: rk.pages + 1 }); fresh++; }
    return fresh;
  }
  function guessNext(u, n) {
    const x = new URL(u); for (const k of ["page", "pag", "pagina", "pn", "p", "pagenumber", "pageNr", "o"]) if (x.searchParams.has(k) && /^\d+$/.test(x.searchParams.get(k))) { x.searchParams.set(k, String(+x.searchParams.get(k) + 1)); return x.href; }
    if ((RHS.recipe && RHS.recipe.pageParam) || n === 1) { x.searchParams.set((RHS.recipe && RHS.recipe.pageParam) || "page", String(n + 1)); return x.href; }
    return null;
  }
  async function toServer(list) {
    const items = [];
    for (const c of list) { let path = ""; try { path = new URL(c.url).pathname; } catch { continue; } if (sent.has(path)) continue; sent.add(path);
      const f = c.f; if (!f.price || !f.sqm) continue;
      items.push({ h: await RHS.hash(`${A.id}:${path}`), portal: A.id, pp: Math.round(f.price / f.sqm), cur: f.currency, lat: f.lat ?? null, lng: f.lng ?? null, area: f.area || "", price: f.price, sqm: f.sqm, url: c.url.split("?")[0], country: f.country }); }
    for (let i = 0; i < items.length; i += 60) send({ t: "cards", rank: true, portal: A.id, area: A.areaKey(), items: items.slice(i, i + 60) });
  }
  async function startRank() {
    rk = { items: new Map(), pages: 0, running: true, stop: false, blocked: false, visited: new Set([keyOf(location.href) + location.search]), onlySqm: false, t0: Date.now() };
    const first = A.cards().map((c) => ({ url: c.url, f: c.f }));
    addItems(first); rk.pages = 1; renderRank(); toServer(first);
    send({ t: "track", kind: "rank_start", meta: { portal: A.id, n: first.length } });
    let url = RHS.nextPageUrl(document, location.href) || (first.length >= 8 ? guessNext(location.href, 1) : null), misses = 0;
    // learn the page-number pattern from page 2's address, so we can keep going when a page shows no "next" link
    const p2 = url; const re2 = /([/=_-]|page|pagina|pag|side|seite)2(?=\/?$|\/?[?&#]|\.\w{2,5}$)/i;
    const tpl = p2 && re2.test(p2) ? (n) => p2.replace(re2, "$1" + n) : null;
    while (url && !rk.stop && rk.pages < RANK_MAX) {
      const vk = keyOf(url) + new URL(url).search; if (rk.visited.has(vk)) break; rk.visited.add(vk);
      rk.loading = rk.pages + 1; renderRank();
      await sleep(1100 + Math.random() * 1400); // polite: about one page every 1-2.5 seconds, like a person clicking "next"
      if (rk.stop) break;
      let html = "";
      try { const res = await fetch(url, { credentials: "include" }); if (res.status === 403 || res.status === 429) { rk.blocked = true; break; } if (!res.ok) break; html = await res.text(); } catch { break; }
      if (html.length < 80000 && /captcha|are you a robot|access denied|px-captcha|cf-chl|datadome|geo\.captcha|unusual traffic/i.test(html)) { rk.blocked = true; break; }
      const doc = new DOMParser().parseFromString(html, "text/html");
      let got = []; try { got = A.cardsFrom(doc, url); } catch { got = []; }
      const fresh = addItems(got); rk.pages++;
      if (!fresh) { if (++misses >= 2) break; } else { misses = 0; toServer(got); }
      renderRank();
      const nx = RHS.nextPageUrl(doc, url);
      url = (nx && !rk.visited.has(keyOf(nx) + new URL(nx).search) ? nx : null) || (tpl ? tpl(rk.pages + 1) : null) || guessNext(url, rk.pages);
    }
    rk.running = false; rk.loading = 0; renderRank();
    send({ t: "track", kind: "rank_done", meta: { portal: A.id, pages: rk.pages, n: rk.items.size, blocked: rk.blocked, secs: Math.round((Date.now() - rk.t0) / 1000) } });
  }
  function ranked() {
    const all = [...rk.items.values()];
    const pp = all.map((x) => (x.f.price && x.f.sqm ? x.f.price / x.f.sqm : null)).filter(Boolean);
    const bench = pp.length >= 5 ? RHS.median(pp) : null;
    const out = all.map((x) => ({ ...x, r: RHS.score({ ...x.f, partial: true }, { bench, benchN: pp.length, benchSource: "page", profile: state.profile, loc: null }) }));
    out.sort((a, b) => b.r.score - a.r.score || (a.r.pct ?? 0) - (b.r.pct ?? 0));
    return { list: rk.onlySqm ? out.filter((x) => x.f.sqm) : out, bench, cur: (all[0] && all[0].f.currency) || "EUR" };
  }
  let rkEl = null, rkT = 0;
  function renderRank(force) {
    if (!rk) return;
    const now = Date.now(); if (!force && rk.running && now - rkT < 350) { clearTimeout(renderRank.t); renderRank.t = setTimeout(() => renderRank(true), 360); return; } rkT = now;
    const scroll = rkEl && rkEl.shadowRoot.querySelector(".rk-l") ? rkEl.shadowRoot.querySelector(".rk-l").scrollTop : 0;
    if (rkEl) rkEl.remove();
    const { h, sh } = host("div"); rkEl = h;
    const { list, bench, cur } = ranked();
    const st = rk.running ? T("rank_loading", [String(rk.loading || rk.pages), String(rk.items.size)]) : rk.blocked ? T("rank_blocked", [String(rk.items.size), String(rk.pages)]) : T("rank_done", [String(rk.items.size), String(rk.pages)]);
    const rows = list.slice(0, 300).map((x, i) => { const f = x.f, r = x.r; const pct = r.pct != null && Math.abs(r.pct) >= 3 ? `<i style="background:${r.pct < 0 ? "#E3F4E8;color:#0F6B34" : "#FBE9E5;color:#C2412D"}">${r.pct < 0 ? "−" : "+"}${Math.abs(r.pct)}%</i>` : "";
      return `<a class="rk-r" href="${esc(x.url)}" target="_blank" rel="noopener"><span class="n">${i + 1}</span><span class="sc" style="background:${RHS.color(r.score)}">${r.score}</span><span class="d"><b>${esc(RHS.money(f.price, f.currency))}</b>${f.sqm ? ` · ${f.sqm} m²` : ""}${f.rooms ? ` · ${f.rooms} ${esc(T("rank_rooms"))}` : ""}${pct}<span>${esc((f.title || f.area || f.desc || "").slice(0, 90))}</span></span></a>`; }).join("");
    const div = document.createElement("div"); div.className = "rk";
    div.innerHTML = `<div class="rk-h"><div class="top"><b>⚡ ${esc(T("rank_title"))}</b><button class="x" data-a="close" aria-label="Close">×</button></div>
      <div class="st">${esc(st)}${bench ? " · " + esc(T("rank_median")) + " " + esc(RHS.money(bench, cur)) + "/m²" : ""}</div>
      <div class="rk-bar${rk.running ? " run" : ""}"><i style="width:${rk.running ? 100 : 100}%"></i></div>
      <div class="rk-tools">${rk.running ? `<button data-a="stop">${esc(T("rank_stop"))}</button>` : ""}<button data-a="sqm" class="${rk.onlySqm ? "on" : ""}">${esc(T("rank_only_sqm"))}</button><button data-a="csv">CSV</button></div></div>
      <div class="rk-l">${rows || `<div class="n" style="padding:14px">${esc(T("rank_empty"))}</div>`}</div>
      <div class="rk-f">${esc(T("rank_fine"))}</div>`;
    div.addEventListener("click", (e) => {
      const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return;
      if (a === "close") { rk.stop = true; rkEl.remove(); rkEl = null; rk = null; return; }
      if (a === "stop") { rk.stop = true; }
      if (a === "sqm") { rk.onlySqm = !rk.onlySqm; renderRank(true); }
      if (a === "csv") { const { list: L } = ranked(); const csv = ["rank,score,price,currency,sqm,price_per_sqm,vs_median_pct,rooms,url", ...L.map((x, i) => [i + 1, x.r.score, x.f.price, x.f.currency, x.f.sqm || "", x.r.ppsqm || "", x.r.pct ?? "", x.f.rooms || "", x.url].join(","))].join("\n");
        const el = document.createElement("a"); el.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); el.download = `realhunt-ranking-${A.id}-${new Date().toISOString().slice(0, 10)}.csv`; el.click(); send({ t: "track", kind: "rank_csv", meta: { n: L.length } }); }
    });
    div.addEventListener("keydown", (e) => e.stopPropagation());
    sh.appendChild(div); document.documentElement.appendChild(h);
    const l = sh.querySelector(".rk-l"); if (l) l.scrollTop = scroll;
  }

  // ---------------------------------------------------------------- run, and re-run on SPA navigation
  let lastUrl = "";
  async function run() {
    if (location.href === lastUrl) return; lastUrl = location.href;
    await getState();
    send({ t: "alive", host: location.hostname });
    if (RHS.recipe === undefined) RHS.recipe = (await send({ t: "recipe", host: location.hostname.replace(/^www\./, "") })) || null;
    try { if (A.isDetail()) await showDetail(); else { if (card) { card.remove(); card = null; } await scanCards(); } } catch (e) { /* never break the page */ }
  }
  run();
  let t = null;
  const ours = (n) => n.nodeType !== 1 || (n.getAttribute && n.getAttribute("data-rhs"));
  new MutationObserver((muts) => { if (muts.every((m) => m.addedNodes.length + m.removedNodes.length > 0 && [...m.addedNodes, ...m.removedNodes].every(ours))) return; clearTimeout(t); t = setTimeout(() => { if (location.href !== lastUrl) { A._list = null; run(); } else if (!A.isDetail()) scanCards(); }, 700); })
    .observe(document.documentElement, { childList: true, subtree: true });
})();
