// RealHunt Score — content script. Runs only on the supported portals (see manifest host list).
(function () {
  const RHS = window.RHS;
  const A = RHS.adapterFor(location.hostname);
  if (!A || window.__rhsLoaded) return;
  window.__rhsLoaded = true;
  const T = (k, subs) => { try { return chrome.i18n.getMessage(k, subs) || k; } catch { return k; } };
  const send = (msg) => new Promise((res) => { try { chrome.runtime.sendMessage(msg, (r) => res(chrome.runtime.lastError ? null : r)); } catch { res(null); } });

  const CSS = `
  :host{all:initial}
  .b{font:700 12px/1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;display:inline-flex;align-items:center;gap:5px;padding:5px 8px;border-radius:999px;color:#fff;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.18);margin:6px 0;user-select:none}
  .b small{font-weight:600;opacity:.85;font-size:10px}
  .c{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:320px;max-height:78vh;overflow:auto;background:#fff;color:#14181c;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.28);font:14px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  .h{display:flex;gap:12px;align-items:center;padding:14px 14px 10px}
  .s{width:58px;height:58px;border-radius:16px;display:grid;place-items:center;color:#fff;font:800 26px/1 system-ui}
  .t b{display:block;font-size:15px}.t small{color:#5b636b}
  .x{margin-left:auto;align-self:flex-start;border:0;background:none;font-size:18px;cursor:pointer;color:#8a9098}
  .p{padding:0 14px 6px}
  .r{margin:8px 0}.r .l{display:flex;justify-content:space-between;font-weight:700;font-size:13px}.r .bar{height:6px;border-radius:4px;background:#eef0f2;margin:4px 0}.r .bar i{display:block;height:100%;border-radius:4px}
  .r p{margin:0;color:#4f5a55;font-size:12.5px}
  .f{padding:10px 14px 14px;display:flex;gap:8px;flex-wrap:wrap}
  button.k{border:0;border-radius:10px;padding:9px 12px;font:700 13px system-ui;cursor:pointer;background:#0F6B34;color:#fff}
  button.k.s2{background:#eef0f2;color:#14181c}
  .n{font-size:11px;color:#8a9098;padding:0 14px 12px}
  .b i{font-style:normal;font-weight:800;font-size:10.5px;background:rgba(255,255,255,.22);border-radius:999px;padding:2px 5px}
  .s{flex-direction:column}
  .s small{display:block;font:800 11px/1 system-ui;opacity:.9;margin-top:3px;color:#fff}
  .v{padding:0 14px 8px;font-weight:700;font-size:13.5px;line-height:1.35}
  .mini{padding:0 14px 6px;display:grid;gap:5px}
  .mini .row{display:grid;grid-template-columns:128px 1fr 38px;gap:8px;align-items:center;font-size:12px;color:#4f5a55}
  .mini .bar{height:6px;border-radius:4px;background:#eef0f2}.mini .bar i{display:block;height:100%;border-radius:4px}
  .mini b{font-size:12px;color:#14181c;text-align:right}
  .pend{opacity:.55}
  .ai{font:800 9.5px/1 system-ui;background:#111;color:#fff;border-radius:6px;padding:3px 5px;vertical-align:2px;margin-left:4px}
  .free{display:inline-block;font:800 10px/1 system-ui;background:#FFE14D;color:#14181c;border-radius:6px;padding:3px 6px;letter-spacing:.04em}
  .nudge{margin:2px 14px 6px;padding:9px 11px;border-radius:12px;background:#14181c;color:#fff;font:700 12.5px/1.35 system-ui;cursor:pointer}
  .in{width:100%;box-sizing:border-box;margin-top:8px;padding:10px 11px;border:1px solid #cfd6d1;border-radius:10px;font:15px system-ui;background:#fff;color:#14181c}
  .ck{display:flex;gap:6px;align-items:flex-start;font-size:11.5px;color:#4f5a55;margin-top:7px}
  .fine{font-size:10.5px;color:#7a837e;margin-top:6px}.err{color:#C2412D;font-size:12px;margin-top:4px}
  .x+.x{margin-left:0}
  .pill{position:fixed;right:16px;bottom:16px;z-index:2147483646;display:flex;align-items:center;gap:8px;padding:8px 14px 8px 8px;border-radius:999px;color:#fff;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.25);font:700 12px/1 system-ui}
  .pill b{background:rgba(255,255,255,.22);border-radius:999px;padding:7px 9px;font:800 16px/1 system-ui}
  .fab{position:fixed;left:16px;bottom:16px;z-index:2147483645;display:flex;align-items:center;gap:8px;padding:10px 16px 10px 10px;border-radius:999px;background:#14181c;color:#fff;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.28);font:700 13px/1.1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  .fab b{background:#FFE14D;color:#14181c;border-radius:999px;width:28px;height:28px;display:grid;place-items:center;font:800 15px/1 system-ui}
  .fab small{display:block;font-weight:600;opacity:.7;font-size:11px;margin-top:2px}
  .rk{position:fixed;left:16px;top:16px;bottom:16px;z-index:2147483646;width:400px;max-width:calc(100vw - 32px);display:flex;flex-direction:column;background:#fff;color:#14181c;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.3);font:13px/1.35 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;overflow:hidden}
  .rk-h{padding:14px 14px 8px;border-bottom:1px solid #eef0f2}
  .rk-h .top{display:flex;align-items:center;gap:8px}.rk-h .top b{font-size:15px}
  .rk-h .st{color:#5b636b;font-size:12px;margin-top:4px}
  .rk-bar{height:4px;background:#eef0f2;border-radius:3px;margin-top:8px;overflow:hidden}.rk-bar i{display:block;height:100%;background:#0F6B34;transition:width .3s}
  .rk-bar.run i{background:linear-gradient(90deg,#0F6B34,#2E9E5B,#0F6B34);background-size:200% 100%;animation:rkm 1.2s linear infinite}
  @keyframes rkm{from{background-position:0 0}to{background-position:200% 0}}
  .rk-tools{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
  .rk-tools button{border:0;border-radius:999px;padding:6px 10px;font:700 12px system-ui;cursor:pointer;background:#eef0f2;color:#14181c}
  .rk-tools button.on{background:#14181c;color:#fff}
  .rk-l{overflow:auto;flex:1;padding:4px 0}
  .rk-filt{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;font-size:11px;color:#4f5a55;align-items:center}
  .rk-filt label{display:flex;gap:3px;align-items:center}.rk-filt input{width:62px;border:1px solid #cfd6d1;border-radius:6px;padding:3px 4px;font:12px system-ui}
  .rk-filt select{border:1px solid #cfd6d1;border-radius:6px;padding:3px 4px;font:12px system-ui;margin-left:auto}
  .cta.sm2{margin:8px 0 0;padding:9px 12px;font-size:13px}
  .rk-r{display:grid;grid-template-columns:26px 44px 1fr;gap:8px;align-items:center;padding:8px 14px;border-bottom:1px solid #f3f4f6;text-decoration:none;color:inherit}
  .rk-r:hover{background:#F4FAF5}
  .rk-r .n{color:#8a9098;font-weight:700;font-size:12px;padding:0;text-align:right}
  .rk-r .sc{width:44px;height:36px;border-radius:10px;display:grid;place-items:center;color:#fff;font:800 16px/1 system-ui}
  .rk-r .d{min-width:0}.rk-r .d b{font-size:13.5px}.rk-r .d span{display:block;color:#5b636b;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .rk-r .d i{font-style:normal;font-weight:800;font-size:11px;padding:1px 5px;border-radius:6px;margin-left:4px}
  .rk-f{padding:8px 14px 12px;font-size:10.5px;color:#7a837e;border-top:1px solid #eef0f2}

  .c.v5{width:372px;display:flex;flex-direction:column;max-height:84vh;overflow:hidden}
  .v5 .h{cursor:grab;user-select:none}
  .v5 .body{overflow:auto;flex:1;padding-bottom:4px}
  .ld{height:3px;margin:0 14px;border-radius:2px;background:linear-gradient(90deg,#0F6B34,#2E9E5B,#FFE14D,#0F6B34);background-size:300% 100%;animation:rkm 1.4s linear infinite}
  .sum{margin:0 14px 8px;font-size:12.5px;color:#4f5a55}
  .blocks{display:grid;gap:8px;padding:0 12px}
  .blk{background:#F7F8F9;border-radius:14px;padding:10px 12px;position:relative;animation:fin .35s ease}
  @keyframes fin{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
  .blk h4{margin:0 0 6px;font:800 12.5px/1.2 system-ui;color:#14181c;display:flex;gap:6px;align-items:center}
  .blk h4 em{font-style:normal;font-weight:700;font-size:10px;background:#E8ECEA;border-radius:6px;padding:2px 5px;color:#4f5a55;margin-left:auto}
  .blk p{margin:4px 0 0;font-size:12.5px}.blk .mut,.mut{color:#6b746f;font-size:11.5px}
  .blk .big{font:800 22px/1.1 system-ui}
  .pos{color:#0F6B34}.neg{color:#C2412D}
  .two{display:grid;grid-template-columns:1fr 1fr;gap:8px}.two small{display:block;color:#6b746f;font-size:11px}.two b{font:800 16px/1.2 system-ui}
  .calc{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;font-size:11px;color:#4f5a55}.calc input{width:46px;border:1px solid #cfd6d1;border-radius:6px;padding:3px 4px;font:12px system-ui;background:#fff;color:#14181c}
  .hist,.lk,.qs{margin:2px 0 0;padding-left:16px;font-size:12.5px}.hist{list-style:none;padding:0}.hist li{display:flex;gap:8px}.hist span{color:#6b746f;min-width:58px}
  .hist em,.lk em{font-style:normal;font-weight:800;font-size:11px}
  .lk li{margin:3px 0}.lk a{color:#0F6B34;font-weight:700;text-decoration:none}.lk small{color:#6b746f}
  .chips{display:flex;flex-wrap:wrap;gap:5px}.chips span{background:#fff;border-radius:999px;padding:3px 8px;font-size:11.5px}.chips span.off{opacity:.45}
  .k.sm{padding:6px 9px;font-size:12px;margin-top:6px}
  .sk i{display:block;height:10px;border-radius:5px;margin:6px 0;background:linear-gradient(90deg,#e9ecee,#f6f7f8,#e9ecee);background-size:200% 100%;animation:rkm 1.2s linear infinite}.sk i+i{width:60%}
  .blk.lock>*:not(h4){filter:blur(4px);pointer-events:none;user-select:none}
  .unlock{margin:8px 12px 0;padding:10px 12px;border-radius:12px;background:#14181c;color:#fff;font:700 12.5px/1.35 system-ui;cursor:pointer}
  .cta{display:block;margin:10px 12px 4px;padding:12px 14px;border-radius:14px;background:linear-gradient(135deg,#0F6B34,#2E9E5B);color:#fff;font:800 14px/1.25 system-ui;text-decoration:none;text-align:center;box-shadow:0 6px 16px rgba(15,107,52,.25)}
  .v5 .f{flex-wrap:nowrap;gap:6px;padding:8px 12px 10px}.v5 .f button.k{padding:8px 9px;font-size:12px;white-space:nowrap}.v5 .cta{margin:8px 12px 0}
  .det{margin:8px 12px 0}.det summary{cursor:pointer;font:700 12.5px system-ui;color:#4f5a55;padding:6px 2px}
  .onb{margin:0 12px 8px;padding:10px 12px;border-radius:12px;background:#FFF8D6;font-size:12px}.onb ol{margin:4px 0;padding-left:18px}

  .gate{background:#F4FAF5;border:1px solid #D7EBDC;border-radius:12px;padding:10px;margin:8px 0;font-size:13px}
  @media (prefers-color-scheme: dark){
    .c,.rk{background:#15191c;color:#e8ecea}.blk{background:#1f2428}.blk h4{color:#e8ecea}.blk h4 em{background:#2a3036;color:#b6bfba}
    .mut,.blk .mut,.two small,.hist span,.lk small,.r p,.mini .row,.n,.sum,.st{color:#9aa49f}.chips span{background:#2a3036}.calc input{background:#1f2428;color:#e8ecea;border-color:#3a4148}
    button.k.s2,.rk-tools button{background:#2a3036;color:#e8ecea}.mini .bar,.r .bar,.rk-bar{background:#2a3036}.rk-r:hover{background:#1f2428}.rk-h,.rk-f{border-color:#2a3036}.rk-r{border-color:#22272b}
    .gate{background:#1c2a22;border-color:#24402e}.onb{background:#3a3315}.in{background:#1f2428;color:#e8ecea;border-color:#3a4148}.pos{color:#4fd18a}.neg{color:#ff8a73}.rk-filt input,.rk-filt select{background:#1f2428;color:#e8ecea;border-color:#3a4148}
  }  `;
  const host = (tag = "span") => { const h = document.createElement(tag); h.setAttribute("data-rhs", "1"); const sh = h.attachShadow({ mode: "open" }); const st = document.createElement("style"); st.textContent = CSS; sh.appendChild(st); return { h, sh }; };
  const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  const SYM = { EUR: "€", GBP: "£", USD: "$", DKK: "kr", SEK: "kr", NOK: "kr", CHF: "CHF", PLN: "zł", CZK: "Kč", HUF: "Ft", JPY: "¥", INR: "₹", AUD: "A$", CAD: "C$", NZD: "NZ$", BRL: "R$", MXN: "MX$", AED: "AED", TRY: "₺", ILS: "₪", ZAR: "R", SGD: "S$", HKD: "HK$", THB: "฿", KRW: "₩" };
  const sym = (c) => SYM[c] || c || "€";
  let state = null;
  async function getState() { state = (await send({ t: "state" })) || { consent: false, quotaLeft: 3, profile: null, email: null }; return state; }

  // ---------------------------------------------------------------- search result pages: one badge per card
  const sent = new Set();
  async function scanCards() {
    const cards = A.cards();
    showFab(cards.length);
    if (!cards.length) return;
    const pp = cards.map((c) => (c.f.price && c.f.sqm ? c.f.price / c.f.sqm : null)).filter(Boolean);
    const bench = RHS.median(pp);
    // Remember these homes (derived numbers only) so any listing opened later has comparables on day one.
    const items = [];
    for (const c of cards) {
      let path = ""; try { path = new URL(c.url).pathname; } catch { continue; }
      if (sent.has(path)) continue; sent.add(path);
      items.push({ h: await RHS.hash(`${A.id}:${path}`), portal: A.id, pp: c.f.price && c.f.sqm ? Math.round(c.f.price / c.f.sqm) : null, cur: c.f.currency, rooms: c.f.rooms || null,
        lat: c.f.lat ?? null, lng: c.f.lng ?? null, area: c.f.area || "", price: c.f.price, sqm: c.f.sqm, url: c.url.split("?")[0], country: c.f.country });
    }
    if (items.length || (bench && pp.length >= 5)) send({ t: "cards", portal: A.id, bench: pp.length >= 5 ? Math.round(bench) : null, n: pp.length, area: A.areaKey(), city: cityHint(null), items: items.filter((x) => x.pp) });
    for (const c of cards) {
      if (c.el.querySelector("[data-rhs]")) continue; // React may re-render a card and drop our badge: re-add it
      const r = RHS.score({ ...c.f, partial: true }, { bench: pp.length >= 5 ? bench : null, benchN: pp.length, benchSource: "page", profile: state.profile, loc: null });
      const { h, sh } = host();
      const b = document.createElement("span"); b.className = "b"; b.style.background = RHS.color(r.score);
      b.innerHTML = `${r.score}<small>RealHunt</small>${r.pct != null && Math.abs(r.pct) >= 3 ? `<i>${r.pct < 0 ? "−" : "+"}${Math.abs(r.pct)}% ${sym(c.f.currency)}/m²</i>` : ""}`;
      b.title = r.verdict + "\n\n" + r.parts.filter((p) => p.k !== "location").map((p) => `${T("part_" + p.k) || p.label}: ${p.pts}/${p.max}`).join("\n") + "\n" + T("badge_hint") + "\n" + T("disclaimer");
      b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); window.open(c.url, "_blank"); });
      sh.appendChild(b);
      try { (c.mount || c.el).prepend(h); } catch { c.el.prepend(h); }
    }
    if (!scanCards.tracked) { scanCards.tracked = true; send({ t: "track", kind: "badge", meta: { portal: A.id, n: cards.length } }); }
  }

  // ---------------------------------------------------------------- listing pages: the smart card (v0.5)
  // Opens at once with the score, then fills block by block as data arrives: comparables, our server (history,
  // duplicates, city, better options), the map and the AI reading. Every block has a reason; nothing is invented.
  let card = null, cur = null, prefs = {};
  const cityHint = (f) => [f && (f.city || f.province || f.area), (document.querySelector("h1") || {}).textContent || "", decodeURIComponent(location.pathname)].filter(Boolean).join(" ").replace(/\s+/g, " ").slice(0, 200);
  async function showDetail() {
    const f = A.detail();
    if (!f) return;
    if (f.flagsExtra) f.desc = (f.desc || "") + f.flagsExtra;
    prefs = (await send({ t: "prefs" })) || {};
    const url = location.href.split("?")[0];
    const hash = await RHS.hash(`${A.id}:${location.pathname}`);
    const comps = (await send({ t: "detail", f: { ...f, desc: undefined, title: undefined }, hash })) || {};
    const hasGeo = f.lat != null && f.lng != null;
    const me = (cur = { url, hash, f, comps, ins: state.consent ? undefined : null, ctx: { profile: state.profile, bench: comps.bench, benchN: comps.n, benchSource: comps.source, benchKm: comps.km, official: comps.official, loc: hasGeo ? undefined : null, ai: null }, expanded: false, gate: null, open: !state.min });
    const rescore = () => { if (cur !== me) return; me.r = RHS.score(f, me.ctx); renderCard(); };
    rescore();
    const q = await send({ t: "useReport", hash }); // the first full report of the day is free; after that, with a free email
    me.allowed = !!(q && q.allowed); state.quotaLeft = q ? q.quotaLeft : state.quotaLeft;
    const jobs = [];
    if (hasGeo) jobs.push(send({ t: "nearby", lat: f.lat, lng: f.lng }).then((loc) => { me.ctx.loc = loc || null; rescore(); }));
    if (state.consent) jobs.push(send({ t: "insights", p: { hash, lat: f.lat, lng: f.lng, price: f.price, sqm: f.sqm, rooms: f.rooms, currency: f.currency, country: f.country, city: cityHint(f), area: f.area, url, portal: A.id } }).then((ins) => {
      me.ins = ins || null;
      const b = RHS.bestBench(comps, ins);
      if (b) Object.assign(me.ctx, { bench: b.bench, benchN: b.n, benchSource: b.source, benchKm: b.km });
      rescore();
    }));
    if (state.consent && (f.desc || "").length > 60) jobs.push(send({ t: "analyze", hash, text: f.desc, lang: RHS.lang }).then((ai) => { me.aiDone = true; if (ai) me.ctx.ai = ai; rescore(); }));
    const report = (first) => { const r = me.r; send({ t: "report", report: { first, hash, url, portal: A.id, price: f.price, currency: f.currency, sqm: f.sqm, rooms: f.rooms, area: f.area, country: f.country, ptype: f.ptype, days: f.days, city: cityHint(f),
      lat: f.lat, lng: f.lng, score: r.score, grade: RHS.grade(r.score), verdict: r.verdict, parts: r.parts, flags: r.flags.map((x) => x.label), plus: r.plus.map((x) => x.label), ppsqm: r.ppsqm, ai: r.ai, final: !r.pending } }); };
    report(true);
    await Promise.all(jobs);
    if (cur !== me) return;
    report();
  }

  const FREE = { es: "GRATIS", da: "GRATIS", de: "GRATIS", it: "GRATIS", pt: "GRÁTIS", fr: "GRATUIT", nl: "GRATIS", sv: "GRATIS", nb: "GRATIS" }[RHS.lang] || "FREE";
  function gateHtml(g) {
    if (g.step === "code") return `<div class="gate"><b>${esc(T("code_title"))}</b><br><span>${esc(T("code_sent", [g.email]))}</span>
      <input class="in" id="rh-code" inputmode="numeric" maxlength="6" placeholder="123456" autocomplete="one-time-code">
      <button class="k" data-a="code" style="margin-top:6px">${esc(T("code_cta"))}</button> <button class="k s2" data-a="back" style="margin-top:6px">${esc(T("change_email"))}</button>
      <div class="err">${esc(g.err || "")}</div></div>`;
    return `<div class="gate"><span class="free">${FREE}</span> <b>${esc(T("unlock_title"))}</b><br><span>${esc(T("unlock_body"))}</span>
      <input class="in" id="rh-email" type="email" placeholder="you@email.com" autocomplete="email" value="${esc(g.email || "")}">
      <label class="ck"><input type="checkbox" id="rh-mk" ${g.mk ? "checked" : ""}> ${esc(T("marketing_ok"))}</label>
      <button class="k" data-a="email" style="margin-top:6px;width:100%">${esc(T("unlock_cta"))}</button>
      <div class="fine">${esc(T("unlock_fine"))}</div><div class="err">${esc(g.err || "")}</div></div>`;
  }
  const M = (n, c) => RHS.money(n, c);
  const skel = `<div class="sk"><i></i><i></i></div>`;
  function blk(id, title, body, opt = {}) {
    return `<section class="blk${opt.lock ? " lock" : ""}${opt.wide ? " wide" : ""}" data-b="${id}"><h4>${opt.icon || ""} ${esc(title)}${opt.badge ? ` <em>${esc(opt.badge)}</em>` : ""}</h4>${body}</section>`;
  }

  function blocksHtml(me) {
    const { f, r, ins } = me; const cc = f.country || RHS.siteCountry(location.hostname) || "";
    const bench = me.ctx.bench; const hist = ins && ins.history; const offer = RHS.offer(f, bench, hist);
    const out = [];
    // 1. price in money
    if (bench && f.sqm) {
      const d = offer.diff, pct = r.pct;
      const src = me.ctx.benchSource === "near" ? T("src_near", [String(me.ctx.benchN), String(me.ctx.benchKm || 2)]) : me.ctx.benchSource === "area" ? T("src_area", [String(me.ctx.benchN)]) : T("src_page", [String(me.ctx.benchN)]);
      out.push(blk("price", T("b_price"), `<div class="big ${d > 0 ? "neg" : "pos"}">${d > 0 ? "+" : "−"}${esc(M(Math.abs(d), f.currency))}</div><p>${esc(T(d > 0 ? "price_over" : "price_under", [String(Math.abs(pct || 0))]))}</p><p class="mut">${esc(T("fair_value"))}: <b>${esc(M(offer.fair, f.currency))}</b> · ${esc(src)}</p>`, { icon: "€" }));
    } else if (me.ins === undefined || me.ctx.loc === undefined) out.push(blk("price", T("b_price"), skel, { icon: "€" }));
    else out.push(blk("price", T("b_price"), `<p class="mut">${esc(T("price_nocomps"))}</p>`, { icon: "€" }));
    // 2. what to offer
    if (offer) out.push(blk("offer", T("b_offer"), `<div class="two"><div><small>${esc(T("offer_open"))}</small><b>${esc(M(offer.open, f.currency))}</b></div><div><small>${esc(T("offer_max"))}</small><b>${esc(M(offer.max, f.currency))}</b></div></div><p class="mut">${esc(T(offer.hasFair ? (offer.stale ? "offer_why_stale" : "offer_why") : "offer_why_nocomps"))}</p><button class="k s2 sm" data-a="haggle">✉ ${esc(T("haggle"))}</button>`, { icon: "🤝", badge: T("estimate") }));
    const lock = !(state.email || me.allowed);
    // 3. monthly cost and rent
    const c = prefs.calc || {}; const mo = RHS.monthly(f.price, cc, c); const re = RHS.rent(f.price, cc, c.yield);
    if (mo) out.push(blk("cost", T("b_cost"), `<div class="two"><div><small>${esc(T("cost_month"))}</small><b>${esc(M(mo.pay, f.currency))}</b></div><div><small>${esc(T("cost_cash"))}</small><b>${esc(M(mo.cash, f.currency))}</b></div></div>
      <div class="calc"><label>${esc(T("cost_down"))} <input type="number" min="0" max="100" step="5" data-c="down" value="${mo.down}">%</label><label>${esc(T("cost_rate"))} <input type="number" min="0" max="20" step="0.1" data-c="rate" value="${mo.rate}">%</label><label>${esc(T("cost_years"))} <input type="number" min="5" max="40" step="1" data-c="years" value="${mo.years}"></label></div>
      <p class="mut">${esc(T("cost_note", [String(mo.costsPct)]))}</p>
      ${re ? `<p>${esc(T("rent_line", [M(re.month, f.currency), String(re.yield)]))}${mo.pay ? ` ${esc(T(re.month >= mo.pay ? "rent_covers" : "rent_short"))}` : ""}</p>` : ""}`, { icon: "🏦", badge: T("estimate"), lock }));
    // 4. price history and time on the market
    const hb = [];
    if (hist === undefined && me.ins === undefined) hb.push(skel);
    else {
      if (hist && hist.length > 1) hb.push(`<ul class="hist">${hist.slice(-5).map((h, i, a) => `<li><span>${esc(new Date(h.t).toLocaleDateString(RHS.lang, { day: "numeric", month: "short" }))}</span><b>${esc(M(h.price, f.currency))}</b>${i && h.price < a[i - 1].price ? ` <em class="pos">▼ ${Math.round((1 - h.price / a[i - 1].price) * 100)}%</em>` : i && h.price > a[i - 1].price ? ` <em class="neg">▲</em>` : ""}</li>`).join("")}</ul>`);
      else hb.push(`<p class="mut">${esc(T(hist && hist.length === 1 ? "hist_one" : "hist_none"))}</p>`);
      if (f.days != null) hb.push(`<p>${esc(T("days_listed", [String(f.days)]))}</p>`);
    }
    out.push(blk("hist", T("b_hist"), hb.join(""), { icon: "📈", lock }));
    // 5. same home elsewhere
    const dups = ins && ins.dups;
    if (me.ins === undefined) out.push(blk("dups", T("b_dups"), skel, { icon: "🔁", lock }));
    else if (dups && dups.length) out.push(blk("dups", T("b_dups"), `<ul class="lk">${dups.map((d) => `<li><a href="${esc(d.url)}" target="_blank" rel="noopener">${esc(RHS.portalName(d.portal))}</a> <b>${esc(M(d.price, f.currency))}</b>${d.price < f.price ? ` <em class="pos">−${esc(M(f.price - d.price, f.currency))}</em>` : ""}</li>`).join("")}</ul>`, { icon: "🔁", lock }));
    else if (ins) out.push(blk("dups", T("b_dups"), `<p class="mut">${esc(T("dups_none"))}</p>`, { icon: "🔁", lock }));
    // 6. within a walk
    const loc = me.ctx.loc;
    if (loc === undefined) out.push(blk("walk", T("b_walk"), skel, { icon: "🚶", lock }));
    else if (loc) {
      const it = [["transit", "🚌"], ["shop", "🛒"], ["school", "🏫"], ["health", "💊"], ["park", "🌳"], ["beach", "🏖"]].filter(([k]) => loc[k] != null);
      out.push(blk("walk", T("b_walk"), `<div class="chips">${it.map(([k, i]) => `<span class="${loc[k] > 0 ? "" : "off"}">${i} ${loc[k] >= 10 ? "10+" : loc[k]} ${esc(T("w_" + k))}</span>`).join("")}</div><p class="mut">OpenStreetMap · 800 m</p>`, { icon: "🚶", lock }));
    }
    // 7. size check and questions for the agent
    const sz = RHS.sizeNote(f);
    const qs = RHS.questions(f, r);
    out.push(blk("ask", T("b_ask"), `${sz ? `<p class="${sz.k === "small" ? "neg" : "pos"}">${esc(T("size_" + sz.k, [String(f.rooms), String(sz.per)]))}</p>` : ""}<ol class="qs">${qs.map((k) => `<li>${esc(T(k))}</li>`).join("")}</ol><button class="k s2 sm" data-a="copyq">⧉ ${esc(T("copy_questions"))}</button>`, { icon: "❓", lock }));
    // 8. better options in the same city
    const alts = ins && ins.alts;
    if (alts && alts.length) out.push(blk("alts", T("b_alts", [ins.city ? ins.city.name : ""]), `<ul class="lk">${alts.map((a) => `<li><a href="${esc(a.url)}" target="_blank" rel="noopener">${esc(M(a.price, f.currency))} · ${esc(a.sqm)} m²${a.rooms ? " · " + a.rooms + " " + esc(T("rank_rooms")) : ""}</a> <em class="pos">${esc(M(a.ppsqm, f.currency))}/m²</em>${a.area ? `<br><small>${esc(a.area)} · ${esc(RHS.portalName(a.portal))}</small>` : ""}</li>`).join("")}</ul>`, { icon: "✨", lock }));
    // 9. the city on RealHunt
    if (ins && ins.city && ins.city.median) out.push(blk("city", T("b_city", [ins.city.name]), `<p>${esc(T("city_line", [M(ins.city.median, f.currency), String(ins.city.n)]))}${ins.city.trend != null ? ` · <b class="${ins.city.trend > 0 ? "neg" : "pos"}">${ins.city.trend > 0 ? "▲" : "▼"} ${Math.abs(ins.city.trend)}%</b> ${esc(T("city_trend"))}` : ""}</p>`, { icon: "🏙" }));
    return out.join("");
  }

  function siteLink(me) {
    const c = me.ins && me.ins.city;
    const u = (c ? c.url : "https://realhunt.co/best") + "?utm_source=extension&utm_medium=card&utm_campaign=" + encodeURIComponent(A.id);
    return `<a class="cta" href="${esc(u)}" target="_blank" rel="noopener" data-a="site">🏆 ${esc(c ? T("top10_city", [c.name]) : T("top10_any"))} →</a>`;
  }

  async function haggleText(me) {
    const { f, r } = me; const o = RHS.offer(f, me.ctx.bench, me.ins && me.ins.history);
    return T("haggle_body", [M(o.open, f.currency), r.pct != null && r.pct > 0 ? T("haggle_arg_over", [String(r.pct)]) : T("haggle_arg_gen"), location.href.split("?")[0]]);
  }
  async function copy(text) { try { await navigator.clipboard.writeText(text); return true; } catch { return false; } }

  function renderCard() {
    const me = cur; if (!me || !me.r) return;
    const { f, r, hash } = me;
    const keepFocus = card && card.shadowRoot && card.shadowRoot.activeElement && card.shadowRoot.activeElement.id;
    const scroll = card && card.shadowRoot && card.shadowRoot.querySelector(".body") ? card.shadowRoot.querySelector(".body").scrollTop : 0;
    const typed = {}; if (card && card.shadowRoot) for (const id of ["rh-email", "rh-code"]) { const el = card.shadowRoot.getElementById(id); if (el) typed[id] = el.value; }
    if (card) card.remove();
    const { h, sh } = host("div"); card = h;
    if (!me.open) {
      const pill = document.createElement("div"); pill.className = "pill"; pill.style.background = RHS.color(r.score);
      pill.innerHTML = `<b>${r.score}</b><span>${RHS.grade(r.score)} · RealHunt</span>`; pill.title = r.verdict + "  (Alt+Shift+R)";
      pill.addEventListener("click", () => { me.open = true; state.min = false; send({ t: "pref", min: false }); renderCard(); });
      sh.appendChild(pill); document.documentElement.appendChild(h); return;
    }
    const quotaOk = state.email || me.allowed;
    const mini = r.parts.map((p) => `<div class="row${p.pending ? " pend" : ""}"><span>${esc(T("part_" + p.k) || p.label)}</span><div class="bar"><i style="width:${Math.round((p.pts / p.max) * 100)}%;background:${RHS.color((p.pts / p.max) * 100)}"></i></div><b>${p.pending ? "…" : p.pts + "/" + p.max}</b></div>`).join("");
    const rows = me.expanded && quotaOk ? r.parts.map((p) => `<div class="r"><div class="l"><span>${esc(T("part_" + p.k) || p.label)}</span><span>${p.pending ? "…" : p.pts + "/" + p.max}</span></div><p>${esc(p.why)}</p></div>`).join("") : "";
    const gate = me.gate ? gateHtml(me.gate) : "";
    const consentAsk = !state.consent && !me.gate ? `<div class="gate">${esc(T("consent_short"))}<br><span class="mut">${esc(T("consent_more"))}</span><br><button class="k" data-a="consent" style="margin-top:8px">${esc(T("allow"))}</button></div>` : "";
    const locked = !quotaOk && !me.gate ? `<div class="unlock" data-a="open-gate"><span class="free">${FREE}</span> ${esc(T("unlock_blocks"))} →</div>` : "";
    const bits = RHS.summaryBits(r, { f, offer: RHS.offer(f, me.ctx.bench, me.ins && me.ins.history), hist: me.ins && me.ins.history, dups: me.ins && me.ins.dups, size: RHS.sizeNote(f) });
    const sum = bits.length ? `<div class="sum">${bits.map((b) => esc(T(b.k, b.v))).join(" · ")}</div>` : "";
    const loading = me.ins === undefined || me.ctx.loc === undefined || (state.consent && !me.ctx.ai && (f.desc || "").length > 60 && !me.aiDone);
    const onb = !prefs.onb ? `<div class="onb"><b>${esc(T("onb_title"))}</b><ol><li>${esc(T("onb_1"))}</li><li>${esc(T("onb_2"))}</li><li>${esc(T("onb_3"))}</li></ol><button class="k sm" data-a="onb">${esc(T("onb_ok"))}</button></div>` : "";
    const div = document.createElement("div"); div.className = "c v5";
    if (prefs.pos) { div.style.left = prefs.pos.x + "px"; div.style.top = prefs.pos.y + "px"; div.style.right = "auto"; div.style.bottom = "auto"; }
    div.innerHTML = `<div class="h" data-drag="1"><div class="s" style="background:${RHS.color(r.score)}">${r.score}<small>${RHS.grade(r.score)}</small></div><div class="t"><b>RealHunt Score${r.ai ? ` <span class="ai">AI</span>` : ""}</b><small>${esc(M(f.price, f.currency))}${f.sqm ? " · " + f.sqm + " m²" : ""}${r.ppsqm ? " · " + esc(M(r.ppsqm, f.currency)) + "/m²" : ""}</small></div><button class="x" data-a="min" aria-label="Minimise" title="Minimise (Alt+Shift+R)">–</button><button class="x" data-a="close" aria-label="Close">×</button></div>
      ${loading ? `<div class="ld"><i></i></div>` : ""}
      <div class="body">
      <div class="v">${esc(r.verdict)}</div>${sum}
      ${onb}${consentAsk}
      <div class="blocks">${blocksHtml(me)}</div>
      ${locked}${gate ? `<div class="p">${gate}</div>` : ""}
      <details class="det"${me.expanded ? " open" : ""}><summary>${esc(T("see_why"))}</summary><div class="mini">${mini}</div><div class="p">${rows}</div></details>
      </div>
      ${siteLink(me)}
      <div class="f"><button class="k s2" data-a="save">♡ ${esc(T("save"))}</button><button class="k s2" data-a="cmp">⇄ ${esc(T("compare"))}${me.cmpN ? ` (${me.cmpN})` : ""}</button><button class="k s2" data-a="share">${esc(T("share_short"))}</button><button class="k s2" data-a="panel">${esc(T("open_panel"))}</button></div>
      <div class="n">${esc(T("disclaimer"))}</div>`;
    div.addEventListener("toggle", (e) => { if (e.target.classList && e.target.classList.contains("det")) { me.expanded = e.target.open; if (me.expanded && !quotaOk && !me.gate) { me.gate = { step: "email" }; send({ t: "track", kind: "email_prompt" }); renderCard(); } } }, true);
    div.addEventListener("change", (e) => {
      const k = e.target.dataset && e.target.dataset.c; if (!k) return;
      prefs.calc = { ...(prefs.calc || {}), [k]: Number(e.target.value) }; send({ t: "pref", calc: prefs.calc }); renderCard();
    });
    div.addEventListener("click", async (e) => {
      const el = e.target.closest("[data-a]"); const a = el && el.dataset.a; if (!a) return;
      const $ = (id) => sh.getElementById(id);
      if (a === "site") { send({ t: "track", kind: "to_site", meta: { where: "card", city: me.ins && me.ins.city ? me.ins.city.slug : "" } }); return; }
      if (a === "close") { card.remove(); card = null; cur && (cur.closed = true); }
      if (a === "min") { state.min = true; me.open = false; send({ t: "pref", min: true }); renderCard(); }
      if (a === "onb") { prefs.onb = true; send({ t: "pref", onb: true }); renderCard(); }
      if (a === "open-gate") { me.gate = { step: "email" }; send({ t: "track", kind: "email_prompt" }); renderCard(); }
      if (a === "panel") { const ok = await send({ t: "openPanel" }); if (!ok) { me.expanded = true; renderCard(); } }
      if (a === "save") { await send({ t: "track", kind: "save", hash, price: f.price }); el.textContent = "♥ " + T("saved"); }
      if (a === "share") { await send({ t: "openPanel" }); }
      if (a === "cmp") {
        const res = await send({ t: "compare", op: "add", item: { url: me.url, portal: A.id, price: f.price, cur: f.currency, sqm: f.sqm, rooms: f.rooms, score: r.score, pct: r.pct, area: f.area } });
        const n = res && res.list ? res.list.length : 1; me.cmpN = n;
        if (n >= 2 && me.cmpReady) { await send({ t: "compare", op: "open" }); me.cmpReady = false; }
        else { me.cmpReady = n >= 2; renderCard(); }
      }
      if (a === "haggle") { const ok = await copy(await haggleText(me)); el.textContent = ok ? "✓ " + T("copied") : T("try_again"); send({ t: "track", kind: "haggle" }); }
      if (a === "copyq") { const ok = await copy(RHS.questions(f, r).map((k, i) => `${i + 1}. ${T(k)}`).join("\n")); el.textContent = ok ? "✓ " + T("copied") : T("try_again"); }
      if (a === "consent") { await send({ t: "consent" }); await getState(); showDetail(); }
      if (a === "back") { me.gate = { step: "email", email: me.gate.email }; renderCard(); }
      if (a === "email") {
        const email = ($("rh-email").value || "").trim(), mk = $("rh-mk").checked;
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { me.gate = { step: "email", email, mk, err: T("bad_email") }; return renderCard(); }
        if (!state.consent) { await send({ t: "consent" }); await getState(); }
        el.disabled = true; el.textContent = "…";
        const res = await send({ t: "verifyStart", email, lang: RHS.lang });
        me.gate = res && res.ok ? { step: "code", email, mk } : { step: "email", email, mk, err: res && res.error === "wait" ? T("wait_code") : T("try_again") };
        renderCard();
      }
      if (a === "code") {
        const code = ($("rh-code").value || "").replace(/\D/g, "");
        const res = await send({ t: "verifyCheck", code, marketing: !!me.gate.mk });
        if (res && res.ok) { await getState(); me.gate = null; me.expanded = true; renderCard(); send({ t: "track", kind: "lead" }); }
        else { me.gate = { ...me.gate, err: res && res.error === "expired" ? T("code_expired") : T("code_wrong") }; renderCard(); }
      }
    });
    // drag the card by its header; the position is remembered
    div.querySelector("[data-drag]").addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      const r0 = div.getBoundingClientRect(), dx = e.clientX - r0.left, dy = e.clientY - r0.top;
      const mv = (ev) => { const x = Math.max(0, Math.min(innerWidth - 120, ev.clientX - dx)), y = Math.max(0, Math.min(innerHeight - 60, ev.clientY - dy)); Object.assign(div.style, { left: x + "px", top: y + "px", right: "auto", bottom: "auto" }); };
      const up = () => { removeEventListener("pointermove", mv); removeEventListener("pointerup", up); const b = div.getBoundingClientRect(); prefs.pos = { x: Math.round(b.left), y: Math.round(b.top) }; send({ t: "pref", pos: prefs.pos }); };
      addEventListener("pointermove", mv); addEventListener("pointerup", up);
    });
    div.querySelector("[data-drag]").addEventListener("dblclick", () => { prefs.pos = null; send({ t: "pref", pos: null }); renderCard(); });
    div.addEventListener("keydown", (e) => { if (e.key === "Enter") { const id = e.target.id; if (id === "rh-email") div.querySelector('[data-a="email"]').click(); if (id === "rh-code") div.querySelector('[data-a="code"]').click(); } e.stopPropagation(); });
    sh.appendChild(div);
    document.documentElement.appendChild(h);
    const b = sh.querySelector(".body"); if (b) b.scrollTop = scroll;
    for (const id in typed) { const el = sh.getElementById(id); if (el && !el.value) el.value = typed[id]; }
    if (keepFocus) sh.getElementById(keepFocus)?.focus();
  }
  // Alt+Shift+R: open or minimise the card (on a search page: rank the whole search)
  addEventListener("keydown", (e) => {
    if (!(e.altKey && e.shiftKey && (e.key === "R" || e.key === "r" || e.code === "KeyR"))) return;
    if (cur && cur.r) { cur.open = !cur.open; state.min = !cur.open; send({ t: "pref", min: state.min }); renderCard(); }
    else if (!rk && fab) { fab.remove(); fab = null; startRank(); }
  });


  // ---------------------------------------------------------------- rank the whole search: one click, reads page after page (up to 500)
  const RANK_MAX = 500;
  let rk = null, fab = null;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function showFab(n) {
    if (rk || A.isDetail() || n < 3) { if (fab && (rk || A.isDetail())) { fab.remove(); fab = null; } return; }
    if (fab && fab.isConnected) return;
    const { h, sh } = host("div"); fab = h;
    const b = document.createElement("div"); b.className = "fab";
    b.innerHTML = `<b>⚡</b><div>${esc(T("rank_cta"))}<small>${esc(T("rank_sub"))}</small></div>`;
    b.addEventListener("click", () => { fab.remove(); fab = null; startRank(); });
    sh.appendChild(b); document.documentElement.appendChild(h);
  }
  const keyOf = (u) => { try { const x = new URL(u, location.href); return x.hostname + x.pathname.replace(/\/$/, ""); } catch { return u; } };
  function addItems(list) {
    let fresh = 0;
    for (const c of list) { if (!c || !c.url || !c.f || !c.f.price) continue; const k = keyOf(c.url); if (rk.items.has(k)) continue; rk.items.set(k, { url: c.url.split("#")[0], f: c.f, page: rk.pages + 1 }); fresh++; }
    return fresh;
  }
  function guessNext(u, n) {
    const x = new URL(u); for (const k of ["page", "pag", "pagina", "pn", "p", "pagenumber", "pageNr", "o"]) if (x.searchParams.has(k) && /^\d+$/.test(x.searchParams.get(k))) { x.searchParams.set(k, String(+x.searchParams.get(k) + 1)); return x.href; }
    if ((RHS.recipe && RHS.recipe.pageParam) || n === 1) { x.searchParams.set((RHS.recipe && RHS.recipe.pageParam) || "page", String(n + 1)); return x.href; }
    return null;
  }
  async function toServer(list) {
    const items = [];
    for (const c of list) { let path = ""; try { path = new URL(c.url).pathname; } catch { continue; } if (sent.has(path)) continue; sent.add(path);
      const f = c.f; if (!f.price || !f.sqm) continue;
      items.push({ h: await RHS.hash(`${A.id}:${path}`), portal: A.id, pp: Math.round(f.price / f.sqm), cur: f.currency, rooms: f.rooms || null, lat: f.lat ?? null, lng: f.lng ?? null, area: f.area || "", price: f.price, sqm: f.sqm, url: c.url.split("?")[0], country: f.country }); }
    for (let i = 0; i < items.length; i += 60) send({ t: "cards", rank: true, portal: A.id, area: A.areaKey(), city: cityHint(null), items: items.slice(i, i + 60) });
  }
  async function startRank() {
    rk = { items: new Map(), pages: 0, running: true, stop: false, blocked: false, visited: new Set([keyOf(location.href) + location.search]), onlySqm: false, t0: Date.now() };
    const first = A.cards().map((c) => ({ url: c.url, f: c.f }));
    addItems(first); rk.pages = 1; renderRank(); toServer(first);
    send({ t: "track", kind: "rank_start", meta: { portal: A.id, n: first.length } });
    if (state.consent) { const g = first.find((c) => c.f.lat != null); send({ t: "insights", p: { city: cityHint(null), country: RHS.siteCountry(location.hostname) || (first[0] && first[0].f.country), lat: g ? g.f.lat : null, lng: g ? g.f.lng : null, url: location.href, currency: first[0] && first[0].f.currency } }).then((ins) => { if (rk && ins && ins.city) { rk.city = ins.city; renderRank(true); } }); }
    let url = RHS.nextPageUrl(document, location.href) || (first.length >= 8 ? guessNext(location.href, 1) : null), misses = 0;
    // learn the page-number pattern from page 2's address, so we can keep going when a page shows no "next" link
    const p2 = url; const re2 = /([/=_-]|page|pagina|pag|side|seite)2(?=\/?$|\/?[?&#]|\.\w{2,5}$)/i;
    const tpl = p2 && re2.test(p2) ? (n) => p2.replace(re2, "$1" + n) : null;
    while (url && !rk.stop && rk.pages < RANK_MAX) {
      const vk = keyOf(url) + new URL(url).search; if (rk.visited.has(vk)) break; rk.visited.add(vk);
      rk.loading = rk.pages + 1; renderRank();
      await sleep(1100 + Math.random() * 1400); // polite: about one page every 1-2.5 seconds, like a person clicking "next"
      if (rk.stop) break;
      let html = "";
      try { const res = await fetch(url, { credentials: "include" }); if (res.status === 403 || res.status === 429) { rk.blocked = true; break; } if (!res.ok) break; html = await res.text(); } catch { break; }
      if (html.length < 80000 && /captcha|are you a robot|access denied|px-captcha|cf-chl|datadome|geo\.captcha|unusual traffic/i.test(html)) { rk.blocked = true; break; }
      const doc = new DOMParser().parseFromString(html, "text/html");
      let got = []; try { got = A.cardsFrom(doc, url); } catch { got = []; }
      const fresh = addItems(got); rk.pages++;
      if (!fresh) { if (++misses >= 2) break; } else { misses = 0; toServer(got); }
      renderRank();
      const nx = RHS.nextPageUrl(doc, url);
      url = (nx && !rk.visited.has(keyOf(nx) + new URL(nx).search) ? nx : null) || (tpl ? tpl(rk.pages + 1) : null) || guessNext(url, rk.pages);
    }
    rk.running = false; rk.loading = 0; renderRank();
    send({ t: "track", kind: "rank_done", meta: { portal: A.id, pages: rk.pages, n: rk.items.size, blocked: rk.blocked, secs: Math.round((Date.now() - rk.t0) / 1000) } });
  }
  function ranked() {
    const all = [...rk.items.values()];
    const pp = all.map((x) => (x.f.price && x.f.sqm ? x.f.price / x.f.sqm : null)).filter(Boolean);
    const bench = pp.length >= 5 ? RHS.median(pp) : null;
    let out = all.map((x) => ({ ...x, r: RHS.score({ ...x.f, partial: true }, { bench, benchN: pp.length, benchSource: "page", profile: state.profile, loc: null }) }));
    const F = rk.flt || {};
    out = out.filter((x) => (!rk.onlySqm || x.f.sqm) && (!F.pmax || x.f.price <= F.pmax) && (!F.smin || (x.f.sqm || 0) >= F.smin) && (!F.rmin || (x.f.rooms || 0) >= F.rmin) && (!F.scmin || x.r.score >= F.scmin));
    const S = rk.sort || "score";
    const fit = (x) => (x.r.parts.find((p) => p.k === "fit") || {}).pts || 0;
    out.sort(S === "ppsqm" ? (a, b) => (a.r.ppsqm || 1e12) - (b.r.ppsqm || 1e12) : S === "price" ? (a, b) => a.f.price - b.f.price : S === "fit" ? (a, b) => fit(b) - fit(a) || b.r.score - a.r.score : (a, b) => b.r.score - a.r.score || (a.r.pct ?? 0) - (b.r.pct ?? 0));
    return { list: out, bench, cur: (all[0] && all[0].f.currency) || "EUR", total: all.length };
  }
  let rkEl = null, rkT = 0;
  function renderRank(force) {
    if (!rk) return;
    const now = Date.now(); if (!force && rk.running && now - rkT < 350) { clearTimeout(renderRank.t); renderRank.t = setTimeout(() => renderRank(true), 360); return; } rkT = now;
    const scroll = rkEl && rkEl.shadowRoot.querySelector(".rk-l") ? rkEl.shadowRoot.querySelector(".rk-l").scrollTop : 0;
    if (rkEl) rkEl.remove();
    const { h, sh } = host("div"); rkEl = h;
    const { list, bench, cur } = ranked();
    const st = rk.running ? T("rank_loading", [String(rk.loading || rk.pages), String(rk.items.size)]) : rk.blocked ? T("rank_blocked", [String(rk.items.size), String(rk.pages)]) : T("rank_done", [String(rk.items.size), String(rk.pages)]);
    const rows = list.slice(0, 300).map((x, i) => { const f = x.f, r = x.r; const pct = r.pct != null && Math.abs(r.pct) >= 3 ? `<i style="background:${r.pct < 0 ? "#E3F4E8;color:#0F6B34" : "#FBE9E5;color:#C2412D"}">${r.pct < 0 ? "−" : "+"}${Math.abs(r.pct)}%</i>` : "";
      return `<a class="rk-r" href="${esc(x.url)}" target="_blank" rel="noopener"><span class="n">${i + 1}</span><span class="sc" style="background:${RHS.color(r.score)}">${r.score}</span><span class="d"><b>${esc(RHS.money(f.price, f.currency))}</b>${f.sqm ? ` · ${f.sqm} m²` : ""}${f.rooms ? ` · ${f.rooms} ${esc(T("rank_rooms"))}` : ""}${pct}<span>${esc((f.title || f.area || f.desc || "").slice(0, 90))}</span></span></a>`; }).join("");
    const div = document.createElement("div"); div.className = "rk";
    div.innerHTML = `<div class="rk-h"><div class="top"><b>⚡ ${esc(T("rank_title"))}</b><button class="x" data-a="close" aria-label="Close">×</button></div>
      <div class="st">${esc(st)}${bench ? " · " + esc(T("rank_median")) + " " + esc(RHS.money(bench, cur)) + "/m²" : ""}</div>
      <div class="rk-bar${rk.running ? " run" : ""}"><i style="width:${rk.running ? 100 : 100}%"></i></div>
      <div class="rk-tools">${rk.running ? `<button data-a="stop">${esc(T("rank_stop"))}</button>` : ""}<button data-a="sqm" class="${rk.onlySqm ? "on" : ""}">${esc(T("rank_only_sqm"))}</button><button data-a="csv">CSV</button><button data-a="rshare">↗ ${esc(T("rank_share"))}</button></div>
      <div class="rk-filt"><label>${esc(T("f_pmax"))}<input type="number" data-f="pmax" value="${(rk.flt || {}).pmax || ""}" placeholder="—"></label><label>m² ≥<input type="number" data-f="smin" value="${(rk.flt || {}).smin || ""}" placeholder="—"></label><label>${esc(T("rank_rooms"))} ≥<input type="number" data-f="rmin" value="${(rk.flt || {}).rmin || ""}" placeholder="—"></label><label>${esc(T("f_score"))} ≥<input type="number" data-f="scmin" value="${(rk.flt || {}).scmin || ""}" placeholder="—"></label>
        <select data-f="sort">${["score", "ppsqm", "price", "fit"].map((k) => `<option value="${k}"${(rk.sort || "score") === k ? " selected" : ""}>${esc(T("sort_" + k))}</option>`).join("")}</select></div>
      ${rk.city ? `<a class="cta sm2" href="${esc(rk.city.url)}?utm_source=extension&utm_medium=ranking" target="_blank" rel="noopener" data-a="site">🏆 ${esc(T("top10_city", [rk.city.name]))} →</a>` : ""}
      ${list.length !== rk.items.size ? `<div class="st">${esc(T("rank_showing", [String(list.length), String(rk.items.size)]))}</div>` : ""}</div>
      <div class="rk-l">${rows || `<div class="n" style="padding:14px">${esc(T("rank_empty"))}</div>`}</div>
      <div class="rk-f">${esc(T("rank_fine"))}</div>`;
    div.addEventListener("click", (e) => {
      const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return;
      if (a === "close") { rk.stop = true; rkEl.remove(); rkEl = null; rk = null; return; }
      if (a === "stop") { rk.stop = true; }
      if (a === "sqm") { rk.onlySqm = !rk.onlySqm; renderRank(true); }
      if (a === "site") { send({ t: "track", kind: "to_site", meta: { where: "ranking" } }); return; }
      if (a === "rshare") {
        const { list: L } = ranked(); const el = e.target.closest("[data-a]"); el.textContent = "…";
        send({ t: "shareRanking", title: ((document.querySelector("h1") || {}).textContent || document.title).trim().slice(0, 110), cc: RHS.siteCountry(location.hostname), city: rk.city ? rk.city.name : "", src: location.href.split("#")[0],
          items: L.slice(0, 300).map((x) => ({ url: x.url, portal: A.id, price: x.f.price, cur: x.f.currency, sqm: x.f.sqm, rooms: x.f.rooms, score: x.r.score, pct: x.r.pct, area: x.f.area || "" })) })
          .then((r) => { el.textContent = r && r.url ? "✓ " + T("rank_shared") : (r && r.error === "consent" ? T("consent_needed") : T("try_again")); if (r && r.url) copy(r.url); });
      }
      if (a === "csv") { const { list: L } = ranked(); const csv = ["rank,score,price,currency,sqm,price_per_sqm,vs_median_pct,rooms,url", ...L.map((x, i) => [i + 1, x.r.score, x.f.price, x.f.currency, x.f.sqm || "", x.r.ppsqm || "", x.r.pct ?? "", x.f.rooms || "", x.url].join(","))].join("\n");
        const el = document.createElement("a"); el.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); el.download = `realhunt-ranking-${A.id}-${new Date().toISOString().slice(0, 10)}.csv`; el.click(); send({ t: "track", kind: "rank_csv", meta: { n: L.length } }); }
    });
    div.addEventListener("change", (e) => {
      const k = e.target.dataset && e.target.dataset.f; if (!k) return;
      if (k === "sort") rk.sort = e.target.value; else { rk.flt = { ...(rk.flt || {}), [k]: Number(e.target.value) || 0 }; }
      renderRank(true);
    });
    div.addEventListener("keydown", (e) => e.stopPropagation());
    sh.appendChild(div); document.documentElement.appendChild(h);
    const l = sh.querySelector(".rk-l"); if (l) l.scrollTop = scroll;
  }

  // ---------------------------------------------------------------- run, and re-run on SPA navigation
  let lastUrl = "";
  async function run() {
    if (location.href === lastUrl) return; lastUrl = location.href;
    await getState();
    send({ t: "alive", host: location.hostname });
    if (RHS.recipe === undefined) RHS.recipe = (await send({ t: "recipe", host: location.hostname.replace(/^www\./, "") })) || null;
    try { if (A.isDetail()) await showDetail(); else { if (card) { card.remove(); card = null; } await scanCards(); } } catch (e) { /* never break the page */ }
  }
  run();
  let t = null;
  const ours = (n) => n.nodeType !== 1 || (n.getAttribute && n.getAttribute("data-rhs"));
  new MutationObserver((muts) => { if (muts.every((m) => m.addedNodes.length + m.removedNodes.length > 0 && [...m.addedNodes, ...m.removedNodes].every(ours))) return; clearTimeout(t); t = setTimeout(() => { if (location.href !== lastUrl) { A._list = null; run(); } else if (!A.isDetail()) scanCards(); }, 700); })
    .observe(document.documentElement, { childList: true, subtree: true });
})();
