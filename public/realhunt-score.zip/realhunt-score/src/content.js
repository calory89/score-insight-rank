// RealHunt Score — content script. Runs only on the supported portals (see manifest host list).
(function () {
  const RHS = window.RHS;
  const A = RHS.adapterFor(location.hostname);
  if (!A || window.__rhsLoaded) return;
  window.__rhsLoaded = true;
  const T = (k, subs) => { try { return chrome.i18n.getMessage(k, subs) || k; } catch { return k; } };
  const send = (msg) => new Promise((res) => { try { chrome.runtime.sendMessage(msg, (r) => res(chrome.runtime.lastError ? null : r)); } catch { res(null); } });

  const CSS = `
  :host{all:initial}
  .b{font:700 12px/1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;display:inline-flex;align-items:center;gap:5px;padding:5px 8px;border-radius:999px;color:#fff;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.18);margin:6px 0;user-select:none}
  .b small{font-weight:600;opacity:.85;font-size:10px}
  .c{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:320px;max-height:78vh;overflow:auto;background:#fff;color:#14181c;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.28);font:14px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  .h{display:flex;gap:12px;align-items:center;padding:14px 14px 10px}
  .s{width:58px;height:58px;border-radius:16px;display:grid;place-items:center;color:#fff;font:800 26px/1 system-ui}
  .t b{display:block;font-size:15px}.t small{color:#5b636b}
  .x{margin-left:auto;align-self:flex-start;border:0;background:none;font-size:18px;cursor:pointer;color:#8a9098}
  .p{padding:0 14px 6px}
  .r{margin:8px 0}.r .l{display:flex;justify-content:space-between;font-weight:700;font-size:13px}.r .bar{height:6px;border-radius:4px;background:#eef0f2;margin:4px 0}.r .bar i{display:block;height:100%;border-radius:4px}
  .r p{margin:0;color:#4f5a55;font-size:12.5px}
  .f{padding:10px 14px 14px;display:flex;gap:8px;flex-wrap:wrap}
  button.k{border:0;border-radius:10px;padding:9px 12px;font:700 13px system-ui;cursor:pointer;background:#0F6B34;color:#fff}
  button.k.s2{background:#eef0f2;color:#14181c}
  .n{font-size:11px;color:#8a9098;padding:0 14px 12px}
  .b i{font-style:normal;font-weight:800;font-size:10.5px;background:rgba(255,255,255,.22);border-radius:999px;padding:2px 5px}
  .s{flex-direction:column}
  .s small{display:block;font:800 11px/1 system-ui;opacity:.9;margin-top:3px;color:#fff}
  .v{padding:0 14px 8px;font-weight:700;font-size:13.5px;line-height:1.35}
  .mini{padding:0 14px 6px;display:grid;gap:5px}
  .mini .row{display:grid;grid-template-columns:128px 1fr 38px;gap:8px;align-items:center;font-size:12px;color:#4f5a55}
  .mini .bar{height:6px;border-radius:4px;background:#eef0f2}.mini .bar i{display:block;height:100%;border-radius:4px}
  .mini b{font-size:12px;color:#14181c;text-align:right}
  .pend{opacity:.55}
  .gate{background:#F4FAF5;border:1px solid #D7EBDC;border-radius:12px;padding:10px;margin:8px 0;font-size:13px}
  `;
  const host = (tag = "span") => { const h = document.createElement(tag); h.setAttribute("data-rhs", "1"); const sh = h.attachShadow({ mode: "open" }); const st = document.createElement("style"); st.textContent = CSS; sh.appendChild(st); return { h, sh }; };
  const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  let state = null;
  async function getState() { state = (await send({ t: "state" })) || { consent: false, quotaLeft: 3, profile: null, email: null }; return state; }

  // ---------------------------------------------------------------- search result pages: one badge per card
  const sent = new Set();
  async function scanCards() {
    const cards = A.cards();
    if (!cards.length) return;
    const pp = cards.map((c) => (c.f.price && c.f.sqm ? c.f.price / c.f.sqm : null)).filter(Boolean);
    const bench = RHS.median(pp);
    // Remember these homes (derived numbers only) so any listing opened later has comparables on day one.
    const items = [];
    for (const c of cards) {
      let path = ""; try { path = new URL(c.url).pathname; } catch { continue; }
      if (sent.has(path)) continue; sent.add(path);
      items.push({ h: await RHS.hash(`${A.id}:${path}`), portal: A.id, pp: c.f.price && c.f.sqm ? Math.round(c.f.price / c.f.sqm) : null, cur: c.f.currency,
        lat: c.f.lat ?? null, lng: c.f.lng ?? null, area: c.f.area || "", price: c.f.price, sqm: c.f.sqm, url: c.url.split("?")[0], country: c.f.country });
    }
    if (items.length || (bench && pp.length >= 5)) send({ t: "cards", portal: A.id, bench: pp.length >= 5 ? Math.round(bench) : null, n: pp.length, area: A.areaKey(), items: items.filter((x) => x.pp) });
    for (const c of cards) {
      if (c.el.querySelector("[data-rhs]")) continue; // React may re-render a card and drop our badge: re-add it
      const r = RHS.score({ ...c.f, partial: true }, { bench: pp.length >= 5 ? bench : null, benchN: pp.length, benchSource: "page", profile: state.profile, loc: null });
      const { h, sh } = host();
      const b = document.createElement("span"); b.className = "b"; b.style.background = RHS.color(r.score);
      b.innerHTML = `${r.score}<small>RealHunt</small>${r.pct != null && Math.abs(r.pct) >= 3 ? `<i>${r.pct < 0 ? "−" : "+"}${Math.abs(r.pct)}% €/m²</i>`.replace("€", { GBP: "£", USD: "$" }[c.f.currency] || "€") : ""}`;
      b.title = r.verdict + "\n\n" + r.parts.filter((p) => p.k !== "location").map((p) => `${T("part_" + p.k) || p.label}: ${p.pts}/${p.max}`).join("\n") + "\n" + T("badge_hint") + "\n" + T("disclaimer");
      b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); window.open(c.url, "_blank"); });
      sh.appendChild(b);
      try { (c.mount || c.el).prepend(h); } catch { c.el.prepend(h); }
    }
    if (!scanCards.tracked) { scanCards.tracked = true; send({ t: "track", kind: "badge", meta: { portal: A.id, n: cards.length } }); }
  }

  // ---------------------------------------------------------------- listing pages: score card
  let card = null, cur = null;
  async function showDetail() {
    const f = A.detail();
    if (!f) return;
    if (f.flagsExtra) f.desc = (f.desc || "") + f.flagsExtra;
    const url = location.href.split("?")[0];
    const hash = await RHS.hash(`${A.id}:${location.pathname}`);
    const comps = (await send({ t: "detail", f: { ...f, desc: undefined, title: undefined }, hash })) || {};
    const ctx = { profile: state.profile, bench: comps.bench, benchN: comps.n, benchSource: comps.source, benchKm: comps.km };
    const hasGeo = f.lat != null && f.lng != null;
    let r = RHS.score(f, { ...ctx, loc: hasGeo ? undefined : null });
    const me = (cur = { url, hash });
    renderCard(f, r, hash);
    if (hasGeo) {
      const loc = await send({ t: "nearby", lat: f.lat, lng: f.lng });
      if (cur !== me) return; // the user moved on
      r = RHS.score(f, { ...ctx, loc: loc || null });
      if (loc == null) r.parts.find((p) => p.k === "location").why = T("loc_unavailable") || "The map service didn't answer, so location counts as neutral. Reload to try again.";
      renderCard(f, r, hash, card && card._expanded);
    }
    // The side panel gets only derived features and the score, never photos or the description.
    send({ t: "report", report: { hash, url, portal: A.id, price: f.price, currency: f.currency, sqm: f.sqm, rooms: f.rooms, area: f.area, country: f.country, ptype: f.ptype, days: f.days,
      lat: f.lat, lng: f.lng, score: r.score, grade: RHS.grade(r.score), verdict: r.verdict, parts: r.parts, flags: r.flags.map((x) => x.label), plus: r.plus.map((x) => x.label), ppsqm: r.ppsqm } });
  }

  function renderCard(f, r, hash, expanded = false) {
    if (card) card.remove();
    const { h, sh } = host("div"); card = h; card._expanded = expanded;
    const quotaOk = state.email || state.quotaLeft > 0;
    const mini = r.parts.map((p) => `<div class="row${p.pending ? " pend" : ""}"><span>${esc(T("part_" + p.k) || p.label)}</span><div class="bar"><i style="width:${Math.round((p.pts / p.max) * 100)}%;background:${RHS.color((p.pts / p.max) * 100)}"></i></div><b>${p.pending ? "…" : p.pts + "/" + p.max}</b></div>`).join("");
    const rows = expanded && quotaOk
      ? r.parts.map((p) => `<div class="r"><div class="l"><span>${esc(T("part_" + p.k) || p.label)}</span><span>${p.pending ? "…" : p.pts + "/" + p.max}</span></div><p>${esc(p.why)}</p></div>`).join("")
      : "";
    const gate = expanded && !quotaOk ? `<div class="gate">${esc(T("gate"))}</div>` : "";
    const consentAsk = !state.consent ? `<div class="gate">${esc(T("consent_short"))}<br><button class="k" data-a="consent" style="margin-top:8px">${esc(T("allow"))}</button></div>` : "";
    const div = document.createElement("div"); div.className = "c";
    div.innerHTML = `<div class="h"><div class="s" style="background:${RHS.color(r.score)}">${r.score}<small>${RHS.grade(r.score)}</small></div><div class="t"><b>RealHunt Score</b><small>${esc(RHS.money(f.price, f.currency))}${f.sqm ? " · " + f.sqm + " m²" : ""}${r.ppsqm ? " · " + RHS.money(r.ppsqm, f.currency) + "/m²" : ""}</small></div><button class="x" data-a="close" aria-label="Close">×</button></div>
      <div class="v">${esc(r.verdict)}</div>
      <div class="mini">${mini}</div>
      <div class="p">${rows}${gate}${consentAsk}</div>
      <div class="f">${expanded ? "" : `<button class="k" data-a="why">${esc(T("see_why"))}</button>`}<button class="k s2" data-a="panel">${esc(T("open_panel"))}</button><button class="k s2" data-a="save">${esc(T("save"))}</button></div>
      <div class="n">${esc(T("disclaimer"))}</div>`;
    div.addEventListener("click", async (e) => {
      const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return;
      if (a === "close") { card.remove(); card = null; }
      if (a === "why") { const q = await send({ t: "useReport", hash }); state.quotaLeft = q ? q.quotaLeft : state.quotaLeft; renderCard(f, r, hash, true); }
      if (a === "panel") { const ok = await send({ t: "openPanel" }); if (!ok) renderCard(f, r, hash, true); }
      if (a === "save") { await send({ t: "track", kind: "save", hash, price: f.price }); e.target.textContent = T("saved"); }
      if (a === "consent") { await send({ t: "consent" }); await getState(); showDetail(); }
    });
    sh.appendChild(div);
    document.documentElement.appendChild(h);
  }

  // ---------------------------------------------------------------- run, and re-run on SPA navigation
  let lastUrl = "";
  async function run() {
    if (location.href === lastUrl) return; lastUrl = location.href;
    await getState();
    try { if (A.isDetail()) await showDetail(); else { if (card) { card.remove(); card = null; } await scanCards(); } } catch (e) { /* never break the page */ }
  }
  run();
  let t = null;
  new MutationObserver(() => { clearTimeout(t); t = setTimeout(() => { if (location.href !== lastUrl) { A._list = null; run(); } else if (!A.isDetail()) scanCards(); }, 700); })
    .observe(document.documentElement, { childList: true, subtree: true });
})();
