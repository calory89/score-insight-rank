// RealHunt Score — content script. Runs only on the supported portals (see manifest host list).
(function () {
  const RHS = window.RHS;
  const A = RHS.adapterFor(location.hostname);
  if (!A || window.__rhsLoaded) return;
  window.__rhsLoaded = true;
  const T = (k, subs) => { try { return chrome.i18n.getMessage(k, subs) || k; } catch { return k; } };
  const send = (msg) => new Promise((res) => { try { chrome.runtime.sendMessage(msg, (r) => res(chrome.runtime.lastError ? null : r)); } catch { res(null); } });

  const CSS = `
  :host{all:initial}
  .b{font:700 12px/1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;display:inline-flex;align-items:center;gap:5px;padding:5px 8px;border-radius:999px;color:#fff;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.18);margin:6px 0;user-select:none}
  .b small{font-weight:600;opacity:.85;font-size:10px}
  .c{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:320px;max-height:78vh;overflow:auto;background:#fff;color:#14181c;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.28);font:14px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  .h{display:flex;gap:12px;align-items:center;padding:14px 14px 10px}
  .s{width:58px;height:58px;border-radius:16px;display:grid;place-items:center;color:#fff;font:800 26px/1 system-ui}
  .t b{display:block;font-size:15px}.t small{color:#5b636b}
  .x{margin-left:auto;align-self:flex-start;border:0;background:none;font-size:18px;cursor:pointer;color:#8a9098}
  .p{padding:0 14px 6px}
  .r{margin:8px 0}.r .l{display:flex;justify-content:space-between;font-weight:700;font-size:13px}.r .bar{height:6px;border-radius:4px;background:#eef0f2;margin:4px 0}.r .bar i{display:block;height:100%;border-radius:4px}
  .r p{margin:0;color:#4f5a55;font-size:12.5px}
  .f{padding:10px 14px 14px;display:flex;gap:8px;flex-wrap:wrap}
  button.k{border:0;border-radius:10px;padding:9px 12px;font:700 13px system-ui;cursor:pointer;background:#0F6B34;color:#fff}
  button.k.s2{background:#eef0f2;color:#14181c}
  .n{font-size:11px;color:#8a9098;padding:0 14px 12px}
  .b i{font-style:normal;font-weight:800;font-size:10.5px;background:rgba(255,255,255,.22);border-radius:999px;padding:2px 5px}
  .s{flex-direction:column}
  .s small{display:block;font:800 11px/1 system-ui;opacity:.9;margin-top:3px;color:#fff}
  .v{padding:0 14px 8px;font-weight:700;font-size:13.5px;line-height:1.35}
  .mini{padding:0 14px 6px;display:grid;gap:5px}
  .mini .row{display:grid;grid-template-columns:128px 1fr 38px;gap:8px;align-items:center;font-size:12px;color:#4f5a55}
  .mini .bar{height:6px;border-radius:4px;background:#eef0f2}.mini .bar i{display:block;height:100%;border-radius:4px}
  .mini b{font-size:12px;color:#14181c;text-align:right}
  .pend{opacity:.55}
  .ai{font:800 9.5px/1 system-ui;background:#111;color:#fff;border-radius:6px;padding:3px 5px;vertical-align:2px;margin-left:4px}
  .free{display:inline-block;font:800 10px/1 system-ui;background:#FFE14D;color:#14181c;border-radius:6px;padding:3px 6px;letter-spacing:.04em}
  .nudge{margin:2px 14px 6px;padding:9px 11px;border-radius:12px;background:#14181c;color:#fff;font:700 12.5px/1.35 system-ui;cursor:pointer}
  .in{width:100%;box-sizing:border-box;margin-top:8px;padding:10px 11px;border:1px solid #cfd6d1;border-radius:10px;font:15px system-ui;background:#fff;color:#14181c}
  .ck{display:flex;gap:6px;align-items:flex-start;font-size:11.5px;color:#4f5a55;margin-top:7px}
  .fine{font-size:10.5px;color:#7a837e;margin-top:6px}.err{color:#C2412D;font-size:12px;margin-top:4px}
  .x+.x{margin-left:0}
  .pill{position:fixed;right:16px;bottom:16px;z-index:2147483646;display:flex;align-items:center;gap:8px;padding:8px 14px 8px 8px;border-radius:999px;color:#fff;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.25);font:700 12px/1 system-ui}
  .pill b{background:rgba(255,255,255,.22);border-radius:999px;padding:7px 9px;font:800 16px/1 system-ui}
  .fab{position:fixed;left:16px;bottom:16px;z-index:2147483645;display:flex;align-items:center;gap:8px;padding:10px 16px 10px 10px;border-radius:999px;background:#14181c;color:#fff;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.28);font:700 13px/1.1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  .fab b{background:#FFE14D;color:#14181c;border-radius:999px;width:28px;height:28px;display:grid;place-items:center;font:800 15px/1 system-ui}
  .fab small{display:block;font-weight:600;opacity:.7;font-size:11px;margin-top:2px}
  .rk{position:fixed;left:16px;top:16px;bottom:16px;z-index:2147483646;width:400px;max-width:calc(100vw - 32px);display:flex;flex-direction:column;background:#fff;color:#14181c;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.3);font:13px/1.35 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;overflow:hidden}
  .rk-h{padding:14px 14px 8px;border-bottom:1px solid #eef0f2}
  .rk-h .top{display:flex;align-items:center;gap:8px}.rk-h .top b{font-size:15px}
  .rk-h .st{color:#5b636b;font-size:12px;margin-top:4px}
  .rk-bar{height:4px;background:#eef0f2;border-radius:3px;margin-top:8px;overflow:hidden}.rk-bar i{display:block;height:100%;background:#0F6B34;transition:width .3s}
  .rk-bar.run i{background:linear-gradient(90deg,#0F6B34,#2E9E5B,#0F6B34);background-size:200% 100%;animation:rkm 1.2s linear infinite}
  @keyframes rkm{from{background-position:0 0}to{background-position:200% 0}}
  .rk-tools{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
  .rk-tools button{border:0;border-radius:999px;padding:6px 10px;font:700 12px system-ui;cursor:pointer;background:#eef0f2;color:#14181c}
  .rk-tools button.on{background:#14181c;color:#fff}
  .rk-l{overflow:auto;flex:1;padding:4px 0}
  .rk-filt{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;font-size:11px;color:#4f5a55;align-items:center}
  .rk-filt label{display:flex;gap:3px;align-items:center}.rk-filt input{width:62px;border:1px solid #cfd6d1;border-radius:6px;padding:3px 4px;font:12px system-ui}
  .rk-filt select{border:1px solid #cfd6d1;border-radius:6px;padding:3px 4px;font:12px system-ui;margin-left:auto}
  .cta.sm2{margin:8px 0 0;padding:9px 12px;font-size:13px}
  .rk-r{display:grid;grid-template-columns:26px 44px 1fr;gap:8px;align-items:center;padding:8px 14px;border-bottom:1px solid #f3f4f6;text-decoration:none;color:inherit}
  .rk-r:hover{background:#F4FAF5}
  .rk-r .n{color:#8a9098;font-weight:700;font-size:12px;padding:0;text-align:right}
  .rk-r .sc{width:44px;height:36px;border-radius:10px;display:grid;place-items:center;color:#fff;font:800 16px/1 system-ui}
  .rk-r .d{min-width:0}.rk-r .d b{font-size:13.5px}.rk-r .d span{display:block;color:#5b636b;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .rk-r .d .fx{color:#0F6B34;font-weight:700}
  .rk-r .d i{font-style:normal;font-weight:800;font-size:11px;padding:1px 5px;border-radius:6px;margin-left:4px}
  .rk-f{padding:8px 14px 12px;font-size:10.5px;color:#7a837e;border-top:1px solid #eef0f2}

  .c.v5{width:372px;display:flex;flex-direction:column;max-height:84vh;overflow:hidden}
  .v5 .h{cursor:grab;user-select:none}
  .v5 .body{overflow:auto;flex:1;padding-bottom:4px}
  .ld{height:3px;margin:0 14px;border-radius:2px;background:linear-gradient(90deg,#0F6B34,#2E9E5B,#FFE14D,#0F6B34);background-size:300% 100%;animation:rkm 1.4s linear infinite}
  .sum{margin:0 14px 8px;font-size:12.5px;color:#4f5a55}
  .blocks{display:grid;gap:8px;padding:0 12px}
  .blk{background:#F7F8F9;border-radius:14px;padding:10px 12px;position:relative;animation:fin .35s ease}
  @keyframes fin{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
  .blk h4{margin:0 0 6px;font:800 12.5px/1.2 system-ui;color:#14181c;display:flex;gap:6px;align-items:center}
  .blk h4 em{font-style:normal;font-weight:700;font-size:10px;background:#E8ECEA;border-radius:6px;padding:2px 5px;color:#4f5a55;margin-left:auto}
  .blk p{margin:4px 0 0;font-size:12.5px}.blk .mut,.mut{color:#6b746f;font-size:11.5px}
  .blk .big{font:800 22px/1.1 system-ui}
  .pos{color:#0F6B34}.neg{color:#C2412D}
  .two{display:grid;grid-template-columns:1fr 1fr;gap:8px}.two small{display:block;color:#6b746f;font-size:11px}.two b{font:800 16px/1.2 system-ui}
  .calc{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;font-size:11px;color:#4f5a55}.calc input{width:46px;border:1px solid #cfd6d1;border-radius:6px;padding:3px 4px;font:12px system-ui;background:#fff;color:#14181c}
  .hist,.lk,.qs{margin:2px 0 0;padding-left:16px;font-size:12.5px}.hist{list-style:none;padding:0}.hist li{display:flex;gap:8px}.hist span{color:#6b746f;min-width:58px}
  .hist em,.lk em{font-style:normal;font-weight:800;font-size:11px}
  .lk li{margin:3px 0}.lk a{color:#0F6B34;font-weight:700;text-decoration:none}.lk small{color:#6b746f}
  .chips{display:flex;flex-wrap:wrap;gap:5px}.chips span{background:#fff;border-radius:999px;padding:3px 8px;font-size:11.5px}.chips span.off{opacity:.45}
  .k.sm{padding:6px 9px;font-size:12px;margin-top:6px}
  .sk i{display:block;height:10px;border-radius:5px;margin:6px 0;background:linear-gradient(90deg,#e9ecee,#f6f7f8,#e9ecee);background-size:200% 100%;animation:rkm 1.2s linear infinite}.sk i+i{width:60%}
  .blk.lock>*:not(h4){filter:blur(4px);pointer-events:none;user-select:none}
  .unlock{margin:8px 12px 0;padding:10px 12px;border-radius:12px;background:#14181c;color:#fff;font:700 12.5px/1.35 system-ui;cursor:pointer}
  .cta{display:block;margin:10px 12px 4px;padding:12px 14px;border-radius:14px;background:linear-gradient(135deg,#0F6B34,#2E9E5B);color:#fff;font:800 14px/1.25 system-ui;text-decoration:none;text-align:center;box-shadow:0 6px 16px rgba(15,107,52,.25)}
  .v5 .f{flex-wrap:nowrap;gap:6px;padding:8px 12px 10px}.v5 .f button.k{padding:8px 9px;font-size:12px;white-space:nowrap}.v5 .cta{margin:8px 12px 0}
  .det{margin:8px 12px 0}.det summary{cursor:pointer;font:700 12.5px system-ui;color:#4f5a55;padding:6px 2px}
  .onb{margin:0 12px 8px;padding:10px 12px;border-radius:12px;background:#FFF8D6;font-size:12px}.onb ol{margin:4px 0;padding-left:18px}

  .bar7{position:fixed;left:16px;bottom:16px;z-index:2147483645;display:flex;gap:6px;align-items:center;flex-wrap:wrap;max-width:calc(100vw - 32px);font:700 12.5px/1.1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
  .bar7 .fab{position:static}
  .chip{display:flex;align-items:center;gap:6px;padding:8px 12px;border-radius:999px;background:#fff;color:#14181c;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.2);border:0;font:700 12.5px/1.1 system-ui}
  .chip.dk{background:#14181c;color:#fff}.chip.on{background:#FFE14D;color:#14181c}
  .chip i{font-style:normal;color:#fff;border-radius:8px;padding:3px 6px;font-weight:800}
  .chip.xx{padding:8px 10px;opacity:.85}
  .rk-tools button.go{background:#0F6B34;color:#fff}
  textarea.nt{width:100%;box-sizing:border-box;min-height:54px;border:1px solid #cfd6d1;border-radius:10px;padding:7px 9px;font:13px system-ui;background:#fff;color:#14181c;resize:vertical}
  .lk2{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}.lk2 a,.lk2 button{border:0;border-radius:999px;padding:6px 10px;font:700 12px system-ui;background:#fff;color:#0F6B34;text-decoration:none;cursor:pointer}
  .lk2 button.on{background:#0F6B34;color:#fff}
  .seen{font-style:normal;font-size:10px;background:rgba(0,0,0,.25);border-radius:999px;padding:2px 5px}
  .gate{background:#F4FAF5;border:1px solid #D7EBDC;border-radius:12px;padding:10px;margin:8px 0;font-size:13px}
  @media (prefers-color-scheme: dark){
    .c,.rk{background:#15191c;color:#e8ecea}.blk{background:#1f2428}.blk h4{color:#e8ecea}.blk h4 em{background:#2a3036;color:#b6bfba}
    .mut,.blk .mut,.two small,.hist span,.lk small,.r p,.mini .row,.n,.sum,.st{color:#9aa49f}.chips span{background:#2a3036}.calc input{background:#1f2428;color:#e8ecea;border-color:#3a4148}
    button.k.s2,.rk-tools button{background:#2a3036;color:#e8ecea}.mini .bar,.r .bar,.rk-bar{background:#2a3036}.rk-r:hover{background:#1f2428}.rk-h,.rk-f{border-color:#2a3036}.rk-r{border-color:#22272b}
    .gate{background:#1c2a22;border-color:#24402e}.chip{background:#1f2428;color:#e8ecea}textarea.nt{background:#1f2428;color:#e8ecea;border-color:#3a4148}.lk2 a,.lk2 button{background:#2a3036;color:#4fd18a}.onb{background:#3a3315}.in{background:#1f2428;color:#e8ecea;border-color:#3a4148}.pos{color:#4fd18a}.neg{color:#ff8a73}.rk-filt input,.rk-filt select{background:#1f2428;color:#e8ecea;border-color:#3a4148}
  }  `;
  const host = (tag = "span") => { const h = document.createElement(tag); h.setAttribute("data-rhs", "1"); const sh = h.attachShadow({ mode: "open" }); const st = document.createElement("style"); st.textContent = CSS; sh.appendChild(st); return { h, sh }; };
  const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  const SYM = { EUR: "€", GBP: "£", USD: "$", DKK: "kr", SEK: "kr", NOK: "kr", CHF: "CHF", PLN: "zł", CZK: "Kč", HUF: "Ft", JPY: "¥", INR: "₹", AUD: "A$", CAD: "C$", NZD: "NZ$", BRL: "R$", MXN: "MX$", AED: "AED", TRY: "₺", ILS: "₪", ZAR: "R", SGD: "S$", HKD: "HK$", THB: "฿", KRW: "₩" };
  const sym = (c) => SYM[c] || c || "€";
  let state = null, prefs = {};
  const dec = (x) => { try { return decodeURIComponent(x); } catch { return x; } };
  // v0.7: deciding "listing or results page" is costly on big pages: remember the answer per address for a moment
  const isDet = () => { const k = location.href; if (isDet.k === k && Date.now() - isDet.t < 3000) return isDet.v; isDet.k = k; isDet.t = Date.now(); try { isDet.v = !!A.isDetail(); } catch { isDet.v = false; } return isDet.v; };
  const tenOf = (f) => (f && f.tenure && f.tenure.k) || null;
  // what we send for a home's score (v0.10): the score, its fair price and the gap, so the best ones reach realhunt.co
  const scoreOf = (r, f) => (r ? { score: r.score, fair: r.fair ? Math.round(r.fair) : null, pct: r.pct, deep: !!f.deep, deal: f.deal || "sale", title: String(f.title || "").slice(0, 120) } : { deal: f.deal || "sale" });
  const ppOf = (f) => (f.price && f.sqm ? (f.deal === "rent" ? Math.round((f.price / f.sqm) * 100) / 100 : Math.round(f.price / f.sqm)) : null);
  const factsOf = (f) => ({ baths: f.baths || null, year: f.year || null, lot: f.lot || null, ptype: f.ptype || null, loc: f.loc || null });
  let recent = null; // homes opened before (urls), to mark them on search pages
  let recentFull = [];
  async function loadRecent() { if (recent) return recent; const r = (await send({ t: "seen" })) || []; recentFull = r; recent = new Set(r.map((x) => x.url)); return recent; }
  async function getState() { state = (await send({ t: "state" })) || { consent: false, quotaLeft: 3, profile: null, email: null }; return state; }

  // ---------------------------------------------------------------- search result pages: one badge per card
  const sent = new Set();
  let lastScan = [];
  // v0.9: your 👍/👎 by listing address, to mark homes on search pages and in rankings
  let taste = null;
  let notesRaw = {};
  async function loadTaste(force) { if (taste && !force) return taste; const n = (await send({ t: "notesAll" })) || {}; notesRaw = n; taste = new Map(); for (const k in n) if (n[k] && n[k].url && n[k].like) taste.set(keyOf(n[k].url), n[k].like); return taste; }
  // v0.10: your answers win; without them, what the homes you liked have in common (per sale or rent)
  const profileFor = (deal) => state.profile || RHS.learnTaste(notesRaw, deal || "sale") || null;
  const per = (f) => (f && f.deal === "rent" ? T("per_month") : "");
  const MP = (n, f) => RHS.money(n, f.currency) + per(f);
  async function scanCards() {
    const cards = A.cards();
    if (!cards.length) { showFab(0); return; }
    await loadRecent(); await loadTaste();
    const pp = cards.map((c) => (c.f.price && c.f.sqm ? c.f.price / c.f.sqm : null)).filter(Boolean);
    const bench = RHS.median(pp);
    cards.forEach((c) => RHS.enrich(c.f));
    const RS = RHS.scoreGroup(cards.map((c) => c.f), { profile: profileFor(RHS.pageDeal), loc: null }); // v0.8: fair price per home from the whole page
    // Remember these homes (derived numbers only) so any listing opened later has comparables on day one.
    // v0.7: homes without m² travel too (price and bedrooms), so agency sites without sizes still build city tops.
    const items = [];
    for (const [ci, c] of cards.entries()) {
      let path = ""; try { path = new URL(c.url).pathname; } catch { continue; }
      if (sent.has(path)) continue; sent.add(path);
      if (c.f.status === "off" || c.f.status === "short") continue;
      items.push({ h: await RHS.hash(`${A.id}:${path}`), ...scoreOf(RS[ci], c.f), portal: A.id, pp: ppOf(c.f), cur: c.f.currency, rooms: c.f.rooms || null, ten: tenOf(c.f), ...factsOf(c.f),
        lat: c.f.lat ?? null, lng: c.f.lng ?? null, area: c.f.area || "", price: c.f.price, sqm: c.f.sqm, url: c.url.split("?")[0], country: c.f.country });
    }
    if (items.length || (bench && pp.length >= 5)) send({ t: "cards", portal: A.id, bench: pp.length >= 5 ? Math.round(bench) : null, n: pp.length, area: A.areaKey(), city: cityHint(null), items: items.filter((x) => x.pp || (x.price && x.rooms)) });
    const scored = [];
    for (const [ci, c] of cards.entries()) {
      const r = RS[ci];
      scored.push({ c, r });
      if (!c.el || !c.el.isConnected) continue; // homes read from the page's data but not drawn yet get their badge when they appear
      if (c.el.querySelector("[data-rhs]")) continue; // React may re-render a card and drop our badge: re-add it
      const { h, sh } = host();
      const b = document.createElement("span"); b.className = "b"; b.style.background = RHS.color(r.score);
      const seen = recent && recent.has(c.url.split("?")[0]);
      const like = taste && taste.get(keyOf(c.url));
      if (like === -1) { c.el.style.opacity = "0.35"; c.el.dataset.rhsNo = "1"; }
      b.innerHTML = `${like === 1 ? "♥ " : like === -1 ? "👎 " : ""}${r.score}<small>${RHS.grade(r.score)} · RealHunt</small>${r.pct != null && Math.abs(r.pct) >= 3 ? `<i>${r.pct < 0 ? "−" : "+"}${Math.abs(r.pct)}% ${r.fair ? T("vs_fair") : r.unit && !/^sqm/.test(r.unit) ? "/" + T("unit_room") : sym(c.f.currency) + "/m²"}</i>` : ""}${seen ? `<i class="seen" title="${esc(T("seen_before"))}">👁</i>` : ""}`;
      b.title = r.verdict + (r.fair ? "\n" + T("fair_short") + " ≈ " + RHS.money(RHS.nice(r.fair), c.f.currency) : "") + "\n\n" + r.parts.filter((p) => p.k !== "location").map((p) => `${T("part_" + p.k) || p.label}: ${p.pts}/${p.max}`).join("\n") + "\n" + T("badge_hint") + "\n" + T("disclaimer");
      // v0.7: the badge behaves like the listing link (same tab), Ctrl/⌘/middle click opens a new tab
      b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); if (e.ctrlKey || e.metaKey || e.shiftKey) window.open(c.url, "_blank", "noopener"); else location.assign(c.url); });
      b.addEventListener("auxclick", (e) => { if (e.button === 1) { e.preventDefault(); e.stopPropagation(); window.open(c.url, "_blank", "noopener"); } });
      sh.appendChild(b);
      try { (c.mount || c.el).prepend(h); } catch { try { c.el.prepend(h); } catch { /* card gone */ } }
    }
    lastScan = scored;
    paintPage();
    showFab(cards.length);
    if (!scanCards.tracked) { scanCards.tracked = true; send({ t: "track", kind: "badge", meta: { portal: A.id, n: cards.length } }); }
  }
  // v0.7: the 3 best homes on the page get a gold, silver and bronze frame; "hide weak" fades homes under 50
  const MEDAL = ["#E9B80C", "#A7B1BA", "#C9824A"];
  function paintPage() {
    const vis = lastScan.filter((x) => x.c.el && x.c.el.isConnected);
    const top = [...vis].sort((a, b) => b.r.score - a.r.score).slice(0, 3);
    for (const x of vis) {
      const el = x.c.el; const i = top.indexOf(x);
      if (i >= 0 && x.r.score >= 55) { el.style.outline = `3px solid ${MEDAL[i]}`; el.style.outlineOffset = "2px"; el.style.borderRadius = el.style.borderRadius || "8px"; el.dataset.rhsTop = String(i + 1); }
      else if (el.dataset.rhsTop) { el.style.outline = ""; el.style.outlineOffset = ""; delete el.dataset.rhsTop; }
      el.style.opacity = el.dataset.rhsNo ? "0.35" : prefs.dim && x.r.score < 50 ? "0.32" : "";
      el.style.transition = "opacity .2s";
    }
  }

  // ---------------------------------------------------------------- listing pages: the smart card (v0.5)
  // Opens at once with the score, then fills block by block as data arrives: comparables, our server (history,
  // duplicates, city, better options), the map and the AI reading. Every block has a reason; nothing is invented.
  let card = null, cur = null;
  const cityHint = (f) => [f && (f.city || f.province || f.area), (document.querySelector("h1") || {}).textContent || "", dec(location.pathname)].filter(Boolean).join(" ").replace(/\s+/g, " ").slice(0, 200);
  async function showDetail() {
    const f = A.detail();
    if (!f) return;
    RHS.enrich(f);
    await loadRecent();
    const prevSeen = recentFull.find((x) => x.url === location.href.split("?")[0] && x.price && f.price && Math.abs(x.price - f.price) / f.price > 0.005);
    if (f.flagsExtra) f.desc = (f.desc || "") + f.flagsExtra;
    prefs = (await send({ t: "prefs" })) || {};
    const url = location.href.split("?")[0];
    const hash = await RHS.hash(`${A.id}:${location.pathname}`);
    const comps = (await send({ t: "detail", f: { ...f, desc: undefined, title: undefined, _enriched: undefined }, hash })) || {};
    let hasGeo = f.lat != null && f.lng != null;
    const canGeocode = !hasGeo && state.consent;
    // v0.8: a fair price for this exact home from the similar homes you have seen (size, bedrooms, bathrooms, type, area)
    let fairCtx = {};
    try { if (comps.rows && comps.rows.length >= 10) { const M = RHS.fairModel(comps.rows); const p = M && M.predict(f); if (p) fairCtx = { fair: p.fair, fairN: M.n, fairSrc: comps.near ? "near" : p.local ? "local" : "page", conf: RHS.modelConf(M, p.local || comps.near) }; } } catch { /* fall back to the median */ }
    const me = (cur = { url, hash, f, comps, ins: state.consent ? undefined : null, priceChange: prevSeen ? { from: prevSeen.price, t: prevSeen.t } : null, ctx: { profile: profileFor(f.deal), bench: comps.bench, benchN: comps.n, benchSource: comps.source, benchKm: comps.km, official: comps.official, loc: hasGeo || canGeocode ? undefined : null, ai: null, ...fairCtx }, expanded: !!prefs.why && !!state.email, gate: null, open: !state.min && innerWidth >= 760 });
    send({ t: "note", hash }).then((n) => { me.note = n || {}; if (cur === me) renderCard(); });
    const rescore = () => { if (cur !== me) return; me.r = RHS.score(f, me.ctx); renderCard(); };
    rescore();
    const q = await send({ t: "useReport", hash }); // the first full report of the day is free; after that, with a free email
    me.allowed = !!(q && q.allowed); state.quotaLeft = q ? q.quotaLeft : state.quotaLeft;
    const jobs = [];
    // v0.9: no map point on the page -> find the address on the map (OpenStreetMap through our server, cached)
    if (canGeocode) {
      const place = [f.addr || (/\d/.test(f.title || "") ? f.title : ""), f.city || f.area, f.zip, countryName(f.country || RHS.siteCountry(location.hostname))].filter(Boolean).join(", ");
      const g = place.length > 6 ? await send({ t: "geocode", q: place }) : null;
      if (cur !== me) return;
      if (g && g.lat != null) { f.lat = g.lat; f.lng = g.lng; hasGeo = true; me.ctx.geoApprox = (g.rank || 0) < 30; } else { me.ctx.loc = null; rescore(); }
    }
    if (hasGeo) jobs.push(send({ t: "nearby", lat: f.lat, lng: f.lng }).then((loc) => { me.ctx.loc = loc || null; rescore(); }));
    if (state.consent) jobs.push(send({ t: "insights", p: { hash, lat: f.lat, lng: f.lng, price: f.price, sqm: f.sqm, rooms: f.rooms, currency: f.currency, country: f.country, city: cityHint(f), area: f.area, url, portal: A.id, deal: f.deal || "sale" } }).then((ins) => {
      me.ins = ins || null;
      // v0.9: the neighbourhood against the city, and the distance to the centre
      if (ins && ins.near && ins.city && ins.city.median) me.ctx.areaIdx = ins.near.median / ins.city.median;
      if (ins && ins.city && ins.city.lat != null && f.lat != null) { me.ctx.centreKm = RHS.km(f.lat, f.lng, ins.city.lat, ins.city.lng); me.ctx.cityName = ins.city.name; }
      const b = RHS.bestBench(comps, ins);
      if (b) Object.assign(me.ctx, { bench: b.bench, benchN: b.n, benchSource: b.source, benchKm: b.km });
      // the server's nearby median is only used when our fair-price model has too few homes
      if (me.ctx.fair && ins && ins.near && ins.near.n >= 25 && (me.ctx.fairN || 0) < 15) delete me.ctx.fair;
      rescore();
    }));
    if (state.consent && (f.desc || "").length > 60) jobs.push(send({ t: "analyze", hash, text: f.desc, lang: RHS.lang }).then((ai) => { me.aiDone = true; if (ai) me.ctx.ai = ai; rescore(); }));
    const report = (first) => { const r = me.r; send({ t: "report", report: { first, hash, url, portal: A.id, deal: f.deal || "sale", fair: r.fair ? Math.round(r.fair) : null, pct: r.pct, title: String(f.title || "").slice(0, 120), baths: f.baths || null, price: f.price, currency: f.currency, sqm: f.sqm, rooms: f.rooms, area: f.area, country: f.country, ptype: f.ptype, days: f.days, city: cityHint(f),
      lat: f.lat, lng: f.lng, score: r.score, grade: RHS.grade(r.score), verdict: r.verdict, parts: r.parts, flags: r.flags.map((x) => x.label), plus: r.plus.map((x) => x.label), ppsqm: r.ppsqm, ai: r.ai, final: !r.pending } }); };
    report(true);
    send({ t: "seen", add: { url, hash, portal: A.id, price: f.price, cur: f.currency, sqm: f.sqm, rooms: f.rooms, score: me.r.score, title: (f.title || document.title || "").slice(0, 90) } });
    await Promise.all(jobs);
    if (cur !== me) return;
    report();
  }

  const countryName = (cc) => ({ ES: "Spain", PT: "Portugal", IT: "Italy", FR: "France", DE: "Germany", GB: "United Kingdom", US: "USA", DK: "Denmark", SE: "Sweden", NO: "Norway", NL: "Netherlands", BE: "Belgium", AT: "Austria", CH: "Switzerland", IE: "Ireland", ID: "Indonesia", TH: "Thailand", MX: "Mexico", CA: "Canada", AU: "Australia", GR: "Greece", HR: "Croatia", CY: "Cyprus", MT: "Malta", TR: "Turkey", PL: "Poland", AE: "UAE" })[cc] || "";
  const FREE = { es: "GRATIS", da: "GRATIS", de: "GRATIS", it: "GRATIS", pt: "GRÁTIS", fr: "GRATUIT", nl: "GRATIS", sv: "GRATIS", nb: "GRATIS" }[RHS.lang] || "FREE";
  function gateHtml(g) {
    if (g.step === "code") return `<div class="gate"><b>${esc(T("code_title"))}</b><br><span>${esc(T("code_sent", [g.email]))}</span>
      <input class="in" id="rh-code" inputmode="numeric" maxlength="6" placeholder="123456" autocomplete="one-time-code">
      <button class="k" data-a="code" style="margin-top:6px">${esc(T("code_cta"))}</button> <button class="k s2" data-a="back" style="margin-top:6px">${esc(T("change_email"))}</button>
      <div class="err">${esc(g.err || "")}</div></div>`;
    return `<div class="gate"><span class="free">${FREE}</span> <b>${esc(T("unlock_title"))}</b><br><span>${esc(T("unlock_body"))}</span>
      <input class="in" id="rh-email" type="email" placeholder="you@email.com" autocomplete="email" value="${esc(g.email || "")}">
      <label class="ck"><input type="checkbox" id="rh-mk" ${g.mk ? "checked" : ""}> ${esc(T("marketing_ok"))}</label>
      <button class="k" data-a="email" style="margin-top:6px;width:100%">${esc(T("unlock_cta"))}</button>
      <div class="fine">${esc(T("unlock_fine"))}</div><div class="err">${esc(g.err || "")}</div></div>`;
  }
  const M = (n, c) => RHS.money(n, c);
  const skel = `<div class="sk"><i></i><i></i></div>`;
  function blk(id, title, body, opt = {}) {
    return `<section class="blk${opt.lock ? " lock" : ""}${opt.wide ? " wide" : ""}" data-b="${id}"><h4>${opt.icon || ""} ${esc(title)}${opt.badge ? ` <em>${esc(opt.badge)}</em>` : ""}</h4>${body}</section>`;
  }

  function blocksHtml(me) {
    const { f, r, ins } = me; const cc = f.country || RHS.siteCountry(location.hostname) || RHS.ccFromCur(f.currency) || "";
    const bench = me.ctx.bench; const hist = ins && ins.history; const offer = RHS.offer(f, bench, hist, me.ctx.fair);
    const out = [];
    // 1. price in money
    const rb = me.comps && me.comps.room;
    if (offer && offer.diff != null && (me.ctx.fair || (bench && f.sqm))) {
      const d = offer.diff, pct = r.pct;
      const src = me.ctx.fair ? T("src_model", [String(me.ctx.fairN)]) : me.ctx.benchSource === "near" ? T("src_near", [String(me.ctx.benchN), String(me.ctx.benchKm || 2)]) : me.ctx.benchSource === "area" ? T("src_area", [String(me.ctx.benchN)]) : T("src_page", [String(me.ctx.benchN)]);
      out.push(blk("price", T("b_price"), `<div class="big ${d > 0 ? "neg" : "pos"}">${d > 0 ? "+" : "−"}${esc(M(Math.abs(d), f.currency))}</div><p>${esc(T(d > 0 ? "price_over" : "price_under", [String(Math.abs(pct || 0))]))}</p><p class="mut">${esc(T(me.ctx.fair ? "fair_value_model" : "fair_value"))}: <b>${esc(M(offer.fair, f.currency))}</b> · ${esc(src)}</p>`, { icon: "€" }));
    } else if (!f.sqm && rb && f.rooms && f.price) {
      // v0.7: no m² on this site: compare the price per bedroom with similar homes you have seen
      const per = f.price / f.rooms, pct = Math.round((per / rb.bench - 1) * 100);
      out.push(blk("price", T("b_price"), `<div class="big ${pct > 0 ? "neg" : "pos"}">${pct > 0 ? "+" : "−"}${Math.abs(pct)}%</div><p>${esc(T("price_room", [String(Math.abs(pct)), String(rb.n)]))}</p><p class="mut">${esc(M(per, f.currency))} / ${esc(T("unit_room"))} · ${esc(T("median"))} ${esc(M(rb.bench, f.currency))}</p>`, { icon: "€" }));
    } else if (me.ins === undefined || me.ctx.loc === undefined) out.push(blk("price", T("b_price"), skel, { icon: "€" }));
    else out.push(blk("price", T("b_price"), `<p class="mut">${esc(T("price_nocomps"))}</p>`, { icon: "€" }));
    if (f.tenure && f.tenure.k === "lease") out.push(blk("lease", T("b_lease"), `<p>${f.tenure.years ? esc(T("lease_line", [String(f.tenure.years), M(f.price / f.tenure.years, f.currency)])) : esc(T("lease_noyears"))}</p><p class="mut">${esc(T("lease_note"))}</p>`, { icon: "📜" }));
    // 2. what to offer
    if (offer) out.push(blk("offer", T(f.deal === "rent" ? "b_offer_rent" : "b_offer"), `<div class="two"><div><small>${esc(T("offer_open"))}</small><b>${esc(MP(offer.open, f))}</b></div><div><small>${esc(T("offer_max"))}</small><b>${esc(MP(offer.max, f))}</b></div></div><p class="mut">${esc(T(offer.hasFair ? (offer.stale ? "offer_why_stale" : "offer_why") : "offer_why_nocomps"))}</p><button class="k s2 sm" data-a="haggle">✉ ${esc(T("haggle"))}</button>`, { icon: "🤝", badge: T("estimate") }));
    const lock = !(state.email || me.allowed);
    // 3. money: mortgage and rent for a sale; yearly cost and rent-vs-buy for a rental (v0.10)
    const c = prefs.calc || {}; const cityI = ins && ins.city;
    if (f.deal === "rent") {
      const yr = f.price * 12, buy = cityI && cityI.sale_median && f.sqm ? cityI.sale_median * f.sqm : null;
      out.push(blk("cost", T("b_cost_rent"), `<div class="two"><div><small>${esc(T("rent_year"))}</small><b>${esc(M(yr, f.currency))}</b></div><div><small>${esc(T(f.depositMonths ? "rent_deposit_n" : "rent_deposit"))}</small><b>${esc(M(f.price * (f.depositMonths || 2), f.currency))}</b></div></div>
        ${f.sqm ? `<p class="mut">${esc(M(f.price / f.sqm, f.currency))}/m² ${esc(T("per_month"))}${cityI && cityI.rent_median ? " · " + esc(T("city_rent_median", [M(cityI.rent_median, f.currency), cityI.name])) : ""}</p>` : ""}
        ${buy ? `<p>${esc(T("rent_vs_buy", [M(RHS.nice(buy), f.currency), String(Math.round(buy / yr))]))}</p><p class="mut">${esc(T("rent_vs_buy_note", [String(Math.round((yr / buy) * 1000) / 10)]))}</p>` : ""}`, { icon: "🔑", badge: T("estimate"), lock }));
    } else {
      const mo = RHS.monthly(f.price, cc, c);
      // the real rent level of the city when we know it, else the country's typical yield
      const realRent = cityI && cityI.rent_median && f.sqm ? cityI.rent_median * f.sqm : null;
      const realY = realRent ? Math.round((realRent * 12 / f.price) * 1000) / 10 : null;
      const re = realY && realY > 1 && realY < 15 && !c.yield ? { month: RHS.nice(realRent), yield: realY, real: true } : RHS.rent(f.price, cc, c.yield);
      if (mo) out.push(blk("cost", T("b_cost"), `<div class="two"><div><small>${esc(T("cost_month"))}</small><b>${esc(M(mo.pay, f.currency))}</b></div><div><small>${esc(T("cost_cash"))}</small><b>${esc(M(mo.cash, f.currency))}</b></div></div>
      <div class="calc"><label>${esc(T("cost_down"))} <input type="number" min="0" max="100" step="5" data-c="down" value="${mo.down}">%</label><label>${esc(T("cost_rate"))} <input type="number" min="0" max="20" step="0.1" data-c="rate" value="${mo.rate}">%</label><label>${esc(T("cost_years"))} <input type="number" min="5" max="40" step="1" data-c="years" value="${mo.years}"></label></div>
      <p class="mut">${esc(T("cost_note", [String(mo.costsPct)]))}</p>
      ${re ? `<p>${esc(T("rent_line", [M(re.month, f.currency), String(re.yield)]))}${mo.pay ? ` ${esc(T(re.month >= mo.pay ? "rent_covers" : "rent_short"))}` : ""}</p>${re.real ? `<p class="mut">${esc(T("rent_real", [cityI.name]))}</p>` : ""}` : ""}`, { icon: "🏦", badge: T("estimate"), lock }));
    }
    // 4. price history and time on the market
    const hb = [];
    if (hist === undefined && me.ins === undefined) hb.push(skel);
    else {
      if (hist && hist.length > 1) hb.push(`<ul class="hist">${hist.slice(-5).map((h, i, a) => `<li><span>${esc(new Date(h.t).toLocaleDateString(RHS.lang, { day: "numeric", month: "short" }))}</span><b>${esc(M(h.price, f.currency))}</b>${i && h.price < a[i - 1].price ? ` <em class="pos">▼ ${Math.round((1 - h.price / a[i - 1].price) * 100)}%</em>` : i && h.price > a[i - 1].price ? ` <em class="neg">▲</em>` : ""}</li>`).join("")}</ul>`);
      else hb.push(`<p class="mut">${esc(T(hist && hist.length === 1 ? "hist_one" : "hist_none"))}</p>`);
      if (f.days != null) hb.push(`<p>${esc(T("days_listed", [String(f.days)]))}</p>`);
    }
    out.push(blk("hist", T("b_hist"), hb.join(""), { icon: "📈", lock }));
    // 5. same home elsewhere
    const dups = ins && ins.dups;
    if (me.ins === undefined) out.push(blk("dups", T("b_dups"), skel, { icon: "🔁", lock }));
    else if (dups && dups.length) out.push(blk("dups", T("b_dups"), `<ul class="lk">${dups.map((d) => `<li><a href="${esc(d.url)}" target="_blank" rel="noopener">${esc(RHS.portalName(d.portal))}</a> <b>${esc(M(d.price, f.currency))}</b>${d.price < f.price ? ` <em class="pos">−${esc(M(f.price - d.price, f.currency))}</em>` : ""}</li>`).join("")}</ul>`, { icon: "🔁", lock }));
    else if (ins) out.push(blk("dups", T("b_dups"), `<p class="mut">${esc(T("dups_none"))}</p>`, { icon: "🔁", lock }));
    // 6. within a walk, the neighbourhood, the centre and your place (v0.9)
    const loc = me.ctx.loc;
    const mp = prefs.myPlace;
    const myKm = mp && f.lat != null ? RHS.km(f.lat, f.lng, mp.lat, mp.lng) : null;
    const placeHtml = `<div class="lk2" style="margin-top:6px">${mp ? `<span class="mut">🏢 ${esc(T("my_place"))}: ${myKm != null ? `<b>${myKm < 1 ? Math.round(myKm * 1000) + " m" : myKm.toFixed(1) + " km"}</b> · ~${Math.max(2, Math.round(myKm * 1.35 / 35 * 60))} min 🚗 · ~${Math.max(2, Math.round(myKm * 1.25 / 18 * 60))} min 🚲` : esc(mp.label || mp.q)}</span> <button data-a="myplace">✎</button>` : `<button data-a="myplace">🏢 ${esc(T("my_place_set"))}</button>`}</div>${me.placeEdit ? `<div class="lk2"><input class="in" id="rh-place" placeholder="${esc(T("my_place_ph"))}" value="${esc(mp ? mp.q : "")}" style="margin-top:4px"><button data-a="placesave">${esc(T("save"))}</button>${mp ? `<button data-a="placedel">×</button>` : ""}</div><div class="err" id="rh-place-err"></div>` : ""}`;
    const areaLine = (() => { const bits = []; const ai = me.ctx.areaIdx; if (ai) { const d = Math.round((ai - 1) * 100); bits.push(d >= 5 ? "📈 " + T("area_hot", [String(d)]) : d <= -5 ? "📉 " + T("area_cheap", [String(-d)]) : "≈ " + T("area_avg")); } if (me.ctx.centreKm != null && me.ctx.cityName) bits.push("🎯 " + (me.ctx.centreKm < 1 ? T("centre_in", [me.ctx.cityName]) : T("centre_km", [me.ctx.centreKm.toFixed(1), me.ctx.cityName]))); return bits.length ? `<p class="mut">${bits.map(esc).join(" · ")}</p>` : ""; })();
    if (loc === undefined) out.push(blk("walk", T("b_walk"), skel, { icon: "🚶", lock }));
    else if (loc) {
      const it = [["transit", "🚌"], ["shop", "🛒"], ["food", "🍽"], ["school", "🏫"], ["health", "💊"], ["park", "🌳"], ["beach", "🏖"]].filter(([k]) => loc[k] != null);
      out.push(blk("walk", T("b_walk"), `<div class="chips">${it.map(([k, i]) => `<span class="${loc[k] > 0 ? "" : "off"}">${i} ${loc[k] >= 10 ? "10+" : loc[k]} ${esc(T("w_" + k))}</span>`).join("")}</div>${areaLine}<p class="mut">OpenStreetMap · 800 m${me.ctx.geoApprox ? " · " + esc(T("geo_approx")) : ""}</p>${placeHtml}`, { icon: "🚶", lock }));
    } else out.push(blk("walk", T("b_walk"), `<p class="mut">${esc(T(f.lat != null ? "loc_fail" : "loc_none"))}</p>${areaLine}${placeHtml}`, { icon: "🚶" }));
    // 7. size check and questions for the agent
    const sz = RHS.sizeNote(f);
    const qs = RHS.questions(f, r);
    out.push(blk("ask", T("b_ask"), `${sz ? `<p class="${sz.k === "small" ? "neg" : "pos"}">${esc(T("size_" + sz.k, [String(f.rooms), String(sz.per)]))}</p>` : ""}<ol class="qs">${qs.map((k) => `<li>${esc(T(k))}</li>`).join("")}</ol><button class="k s2 sm" data-a="copyq">⧉ ${esc(T("copy_questions"))}</button>`, { icon: "❓", lock }));
    // 8. better options in the same city
    const alts = ins && ins.alts;
    if (alts && alts.length) out.push(blk("alts", T("b_alts", [ins.city ? ins.city.name : ""]), `<ul class="lk">${alts.map((a) => `<li><a href="${esc(a.url)}" target="_blank" rel="noopener">${esc(M(a.price, f.currency))} · ${esc(a.sqm)} m²${a.rooms ? " · " + a.rooms + " " + esc(T("rank_rooms")) : ""}</a> <em class="pos">${esc(M(a.ppsqm, f.currency))}/m²</em>${a.area ? `<br><small>${esc(a.area)} · ${esc(RHS.portalName(a.portal))}</small>` : ""}</li>`).join("")}</ul>`, { icon: "✨", lock }));
    // 9. the city on RealHunt
    if (ins && ins.city && ins.city.median) out.push(blk("city", T("b_city", [ins.city.name]), `<p>${esc(T("city_line", [M(ins.city.median, f.currency), String(ins.city.n)]))}${ins.city.trend != null ? ` · <b class="${ins.city.trend > 0 ? "neg" : "pos"}">${ins.city.trend > 0 ? "▲" : "▼"} ${Math.abs(ins.city.trend)}%</b> ${esc(T("city_trend"))}` : ""}</p>`, { icon: "🏙" }));
    // 10. map and street view (v0.7)
    const where = f.lat != null && f.lng != null ? `${f.lat},${f.lng}` : [f.area, f.city, f.province].filter(Boolean).join(", ");
    if (where) out.push(blk("map", T("b_map"), `<div class="lk2"><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(where)}" target="_blank" rel="noopener">📍 ${esc(T("map_open"))}</a>${f.lat != null ? `<a href="https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${encodeURIComponent(where)}" target="_blank" rel="noopener">🛣 ${esc(T("street_view"))}</a>` : ""}</div>${f.lat == null ? `<p class="mut">${esc(where)}</p>` : ""}`, { icon: "🗺" }));
    // 11. your private notes and 👍/👎 (v0.7, kept in this browser only)
    const nt = me.note || {};
    out.push(blk("notes", T("b_notes"), `<textarea class="nt" id="rh-note" maxlength="1000" placeholder="${esc(T("notes_ph"))}">${esc(nt.text || "")}</textarea><div class="lk2"><button data-a="like" class="${nt.like === 1 ? "on" : ""}">👍 ${esc(T("like"))}</button><button data-a="dislike" class="${nt.like === -1 ? "on" : ""}">👎 ${esc(T("dislike"))}</button></div>`, { icon: "📝" }));
    // 12. share (v0.7)
    if (me.shareOpen) out.push(blk("share", T("b_share"), `<div class="lk2"><button data-a="sumcopy">⧉ ${esc(T("share_copy"))}</button><a href="https://wa.me/?text=${encodeURIComponent(summaryText(me))}" target="_blank" rel="noopener" data-a="wa">WhatsApp</a><a href="mailto:?subject=${encodeURIComponent((f.title || document.title || "").slice(0, 80))}&body=${encodeURIComponent(summaryText(me))}" data-a="mail">✉ Email</a></div>`, { icon: "↗" }));
    return out.join("");
  }
  // a plain-text summary of the home, for copy, WhatsApp or email
  function summaryText(me) {
    const { f, r } = me; const o = RHS.offer(f, me.ctx.bench, me.ins && me.ins.history, me.ctx.fair);
    const L = [`🏠 ${(f.title || document.title || "").trim().slice(0, 100)}`, `${M(f.price, f.currency)}${f.sqm ? " · " + f.sqm + " m²" : ""}${f.rooms ? " · " + f.rooms + " " + T("rank_rooms") : ""}`,
      `RealHunt Score ${r.score}/100 (${RHS.grade(r.score)})${r.pct != null ? ` · ${r.pct > 0 ? "+" : ""}${r.pct}% vs similar homes` : ""}`, r.verdict];
    if (o && o.hasFair) L.push(`${T("offer_open")}: ${M(o.open, f.currency)} · ${T("offer_max")}: ${M(o.max, f.currency)}`);
    L.push(location.href.split("?")[0]);
    return L.filter(Boolean).join("\n");
  }

  function siteLink(me) {
    const c = me.ins && me.ins.city;
    const u = (c ? c.url : "https://realhunt.co/best") + "?utm_source=extension&utm_medium=card&utm_campaign=" + encodeURIComponent(A.id);
    return `<a class="cta" href="${esc(u)}" target="_blank" rel="noopener" data-a="site">🏆 ${esc(c ? T("top10_city", [c.name]) : T("top10_any"))} →</a>`;
  }

  const noteFacts = (me) => ({ url: me.url, price: me.f.price, cur: me.f.currency, score: me.r && me.r.score, sqm: me.f.sqm || null, rooms: me.f.rooms || null, city: me.f.city || (me.ins && me.ins.city && me.ins.city.name) || null, deal: me.f.deal || "sale", ptype: me.f.ptype || null, country: me.f.country || null, portal: A.id });
  async function haggleText(me) {
    const { f, r } = me; const o = RHS.offer(f, me.ctx.bench, me.ins && me.ins.history, me.ctx.fair) || { open: f.price ? RHS.nice(f.price * 0.94) : null };
    return T("haggle_body", [M(o.open, f.currency), r.pct != null && r.pct > 0 ? T("haggle_arg_over", [String(r.pct)]) : T("haggle_arg_gen"), location.href.split("?")[0]]);
  }
  async function copy(text) { try { await navigator.clipboard.writeText(text); return true; } catch { return false; } }

  function renderCard() {
    const me = cur; if (!me || !me.r) return;
    const { f, r, hash } = me;
    const keepFocus = card && card.shadowRoot && card.shadowRoot.activeElement && card.shadowRoot.activeElement.id;
    const scroll = card && card.shadowRoot && card.shadowRoot.querySelector(".body") ? card.shadowRoot.querySelector(".body").scrollTop : 0;
    const typed = {}; if (card && card.shadowRoot) for (const id of ["rh-email", "rh-code", "rh-note", "rh-place"]) { const el = card.shadowRoot.getElementById(id); if (el) typed[id] = el.value; }
    if (card) card.remove();
    const { h, sh } = host("div"); card = h;
    if (!me.open) {
      const pill = document.createElement("div"); pill.className = "pill"; pill.style.background = RHS.color(r.score);
      pill.innerHTML = `<b>${r.score}</b><span>${RHS.grade(r.score)} · RealHunt</span>`; pill.title = r.verdict + "  (Alt+Shift+R)";
      pill.addEventListener("click", () => { me.open = true; state.min = false; send({ t: "pref", min: false }); renderCard(); });
      sh.appendChild(pill); document.documentElement.appendChild(h); return;
    }
    const quotaOk = state.email || me.allowed;
    const mini = r.parts.map((p) => `<div class="row${p.pending ? " pend" : ""}"><span>${esc(T("part_" + p.k) || p.label)}</span><div class="bar"><i style="width:${Math.round((p.pts / p.max) * 100)}%;background:${RHS.color((p.pts / p.max) * 100)}"></i></div><b>${p.pending ? "…" : p.na ? "—" : p.pts + "/" + p.max}</b></div>`).join("");
    const rows = me.expanded && quotaOk ? r.parts.map((p) => `<div class="r"><div class="l"><span>${esc(T("part_" + p.k) || p.label)}</span><span>${p.pending ? "…" : p.pts + "/" + p.max}</span></div><p>${esc(p.why)}</p></div>`).join("") : "";
    const gate = me.gate ? gateHtml(me.gate) : "";
    const consentAsk = !state.consent && !me.gate ? `<div class="gate">${esc(T("consent_short"))}<br><span class="mut">${esc(T("consent_more"))}</span><br><button class="k" data-a="consent" style="margin-top:8px">${esc(T("allow"))}</button></div>` : "";
    const locked = !quotaOk && !me.gate ? `<div class="unlock" data-a="open-gate"><span class="free">${FREE}</span> ${esc(T("unlock_blocks"))} →<br><small style="opacity:.75">${esc(T("unlock_once"))}</small></div>` : "";
    const bits = RHS.summaryBits(r, { f, offer: RHS.offer(f, me.ctx.bench, me.ins && me.ins.history, me.ctx.fair), hist: me.ins && me.ins.history, dups: me.ins && me.ins.dups, size: RHS.sizeNote(f) });
    // v0.9: what pushes the score up or down, and how sure we are
    const kn = r.parts.filter((p) => !p.na && !p.pending).map((p) => ({ k: p.k, q: p.pts / p.max }));
    const ups = kn.filter((p) => p.q >= 0.7).sort((a, b) => b.q - a.q).slice(0, 2), downs = kn.filter((p) => p.q <= 0.4).sort((a, b) => a.q - b.q).slice(0, 1);
    const reasons = ups.map((p) => "＋ " + T("part_" + p.k)).concat(downs.map((p) => "－ " + T("part_" + p.k)));
    const confK = (r.conf || 0) >= 0.75 && r.checked.includes("location") ? "conf_high" : (r.conf || 0) >= 0.5 ? "conf_med" : "conf_low";
    if (me.priceChange) bits.unshift({ k: me.priceChange.from > f.price ? "pc_down" : "pc_up", v: [MP(me.priceChange.from, f), MP(f.price, f), new Date(me.priceChange.t).toLocaleDateString(RHS.lang, { day: "numeric", month: "short" })] });
    const sum = `<div class="sum">${reasons.length ? `<b>${reasons.map(esc).join(" · ")}</b> · ` : ""}<span class="mut" title="${esc(T("conf_tip"))}">${esc(T(confK))}</span>${bits.length ? "<br>" + bits.map((b) => esc(T(b.k, b.v))).join(" · ") : ""}</div>`;
    const loading = me.ins === undefined || me.ctx.loc === undefined || (state.consent && !me.ctx.ai && (f.desc || "").length > 60 && !me.aiDone);
    const onb = !prefs.onb ? `<div class="onb"><b>${esc(T("onb_title"))}</b><ol><li>${esc(T("onb_1"))}</li><li>${esc(T("onb_2"))}</li><li>${esc(T("onb_3"))}</li></ol><button class="k sm" data-a="onb">${esc(T("onb_ok"))}</button></div>` : "";
    const div = document.createElement("div"); div.className = "c v5";
    if (prefs.pos) { div.style.left = Math.max(0, Math.min(innerWidth - 200, prefs.pos.x)) + "px"; div.style.top = Math.max(0, Math.min(innerHeight - 120, prefs.pos.y)) + "px"; div.style.right = "auto"; div.style.bottom = "auto"; }
    div.innerHTML = `<div class="h" data-drag="1"><div class="s" style="background:${RHS.color(r.score)}">${r.score}<small>${RHS.grade(r.score)}</small></div><div class="t"><b>RealHunt Score${r.ai ? ` <span class="ai">AI</span>` : ""}</b><small>${esc(MP(f.price, f))}${f.sqm ? " · " + f.sqm + " m²" : ""}${r.ppsqm ? " · " + esc(M(r.ppsqm, f.currency)) + "/m²" : f.rooms ? " · " + esc(M(f.price / f.rooms, f.currency)) + "/" + esc(T("unit_room")) : ""}${f.tenure && f.tenure.k === "lease" && f.tenure.years ? " · " + esc(M(f.price / f.tenure.years, f.currency)) + esc(T("per_lease_year")) : ""}</small></div><button class="x" data-a="min" aria-label="Minimise" title="Minimise (Alt+Shift+R)">–</button><button class="x" data-a="close" aria-label="Close">×</button></div>
      ${loading ? `<div class="ld"><i></i></div>` : ""}
      <div class="body">
      <div class="v">${esc(r.verdict)}</div>${sum}
      ${onb}${consentAsk}
      <div class="blocks">${blocksHtml(me)}</div>
      ${locked}${gate ? `<div class="p">${gate}</div>` : ""}
      <details class="det"${me.expanded ? " open" : ""}><summary>${esc(T("see_why"))}</summary><div class="mini">${mini}</div><div class="p">${rows}</div></details>
      </div>
      ${siteLink(me)}
      <div class="f"><button class="k s2" data-a="save">♡ ${esc(T("save"))}</button><button class="k s2" data-a="cmp">⇄ ${esc(T("compare"))}${me.cmpN ? ` (${me.cmpN})` : ""}</button><button class="k s2" data-a="share">↗ ${esc(T("share_short"))}</button><button class="k s2" data-a="panel">${esc(T("open_panel"))}</button></div>
      <div class="n">${esc(T("disclaimer"))} · <a href="#" data-a="wrong" style="color:inherit">⚑ ${esc(T("wrong_data"))}</a></div>`;
    div.addEventListener("toggle", (e) => { if (e.target.classList && e.target.classList.contains("det")) { me.expanded = e.target.open; if (quotaOk) send({ t: "pref", why: me.expanded }); if (me.expanded && !quotaOk && !me.gate) { me.gate = { step: "email" }; send({ t: "track", kind: "email_prompt" }); renderCard(); } } }, true);
    div.addEventListener("input", (e) => {
      if (e.target.id !== "rh-note") return;
      me.note = { ...(me.note || {}), text: e.target.value }; clearTimeout(div._nt);
      div._nt = setTimeout(() => send({ t: "note", hash, set: { text: me.note.text, ...noteFacts(me) } }), 500);
    });
    div.addEventListener("change", (e) => {
      const k = e.target.dataset && e.target.dataset.c; if (!k) return;
      prefs.calc = { ...(prefs.calc || {}), [k]: Number(e.target.value) }; send({ t: "pref", calc: prefs.calc }); renderCard();
    });
    div.addEventListener("click", async (e) => {
      const lockedBlk = e.target.closest(".blk.lock");
      if (lockedBlk && !me.gate) { const le = await send({ t: "lastEmail" }); me.gate = { step: "email", email: le || "" }; send({ t: "track", kind: "email_prompt", meta: { from: "blur" } }); renderCard(); const g = sh.querySelector(".gate"); g && g.scrollIntoView({ block: "center" }); return; }
      const el = e.target.closest("[data-a]"); const a = el && el.dataset.a; if (!a) return;
      if (a === "myplace") { me.placeEdit = !me.placeEdit; renderCard(); setTimeout(() => sh.getElementById("rh-place")?.focus(), 30); return; }
      if (a === "placedel") { prefs.myPlace = null; send({ t: "pref", myPlace: null }); me.placeEdit = false; renderCard(); return; }
      if (a === "placesave") {
        const q = ($("rh-place").value || "").trim(); if (q.length < 4) return;
        el.textContent = "…"; const g = await send({ t: "geocode", q });
        if (g && g.lat != null) { prefs.myPlace = { q, lat: g.lat, lng: g.lng, label: g.label || q }; send({ t: "pref", myPlace: prefs.myPlace }); me.placeEdit = false; send({ t: "track", kind: "my_place" }); renderCard(); }
        else { el.textContent = T("save"); const er = $("rh-place-err"); if (er) er.textContent = state.consent ? T("place_notfound") : T("consent_needed"); }
        return;
      }
      if (a === "wrong") { e.preventDefault(); send({ t: "track", kind: "wrong_data", meta: { url: me.url, price: f.price, sqm: f.sqm, rooms: f.rooms, portal: A.id } }); el.textContent = "✓ " + T("thanks"); return; }
      const $ = (id) => sh.getElementById(id);
      if (a === "site") { send({ t: "track", kind: "to_site", meta: { where: "card", city: me.ins && me.ins.city ? me.ins.city.slug : "" } }); return; }
      if (a === "close") { card.remove(); card = null; cur && (cur.closed = true); }
      if (a === "min") { state.min = true; me.open = false; send({ t: "pref", min: true }); renderCard(); }
      if (a === "onb") { prefs.onb = true; send({ t: "pref", onb: true }); renderCard(); }
      if (a === "open-gate") { const le = await send({ t: "lastEmail" }); me.gate = { step: "email", email: le || "" }; send({ t: "track", kind: "email_prompt" }); renderCard(); }
      if (a === "panel") { const ok = await send({ t: "openPanel" }); if (!ok) { me.expanded = true; renderCard(); } }
      if (a === "save") { await send({ t: "track", kind: "save", hash, price: f.price }); el.textContent = "♥ " + T("saved"); el.title = T(state.email ? "saved_alert" : "saved_alert_email"); const n = sh.querySelector(".n"); if (n) n.textContent = T(state.email ? "saved_alert" : "saved_alert_email"); }
      if (a === "share") { me.shareOpen = !me.shareOpen; renderCard(); if (me.shareOpen) { const s2 = sh.querySelector('[data-b="share"]'); s2 && s2.scrollIntoView({ block: "nearest" }); } }
      if (a === "sumcopy") { const ok = await copy(summaryText(me)); el.textContent = ok ? "✓ " + T("copied") : T("try_again"); send({ t: "track", kind: "share_copy" }); }
      if (a === "wa" || a === "mail") { send({ t: "track", kind: "share_" + a }); return; }
      if (a === "like" || a === "dislike") { const v = a === "like" ? 1 : -1; const nl = (me.note || {}).like === v ? 0 : v; me.note = { ...(me.note || {}), like: nl }; send({ t: "note", hash, set: { like: nl, ...noteFacts(me) } }); loadTaste(true); renderCard(); }
      if (a === "cmp") {
        const res = await send({ t: "compare", op: "add", item: { url: me.url, portal: A.id, price: f.price, cur: f.currency, sqm: f.sqm, rooms: f.rooms, score: r.score, pct: r.pct, area: f.area } });
        const n = res && res.list ? res.list.length : 1; me.cmpN = n;
        if (n >= 2 && me.cmpReady) { await send({ t: "compare", op: "open" }); me.cmpReady = false; }
        else { me.cmpReady = n >= 2; renderCard(); }
      }
      if (a === "haggle") { const ok = await copy(await haggleText(me)); el.textContent = ok ? "✓ " + T("copied") : T("try_again"); send({ t: "track", kind: "haggle" }); }
      if (a === "copyq") { const ok = await copy(RHS.questions(f, r).map((k, i) => `${i + 1}. ${T(k)}`).join("\n")); el.textContent = ok ? "✓ " + T("copied") : T("try_again"); }
      if (a === "consent") { await send({ t: "consent" }); await getState(); showDetail(); }
      if (a === "back") { me.gate = { step: "email", email: me.gate.email }; renderCard(); }
      if (a === "email") {
        const email = ($("rh-email").value || "").trim(), mk = $("rh-mk").checked;
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { me.gate = { step: "email", email, mk, err: T("bad_email") }; return renderCard(); }
        if (!state.consent) { await send({ t: "consent" }); await getState(); }
        el.disabled = true; el.textContent = "…";
        const res = await send({ t: "verifyStart", email, lang: RHS.lang });
        me.gate = res && res.ok ? { step: "code", email, mk } : { step: "email", email, mk, err: res && res.error === "wait" ? T("wait_code") : T("try_again") };
        renderCard();
      }
      if (a === "code") {
        const code = ($("rh-code").value || "").replace(/\D/g, "");
        const res = await send({ t: "verifyCheck", code, marketing: !!me.gate.mk });
        if (res && res.ok) { await getState(); me.gate = null; me.expanded = true; renderCard(); send({ t: "track", kind: "lead" }); }
        else { me.gate = { ...me.gate, err: res && res.error === "expired" ? T("code_expired") : T("code_wrong") }; renderCard(); }
      }
    });
    // drag the card by its header; the position is remembered
    div.querySelector("[data-drag]").addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      const r0 = div.getBoundingClientRect(), dx = e.clientX - r0.left, dy = e.clientY - r0.top;
      const mv = (ev) => { const x = Math.max(0, Math.min(innerWidth - 120, ev.clientX - dx)), y = Math.max(0, Math.min(innerHeight - 60, ev.clientY - dy)); Object.assign(div.style, { left: x + "px", top: y + "px", right: "auto", bottom: "auto" }); };
      const up = () => { removeEventListener("pointermove", mv); removeEventListener("pointerup", up); const b = div.getBoundingClientRect(); prefs.pos = { x: Math.round(b.left), y: Math.round(b.top) }; send({ t: "pref", pos: prefs.pos }); };
      addEventListener("pointermove", mv); addEventListener("pointerup", up);
    });
    div.querySelector("[data-drag]").addEventListener("dblclick", () => { prefs.pos = null; send({ t: "pref", pos: null }); renderCard(); });
    div.addEventListener("keydown", (e) => { if (e.key === "Enter") { const id = e.target.id; if (id === "rh-email") div.querySelector('[data-a="email"]').click(); if (id === "rh-code") div.querySelector('[data-a="code"]').click(); if (id === "rh-place") div.querySelector('[data-a="placesave"]')?.click(); } e.stopPropagation(); });
    sh.appendChild(div);
    document.documentElement.appendChild(h);
    const b = sh.querySelector(".body"); if (b) b.scrollTop = scroll;
    for (const id in typed) { const el = sh.getElementById(id); if (el && !el.value) el.value = typed[id]; }
    if (keepFocus) sh.getElementById(keepFocus)?.focus();
  }
  // v0.7: Esc minimises the open card (not while typing in the page)
  addEventListener("keydown", (e) => {
    if (e.key !== "Escape" || !cur || !cur.r || !cur.open || !card) return;
    const t = document.activeElement; if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
    cur.open = false; renderCard();
  });
  // Alt+Shift+R: open or minimise the card (on a search page: rank the whole search)
  addEventListener("keydown", (e) => {
    if (!(e.altKey && e.shiftKey && (e.key === "R" || e.key === "r" || e.code === "KeyR"))) return;
    if (cur && cur.r) { cur.open = !cur.open; state.min = !cur.open; send({ t: "pref", min: state.min }); renderCard(); }
    else if (!rk && !isDet() && lastScan.length >= 3) { if (fab) { fab.remove(); fab = null; } startRank(); }
  });


  // ---------------------------------------------------------------- rank the whole search: one click, reads page after page (up to 500)
  const RANK_MAX = 500;
  let rk = null, fab = null;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const HOST = location.hostname.replace(/^www\./, "");
  let lastRank; // the last ranking saved for this site (v0.7)
  // v0.7: one bar at the bottom left: rank the whole search, jump to the best home here, hide weak homes, reopen the last ranking
  async function showFab(n) {
    if (rk || isDet() || n < 3) { if (fab) { fab.remove(); fab = null; } return; }
    if (lastRank === undefined) lastRank = (await send({ t: "lastRank", host: HOST })) || null;
    const off = (prefs.fabOff || []).includes(HOST);
    const best = [...lastScan].filter((x) => x.c.el && x.c.el.isConnected).sort((a, b) => b.r.score - a.r.score)[0];
    const sig = [off, best && best.c.url, best && best.r.score, !!prefs.dim, !!lastRank].join("|");
    if (fab && fab.isConnected && fab._sig === sig) return;
    if (fab) fab.remove();
    const { h, sh } = host("div"); fab = h; fab._sig = sig;
    const bar = document.createElement("div"); bar.className = "bar7";
    if (off) bar.innerHTML = `<button class="chip dk" data-a="unhide" title="${esc(T("rank_cta"))}">⚡</button>`;
    else bar.innerHTML = `<div class="fab" data-a="rank"><b>⚡</b><div>${esc(T(RHS.pageDeal === "rent" ? "rank_cta_rent" : "rank_cta"))}<small>${esc(T("rank_sub"))}</small></div></div>`
      + (best ? `<button class="chip" data-a="best">🏆 ${esc(T("best_here"))} <i style="background:${RHS.color(best.r.score)}">${best.r.score}</i> ${esc(RHS.money(best.c.f.price, best.c.f.currency))}</button>` : "")
      + `<button class="chip${prefs.dim ? " on" : ""}" data-a="dim">◐ ${esc(T(prefs.dim ? "show_all" : "hide_weak"))}</button>`
      + (lastRank && lastRank.items && lastRank.items.length ? `<button class="chip" data-a="last">↺ ${esc(T("last_rank", [String(lastRank.items.length)]))}</button>` : "")
      + `<button class="chip xx" data-a="hide" title="${esc(T("fab_hide"))}">×</button>`;
    bar.addEventListener("click", (e) => {
      const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return;
      if (a === "rank") { fab.remove(); fab = null; startRank(); }
      if (a === "best" && best) { best.c.el.scrollIntoView({ behavior: "smooth", block: "center" }); const el = best.c.el; el.animate && el.animate([{ boxShadow: "0 0 0 0 rgba(233,184,12,.9)" }, { boxShadow: "0 0 0 14px rgba(233,184,12,0)" }], { duration: 900, iterations: 2 }); send({ t: "track", kind: "best_jump" }); }
      if (a === "dim") { prefs.dim = !prefs.dim; send({ t: "pref", dim: prefs.dim }); paintPage(); showFab(n); }
      if (a === "hide" || a === "unhide") { const L = new Set(prefs.fabOff || []); a === "hide" ? L.add(HOST) : L.delete(HOST); prefs.fabOff = [...L].slice(-200); send({ t: "pref", fabOff: prefs.fabOff }); showFab(n); }
      if (a === "last") { fab.remove(); fab = null; openLastRank(); }
    });
    sh.appendChild(bar); document.documentElement.appendChild(h);
  }
  const keyOf = (u) => { try { const x = new URL(u, location.href); return x.hostname + x.pathname.replace(/\/$/, ""); } catch { return u; } };
  function addItems(list) {
    let fresh = 0;
    for (const c of list) { if (!c || !c.url || !c.f || !c.f.price) continue; const k = keyOf(c.url); if (rk.items.has(k)) continue; rk.items.set(k, { url: c.url.split("#")[0], f: c.f, page: rk.pages + 1 }); fresh++; }
    return fresh;
  }
  function guessNext(u, n) {
    const x = new URL(u); for (const k of ["page", "pag", "pagina", "pn", "p", "pagenumber", "pageNr", "o"]) if (x.searchParams.has(k) && /^\d+$/.test(x.searchParams.get(k))) { x.searchParams.set(k, String(+x.searchParams.get(k) + 1)); return x.href; }
    if ((RHS.recipe && RHS.recipe.pageParam) || n === 1) { x.searchParams.set((RHS.recipe && RHS.recipe.pageParam) || "page", String(n + 1)); return x.href; }
    return null;
  }
  async function toServer(list) {
    const items = [];
    for (const c of list) { let path = ""; try { path = new URL(c.url).pathname; } catch { continue; } if (sent.has(path)) continue; sent.add(path);
      const f = c.f; if (!f.price || !(f.sqm || f.rooms)) continue; // v0.7: homes without m² go with their bedrooms
      if (f.status === "off" || f.status === "short") continue;
      items.push({ h: await RHS.hash(`${A.id}:${path}`), deal: f.deal || "sale", portal: A.id, pp: ppOf(f), cur: f.currency, rooms: f.rooms || null, ten: tenOf(f), ...factsOf(f), lat: f.lat ?? null, lng: f.lng ?? null, area: f.area || "", price: f.price, sqm: f.sqm, url: c.url.split("?")[0], country: f.country }); }
    for (let i = 0; i < items.length; i += 60) send({ t: "cards", rank: true, portal: A.id, area: A.areaKey(), city: cityHint(null), items: items.slice(i, i + 60) });
  }
  // how many homes the search says it has ("1.234 results"), to show progress and time left
  function totalOf(doc) {
    const t = [doc.title, (doc.querySelector("h1") || {}).textContent || "", ((doc.body && doc.body.innerText) || "").slice(0, 4000)].join(" \n ");
    const m = t.match(/(\d{1,3}(?:[.,\s]\d{3})+|\d{2,6})\s*(?:\+\s*)?(?:results|resultados|resultats|résultats|risultati|ergebnisse|resultaten|resultater|homes|properties|propiedades|inmuebles|viviendas|pisos|casas|boliger|annonces|biens|immobili|annunci|objekte|immobilien|woningen|imóveis|listings|villas)\b/i);
    const n = m ? RHS.num(m[1]) : null; return n && n >= 10 && n < 200000 ? n : null;
  }
  async function startRank() {
    rk = { items: new Map(), pages: 0, running: true, stop: false, blocked: false, visited: new Set([keyOf(location.href) + location.search]), onlySqm: false, t0: Date.now(), total: totalOf(document), times: [] };
    const first = A.cards().map((c) => ({ url: c.url, f: c.f }));
    addItems(first); rk.pages = 1; rk.perPage = first.length || 20; renderRank(); toServer(first);
    send({ t: "track", kind: "rank_start", meta: { portal: A.id, n: first.length } });
    if (state.consent) { const g = first.find((c) => c.f.lat != null); send({ t: "insights", p: { city: cityHint(null), country: RHS.siteCountry(location.hostname) || (first[0] && first[0].f.country), lat: g ? g.f.lat : null, lng: g ? g.f.lng : null, url: location.href, currency: first[0] && first[0].f.currency } }).then((ins) => { if (rk && ins && ins.city) { rk.city = ins.city; renderRank(true); } }); }
    const url = RHS.nextPageUrl(document, location.href) || (first.length >= 8 ? guessNext(location.href, 1) : null);
    // learn the page-number pattern from page 2's address, so we can keep going when a page shows no "next" link
    const re2 = /([/=_-]|page|pagina|pag|side|seite)2(?=\/?$|\/?[?&#]|\.\w{2,5}$)/i;
    rk.tpl = url && re2.test(url) ? (n) => url.replace(re2, "$1" + n) : null;
    await rankLoop(url);
  }
  async function rankLoop(url) {
    const me = rk; let misses = 0; me.running = true; me.blocked = false; me.stop = false; me.next = null;
    while (url && !me.stop && me.pages < RANK_MAX) {
      const vk = keyOf(url) + new URL(url).search; if (me.visited.has(vk)) break; me.visited.add(vk);
      me.loading = me.pages + 1; renderRank();
      const t1 = Date.now();
      await sleep(1100 + Math.random() * 1400); // polite: about one page every 1-2.5 seconds, like a person clicking "next"
      if (me.stop) { me.visited.delete(vk); me.next = url; break; }
      let html = "";
      try { const res = await fetch(url, { credentials: "include" }); if (res.status === 403 || res.status === 429) { me.blocked = true; me.visited.delete(vk); me.next = url; break; } if (!res.ok) break; html = await res.text(); } catch { me.next = url; me.visited.delete(vk); break; }
      if (html.length < 80000 && /captcha|are you a robot|access denied|px-captcha|cf-chl|datadome|geo\.captcha|unusual traffic/i.test(html)) { me.blocked = true; me.visited.delete(vk); me.next = url; break; }
      const doc = new DOMParser().parseFromString(html, "text/html");
      let got = []; try { got = A.cardsFrom(doc, url); } catch { got = []; }
      const fresh = addItems(got); me.pages++; me.times.push(Date.now() - t1); if (me.times.length > 8) me.times.shift();
      if (!fresh) { if (++misses >= 2) break; } else { misses = 0; toServer(got); }
      if (rk !== me) return;
      renderRank();
      const nx = RHS.nextPageUrl(doc, url);
      url = (nx && !me.visited.has(keyOf(nx) + new URL(nx).search) ? nx : null) || (me.tpl ? me.tpl(me.pages + 1) : null) || guessNext(url, me.pages);
    }
    if (rk !== me) return;
    me.running = false; me.loading = 0; renderRank(true); saveRank(); uploadScores();
    if (!me.stop && me.items.size >= 5) deepCheck(30); // v0.8: then read the best 30 listings in full
    send({ t: "track", kind: "rank_done", meta: { portal: A.id, pages: me.pages, n: me.items.size, blocked: me.blocked, secs: Math.round((Date.now() - me.t0) / 1000) } });
  }
  // v0.7: keep the last ranking of this site, to reopen it without reading the pages again
  function saveRank() {
    if (!rk || rk.items.size < 3) return;
    const { list } = ranked();
    lastRank = { host: HOST, src: location.href.split("#")[0], title: ((document.querySelector("h1") || {}).textContent || document.title).trim().slice(0, 110), pages: rk.pages,
      items: list.slice(0, 300).map((x) => ({ url: x.url, f: { price: x.f.price, currency: x.f.currency, sqm: x.f.sqm, rooms: x.f.rooms, baths: x.f.baths || null, year: x.f.year || null, lot: x.f.lot || null, drop: x.f.drop || null, ptype: x.f.ptype || null, zip: x.f.zip || null, city: x.f.city || null, area: x.f.area || "", title: (x.f.title || "").slice(0, 90), desc: x.f.deep ? (x.f.desc || "").slice(0, 1500) : (x.f.desc || "").slice(0, 300), deep: !!x.f.deep, tenure: x.f.tenure || null } })) };
    send({ t: "lastRank", save: lastRank });
  }
  function openLastRank() {
    if (!lastRank) return;
    rk = { items: new Map(), pages: lastRank.pages || 1, running: false, stop: true, blocked: false, visited: new Set(), onlySqm: false, t0: Date.now(), restored: lastRank.t, times: [] };
    for (const x of lastRank.items) rk.items.set(keyOf(x.url), { url: x.url, f: x.f, page: 1 });
    renderRank(true);
  }
  // v0.8: open the best homes one by one (politely, in the background) and read the whole listing: description, photos,
  // map point, year, bathrooms, plot, days listed and every red-flag word. Then score them again with everything, map included.
  async function deepCheck(n) {
    if (!rk || (rk.deep && rk.deep.running)) return;
    const me = rk; const top = ranked().list.filter((x) => !x.f.deep).slice(0, n);
    if (!top.length) return;
    me.deep = { running: true, done: 0, total: top.length, stop: false }; renderRank(true);
    send({ t: "track", kind: "rank_deep", meta: { n: top.length } });
    let geo = 0;
    for (const x of top) {
      if (me.deep.stop || rk !== me) break;
      await sleep(900 + Math.random() * 1300);
      try {
        const res = await fetch(x.url, { credentials: "include" });
        if (res.status === 403 || res.status === 429) break;
        if (res.ok) {
          const html = await res.text();
          if (!(html.length < 80000 && /captcha|are you a robot|access denied|px-captcha|cf-chl|datadome/i.test(html))) {
            const doc = new DOMParser().parseFromString(html, "text/html");
            let d = null; try { d = RHS.genericDetail(doc, x.url, RHS.recipe || null); } catch { d = null; }
            const body = ((doc.body && doc.body.textContent) || "").replace(/\s+/g, " ");
            const f = x.f; const desc = (d && d.desc && d.desc.length > 80 ? d.desc : body.slice(0, 5000));
            const fx = RHS.facts(desc + " " + body.slice(0, 12000));
            for (const k of ["baths", "year", "lot", "hoa", "days", "drop"]) if (f[k] == null && fx[k] != null) f[k] = fx[k];
            if (!f.sqm && d && d.sqm) f.sqm = d.sqm; if (!f.rooms && d && d.rooms) f.rooms = d.rooms;
            if (d) { if (d.lat != null && f.lat == null) { f.lat = d.lat; f.lng = d.lng; } if (d.photos) f.photos = d.photos; if (d.days != null && f.days == null) f.days = d.days; if (d.extra) f.extra = d.extra; if (d.tenure && !f.tenure) f.tenure = d.tenure; }
            f.desc = desc.slice(0, 6000); f.deep = true;
            if (f.lat != null && geo < 12) { geo++; send({ t: "nearby", lat: f.lat, lng: f.lng }).then((loc) => { f._loc = loc || null; if (rk === me) { me.ver = (me.ver || 0) + 1; renderRank(); } }); }
          }
        }
      } catch { /* skip this one */ }
      me.deep.done++; me.ver = (me.ver || 0) + 1; renderRank();
    }
    me.deep.running = false; me.ver = (me.ver || 0) + 1; renderRank(true); saveRank(); uploadScores();
  }
  // v0.10: send the final scores (after reading the best ones in full) so the top homes appear on realhunt.co
  async function uploadScores() {
    if (!rk || !state.consent) return;
    const { list } = ranked(); const items = []; let top = 0;
    for (const x of list) { let path = ""; try { path = new URL(x.url).pathname; } catch { continue; } const f = x.f; if (!f.price || !(f.sqm || f.rooms)) continue;
      if (x.r.score >= 85) top++;
      items.push({ h: await RHS.hash(`${A.id}:${path}`), ...scoreOf(x.r, f), portal: A.id, pp: ppOf(f), cur: f.currency, rooms: f.rooms || null, ten: tenOf(f), ...factsOf(f), lat: f.lat ?? null, lng: f.lng ?? null, area: f.area || "", price: f.price, sqm: f.sqm, url: x.url.split("?")[0], country: f.country }); }
    for (let i = 0; i < items.length; i += 60) send({ t: "cards", rank: true, portal: A.id, area: A.areaKey(), city: cityHint(null), items: items.slice(i, i + 60), top: i ? 0 : top });
    rk.uploaded = items.length; rk.topN = top; renderRank(true);
  }
  function ranked() {
    const all = [...rk.items.values()];
    const pp = all.map((x) => (x.f.price && x.f.sqm ? x.f.price / x.f.sqm : null)).filter(Boolean);
    const bench = pp.length >= 5 ? RHS.median(pp) : null;
    // v0.8: one fair-price model over every home read so far (size, bedrooms, bathrooms, lot, age, type, exact area)
    if (!rk._cache || rk._cache.n !== all.length || rk._cache.v !== rk.ver) {
      all.forEach((x) => RHS.enrich(x.f));
      const RS = RHS.scoreGroup(all.map((x) => x.f), { profile: profileFor(rk.deal || RHS.pageDeal), loc: null });
      rk._cache = { n: all.length, v: rk.ver, list: all.map((x, i) => ({ ...x, r: RS[i] })) };
    }
    let out = rk._cache.list;
    rk.off = out.filter((x) => x.f.status === "off").length;
    const F = rk.flt || {};
    const mp = prefs.myPlace;
    for (const x of out) x.km = mp && x.f.lat != null ? RHS.km(x.f.lat, x.f.lng, mp.lat, mp.lng) : null;
    rk.deals = { sale: 0, rent: 0 }; for (const x of out) if (x.f.status !== "off" && x.f.status !== "short") rk.deals[x.f.deal === "rent" ? "rent" : "sale"]++;
    if (!rk.deal) rk.deal = rk.deals.rent > rk.deals.sale ? "rent" : "sale";
    out = out.filter((x) => x.f.status !== "off" && x.f.status !== "short" && (x.f.deal === "rent" ? "rent" : "sale") === rk.deal && (!prefs.rkHideNo || !taste || taste.get(keyOf(x.url)) !== -1) && (!prefs.rkOnlyDeep || x.f.deep) && (!rk.onlySqm || x.f.sqm) && (!F.pmax || x.f.price <= F.pmax) && (!F.smin || (x.f.sqm || 0) >= F.smin) && (!F.rmin || (x.f.rooms || 0) >= F.rmin) && (!F.scmin || x.r.score >= F.scmin));
    const S = rk.sort || "score";
    const fit = (x) => (x.r.parts.find((p) => p.k === "fit") || {}).pts || 0;
    out.sort(S === "near" ? (a, b) => (a.km ?? 1e9) - (b.km ?? 1e9) || b.r.score - a.r.score : S === "fairgap" ? (a, b) => (a.r.pct ?? 999) - (b.r.pct ?? 999) : S === "ppsqm" ? (a, b) => (a.r.ppsqm || 1e12) - (b.r.ppsqm || 1e12) : S === "price" ? (a, b) => a.f.price - b.f.price : S === "fit" ? (a, b) => fit(b) - fit(a) || b.r.score - a.r.score : (a, b) => b.r.score - a.r.score || (a.r.pct ?? 0) - (b.r.pct ?? 0));
    return { list: out, bench, cur: (all[0] && all[0].f.currency) || "EUR", total: all.length };
  }
  const csvCell = (v) => { const x = String(v ?? ""); return /[",\n;]/.test(x) ? '"' + x.replace(/"/g, '""') + '"' : x; };
  let rkEl = null, rkT = 0;
  function renderRank(force) {
    if (!rk) return;
    const now = Date.now(); if (!force && rk.running && now - rkT < 350) { clearTimeout(renderRank.t); renderRank.t = setTimeout(() => renderRank(true), 360); return; } rkT = now;
    const old = rkEl && rkEl.shadowRoot;
    const scroll = old && old.querySelector(".rk-l") ? old.querySelector(".rk-l").scrollTop : 0;
    // v0.7: keep the cursor in a filter box while the list refreshes underneath
    const ae = old && old.activeElement; const focusF = ae && ae.dataset && ae.dataset.f; const caret = ae && ae.selectionStart != null ? (() => { try { return ae.selectionStart; } catch { return null; } })() : null; const typedV = ae && focusF ? ae.value : null;
    if (rkEl) rkEl.remove();
    const { h, sh } = host("div"); rkEl = h;
    const { list, bench, cur } = ranked();
    let st = rk.running ? T("rank_loading", [String(rk.loading || rk.pages), String(rk.items.size)]) : rk.blocked ? T("rank_blocked", [String(rk.items.size), String(rk.pages)]) : T("rank_done", [String(rk.items.size), String(rk.pages)]);
    if (rk.deep && rk.deep.running) st = T("rank_deep", [String(rk.deep.done), String(rk.deep.total)]);
    if (rk.restored) st = T("rank_restored", [String(rk.items.size), new Date(rk.restored).toLocaleDateString(RHS.lang, { day: "numeric", month: "short" })]);
    // progress and time left, when the site tells how many homes the search has
    let prog = 100, eta = "";
    if (rk.total) { prog = Math.min(100, Math.round((rk.items.size / rk.total) * 100)); }
    if (rk.running && rk.total && rk.times.length) { const per = rk.times.reduce((a, b) => a + b, 0) / rk.times.length; const left = Math.max(0, Math.ceil((rk.total - rk.items.size) / Math.max(1, rk.perPage))); const mins = Math.max(1, Math.round((Math.min(left, RANK_MAX - rk.pages) * per) / 60000)); if (left > 0) eta = " · " + T("rank_eta", [String(mins)]); }
    const rows = list.slice(0, 300).map((x, i) => { const f = x.f, r = x.r; const pct = r.pct != null && Math.abs(r.pct) >= 3 ? `<i style="background:${r.pct < 0 ? "#E3F4E8;color:#0F6B34" : "#FBE9E5;color:#C2412D"}">${r.pct < 0 ? "−" : "+"}${Math.abs(r.pct)}%</i>` : "";
      const seen = recent && recent.has(x.url.split("?")[0]) ? ` <i title="${esc(T("seen_before"))}" style="background:#eef0f2;color:#14181c">👁</i>` : "";
      const facts = [f.baths ? f.baths + " " + T("baths_short") : "", f.year ? "🏗 " + f.year : "", f.drop ? "↓ " + RHS.money(f.drop, f.currency) : "", r.fair ? T("fair_short") + " ≈ " + RHS.money(RHS.nice(r.fair), f.currency) : ""].filter(Boolean).join(" · ");
      const fl = r.flags && r.flags.length ? ` <i style="background:#FBE9E5;color:#C2412D" title="${esc(r.flags.map((y) => y.label).join("; "))}">⚠ ${esc(r.flags[0].label.slice(0, 26))}</i>` : "";
      const tl = taste && taste.get(keyOf(x.url)); const likeM = tl === 1 ? " ♥" : tl === -1 ? " 👎" : "";
      const kmM = x.km != null ? ` <i style="background:#eef0f2;color:#14181c" title="${esc(T("my_place"))}">🏢 ${x.km < 1 ? Math.round(x.km * 1000) + " m" : x.km.toFixed(1) + " km"}</i>` : "";
      const deep = f.deep ? ` <i style="background:#E3F4E8;color:#0F6B34" title="${esc(T("deep_done"))}">✓</i>` : "";
      return `<a class="rk-r" href="${esc(x.url)}" target="_blank" rel="noopener"><span class="n">${i + 1}</span><span class="sc" style="background:${RHS.color(r.score)}">${r.score}</span><span class="d"><b>${esc(MP(f.price, f))}</b>${f.sqm ? ` · ${f.sqm} m²` : ""}${f.rooms ? ` · ${f.rooms} ${esc(T("rank_rooms"))}` : ""}${pct}${likeM}${deep}${kmM}${seen}${fl}${facts ? `<span class="fx">${esc(facts)}</span>` : ""}<span>${esc((f.title || f.area || f.desc || "").slice(0, 90))}</span></span></a>`; }).join("");
    const div = document.createElement("div"); div.className = "rk";
    div.innerHTML = `<div class="rk-h"><div class="top"><b>⚡ ${esc(T("rank_title"))}</b><button class="x" data-a="close" aria-label="Close">×</button></div>
      <div class="st">${esc(st)}${esc(eta)}${bench ? " · " + esc(T("rank_median")) + " " + esc(RHS.money(bench, cur)) + "/m²" : ""}</div>
      <div class="rk-bar${rk.running || (rk.deep && rk.deep.running) ? " run" : ""}"><i style="width:${rk.deep && rk.deep.running ? Math.max(4, Math.round((rk.deep.done / rk.deep.total) * 100)) : rk.running ? Math.max(4, prog) : 100}%"></i></div>
      <div class="rk-tools">${rk.running ? `<button data-a="stop">${esc(T("rank_stop"))}</button>` : rk.next && !rk.restored ? `<button class="go" data-a="resume">▶ ${esc(T("rank_continue"))}</button>` : ""}<button data-a="sqm" class="${rk.onlySqm ? "on" : ""}">${esc(T("rank_only_sqm"))}</button><button data-a="onlydeep" class="${prefs.rkOnlyDeep ? "on" : ""}">✓ ${esc(T("rank_only_deep"))}</button><button data-a="hideno" class="${prefs.rkHideNo ? "on" : ""}">👎 ${esc(T("rank_hide_no"))}</button>${!rk.running && !(rk.deep && rk.deep.running) && list.length ? `<button class="go" data-a="deep">🔍 ${esc(T("rank_deep_btn"))}</button>` : ""}${rk.deep && rk.deep.running ? `<button data-a="deepstop">${esc(T("rank_stop"))}</button>` : ""}${rk.deals && rk.deals.sale && rk.deals.rent ? `<button data-a="dsale" class="${rk.deal === "sale" ? "on" : ""}">🏠 ${esc(T("deal_sale"))} (${rk.deals.sale})</button><button data-a="drent" class="${rk.deal === "rent" ? "on" : ""}">🔑 ${esc(T("deal_rent"))} (${rk.deals.rent})</button>` : ""}<button data-a="cmp3">⇄ ${esc(T("rank_cmp3"))}</button><button data-a="top10">⧉ ${esc(T("rank_copy10"))}</button><button data-a="csv">CSV</button><button data-a="rshare">↗ ${esc(T("rank_share"))}</button></div>
      <div class="rk-filt"><label>${esc(T("f_pmax"))}<input type="number" data-f="pmax" value="${(rk.flt || {}).pmax || ""}" placeholder="—"></label><label>m² ≥<input type="number" data-f="smin" value="${(rk.flt || {}).smin || ""}" placeholder="—"></label><label>${esc(T("rank_rooms"))} ≥<input type="number" data-f="rmin" value="${(rk.flt || {}).rmin || ""}" placeholder="—"></label><label>${esc(T("f_score"))} ≥<input type="number" data-f="scmin" value="${(rk.flt || {}).scmin || ""}" placeholder="—"></label>
        <select data-f="sort">${["score", "fairgap", "ppsqm", "price", "fit"].concat(prefs.myPlace ? ["near"] : []).map((k) => `<option value="${k}"${(rk.sort || "score") === k ? " selected" : ""}>${esc(T("sort_" + k))}</option>`).join("")}</select></div>
      ${rk.city ? `<a class="cta sm2" href="${esc(rk.city.url)}?utm_source=extension&utm_medium=ranking" target="_blank" rel="noopener" data-a="site">🏆 ${esc(T("top10_city", [rk.city.name]))} →</a>` : ""}
      ${list.length !== rk.items.size ? `<div class="st">${esc(T("rank_showing", [String(list.length), String(rk.items.size)]))}${rk.off ? " · " + esc(T("hidden_off", [String(rk.off)])) : ""}</div>` : ""}
      <div class="st">${esc(T("rank_basis"))}</div>${rk.uploaded ? `<div class="st">🌍 ${esc(T("rank_uploaded", [String(rk.uploaded), String(rk.topN || 0)]))} <a href="https://realhunt.co/best?utm_source=extension&utm_medium=ranking" target="_blank" rel="noopener" data-a="site">realhunt.co/best →</a></div>` : ""}</div>
      <div class="rk-l">${rows || `<div class="n" style="padding:14px">${esc(T("rank_empty"))}</div>`}</div>
      <div class="rk-f">${esc(T("rank_fine"))}</div>`;
    div.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-a]"); const a = btn && btn.dataset.a; if (!a) return;
      if (a === "close") { rk.stop = true; if (!rk.restored) saveRank(); rkEl.remove(); rkEl = null; rk = null; scanCards(); return; }
      if (a === "stop") { rk.stop = true; }
      if (a === "deep") { deepCheck(30); }
      if (a === "dsale" || a === "drent") { rk.deal = a === "drent" ? "rent" : "sale"; rk.ver = (rk.ver || 0) + 1; renderRank(true); }
      if (a === "cmp3") { const { list: L } = ranked(); (async () => { await send({ t: "compare", op: "clear" }); for (const x of L.slice(0, 3)) await send({ t: "compare", op: "add", item: { url: x.url, portal: A.id, price: x.f.price, cur: x.f.currency, sqm: x.f.sqm, rooms: x.f.rooms, score: x.r.score, pct: x.r.pct, area: x.f.area || x.f.city || "" } }); const r = await send({ t: "compare", op: "open" }); btn.textContent = r && r.url ? "✓" : T(r && r.error === "few" ? "compare_hint" : "consent_needed"); })(); }
      if (a === "deepstop" && rk.deep) { rk.deep.stop = true; }
      if (a === "resume" && rk.next) { const u = rk.next; rk.next = null; rankLoop(u); send({ t: "track", kind: "rank_resume" }); }
      if (a === "sqm") { rk.onlySqm = !rk.onlySqm; renderRank(true); }
      if (a === "onlydeep") { prefs.rkOnlyDeep = !prefs.rkOnlyDeep; send({ t: "pref", rkOnlyDeep: prefs.rkOnlyDeep }); renderRank(true); }
      if (a === "hideno") { prefs.rkHideNo = !prefs.rkHideNo; send({ t: "pref", rkHideNo: prefs.rkHideNo }); loadTaste(true).then(() => renderRank(true)); }
      if (a === "site") { send({ t: "track", kind: "to_site", meta: { where: "ranking" } }); return; }
      if (a === "top10") {
        const { list: L } = ranked();
        const txt = [`⚡ RealHunt · ${((document.querySelector("h1") || {}).textContent || document.title).trim().slice(0, 80)}`, ...L.slice(0, 10).map((x, i) => `${i + 1}. ${x.r.score}/100 · ${RHS.money(x.f.price, x.f.currency)}${x.f.sqm ? " · " + x.f.sqm + " m²" : ""}${x.f.rooms ? " · " + x.f.rooms + " " + T("rank_rooms") : ""} — ${x.url}`)].join("\n");
        copy(txt).then((ok) => { btn.textContent = ok ? "✓ " + T("copied") : T("try_again"); }); send({ t: "track", kind: "rank_copy10" });
      }
      if (a === "rshare") {
        const { list: L } = ranked(); btn.textContent = "…";
        send({ t: "shareRanking", title: ((document.querySelector("h1") || {}).textContent || document.title).trim().slice(0, 110), cc: RHS.siteCountry(location.hostname), city: rk.city ? rk.city.name : "", src: location.href.split("#")[0],
          items: L.slice(0, 300).map((x) => ({ url: x.url, portal: A.id, price: x.f.price, cur: x.f.currency, sqm: x.f.sqm, rooms: x.f.rooms, score: x.r.score, pct: x.r.pct, area: x.f.area || "" })) })
          .then((r) => { btn.textContent = r && r.url ? "✓ " + T("rank_shared") : (r && r.error === "consent" ? T("consent_needed") : T("try_again")); if (r && r.url) copy(r.url); });
      }
      if (a === "csv") { const { list: L } = ranked(); const csv = ["rank,score,deal,price,currency,fair_price,vs_fair_pct,sqm,price_per_sqm,bedrooms,bathrooms,year_built,price_drop,city,area,read_in_full,red_flags,title,url", ...L.map((x, i) => [i + 1, x.r.score, x.f.deal || "sale", x.f.price, x.f.currency, x.r.fair ? Math.round(x.r.fair) : "", x.r.pct ?? "", x.f.sqm || "", x.r.ppsqm ? Math.round(x.r.ppsqm * 100) / 100 : "", x.f.rooms || "", x.f.baths || "", x.f.year || "", x.f.drop || "", x.f.city || "", x.f.area || "", x.f.deep ? "yes" : "", (x.r.flags || []).map((y) => y.label).join("; "), x.f.title || "", x.url].map(csvCell).join(","))].join("\n");
        const href = URL.createObjectURL(new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" })); const el = document.createElement("a"); el.href = href; el.download = `realhunt-ranking-${A.id}-${new Date().toISOString().slice(0, 10)}.csv`; el.click(); setTimeout(() => URL.revokeObjectURL(href), 4000); send({ t: "track", kind: "rank_csv", meta: { n: L.length } }); }
    });
    div.addEventListener("input", (e) => {
      const k = e.target.dataset && e.target.dataset.f; if (!k || k === "sort") return;
      rk.flt = { ...(rk.flt || {}), [k]: Number(e.target.value) || 0 }; clearTimeout(div._ft); div._ft = setTimeout(() => renderRank(true), 400);
    });
    div.addEventListener("change", (e) => { if (e.target.dataset && e.target.dataset.f === "sort") { rk.sort = e.target.value; renderRank(true); } });
    div.addEventListener("keydown", (e) => e.stopPropagation());
    sh.appendChild(div); document.documentElement.appendChild(h);
    const l = sh.querySelector(".rk-l"); if (l) l.scrollTop = scroll;
    if (focusF) { const inp = sh.querySelector(`[data-f="${focusF}"]`); if (inp) { if (typedV != null && inp.value !== typedV) inp.value = typedV; inp.focus(); try { if (caret != null) inp.setSelectionRange(caret, caret); } catch { /* number inputs */ } } }
  }

  // ---------------------------------------------------------------- run, and re-run on SPA navigation
  let lastUrl = "";
  async function run() {
    if (location.href === lastUrl) return; lastUrl = location.href;
    await getState();
    prefs = (await send({ t: "prefs" })) || {};
    send({ t: "alive", host: location.hostname });
    RHS.pageDeal = RHS.pageDealOf(document, location.href); RHS.pagePlaceV = RHS.pagePlace(document);
    await loadTaste(true);
    if (RHS.recipe === undefined) RHS.recipe = (await send({ t: "recipe", host: location.hostname.replace(/^www\./, "") })) || null;
    try { if (isDet()) { if (fab) { fab.remove(); fab = null; } await showDetail(); } else { if (card) { card.remove(); card = null; } await scanCards(); } } catch (e) { /* never break the page */ }
  }
  let t = null, started = false;
  const ours = (n) => n.nodeType !== 1 || (n.getAttribute && n.getAttribute("data-rhs"));
  function start() {
    if (started) return; started = true;
    run();
    new MutationObserver((muts) => { if (muts.every((m) => m.addedNodes.length + m.removedNodes.length > 0 && [...m.addedNodes, ...m.removedNodes].every(ours))) return; clearTimeout(t); t = setTimeout(() => { if (location.href !== lastUrl) { A._list = null; run(); } else if (!isDet()) scanCards(); }, 700); })
      .observe(document.documentElement, { childList: true, subtree: true });
  }
  // The extension loads on every site but only wakes up on pages about homes (any agency or portal, any country).
  const known = ["idealista", "zillow", "rightmove"].includes(A.id);
  const check = () => { try { return known || RHS.looksLikeProperty(document, location.href); } catch { return false; } };
  if (window.top !== window) { /* never inside frames */ }
  else if (check()) start();
  else {
    let tries = 0, href = location.href;
    const iv = setInterval(() => {
      if (started) return clearInterval(iv);
      if (location.href !== href) { href = location.href; tries = 0; } // single-page sites: check again after navigation
      if (++tries > 4 && location.href === href) { if (tries > 40) clearInterval(iv); return; }
      if (check()) { clearInterval(iv); start(); }
    }, 2500);
  }
})();
