import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import RHNav from "@/components/realhunt/RHNav";
import AuthModal from "@/components/realhunt/AuthModal";
const Onboarding = lazy(() => import("@/components/realhunt/Onboarding"));
import { Waves, Check, Heart, Search, Bell, BadgeCheck, TrendingDown, Map as MapIcon, Layers, Sparkles, ArrowRight, Mail } from "lucide-react";
import { db, eur, FLAG, norm, slug, unslug, isNew, cleanCap, IG, EBC, MAX_PRICE, track, srcSet, score, subscribeEmail } from "@/lib/rh";
import { useExperiment } from "@/lib/experiments";

const PRICE_CHIPS: [string, number][] = [["< €10k", 10000], ["< €25k", 25000], ["< €50k", 50000], ["< €100k", 100000]];
const PAGE = 40;
const FEED_KEY = "rh_feed_v2";
const FEED_COLS = "id,source_account,shortcode,image_urls,posted_at,location_name,country_guess,price_eur,is_beach,price_in_image,sqm,bedrooms,hook,rank_score,verified,status";
const VALID_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// An in-grid "leave your email, get the top 10" card. Same size/shape as a listing card so it sits
// naturally in the feed instead of looking like an ad. Uses the shared subscribeEmail() write (collection
// only, no auto-send) and reads the input straight from the DOM on submit so autofill never gets
// flagged as an invalid email (see EmailCapture.tsx for the same fix).
const CaptureCard = () => {
  const { user } = useAuth();
  const [mode, setMode] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [seen, setSeen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const head = useExperiment("capture_card_headline", [{ id: "A", text: "Get the top 10 homes. Free, by email." }]);

  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver((e) => { if (e[0].isIntersecting && !seen) { setSeen(true); track("capture_show", { meta: { kind: "grid_card" } }); } }, { threshold: 0.5 });
    io.observe(el); return () => io.disconnect();
  }, [seen]);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const el = e.currentTarget.querySelector<HTMLInputElement>("input[type=email]");
    const v = (el?.value ?? "").trim();
    if (!VALID_EMAIL.test(v)) { setMode("error"); return; }
    setMode("sending");
    await subscribeEmail(v, "grid_card", user?.id);
    setMode("done");
  };

  return (
    <div ref={ref} className="relative rounded-2xl overflow-hidden aspect-[4/5] bg-gradient-to-br from-ink via-[#232220] to-[#141414] text-white p-4 md:p-5 flex flex-col justify-between shadow-sm [content-visibility:auto]">
      <div>
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/15 text-[11px] font-medium"><Sparkles size={11} /> Free</span>
        <p className="mt-3 font-display text-[19px] md:text-[21px] leading-[1.15] tracking-tight">{head.text || "Get the top 10 homes. Free, by email."}</p>
        <p className="mt-1.5 text-[12.5px] text-white/60">Real listings under €100k, picked by hand.</p>
      </div>
      {mode === "done" ? (
        <p className="text-[13.5px] inline-flex items-start gap-2"><Check size={16} className="shrink-0 mt-0.5" /> Received. Your top 10 lands in your inbox by the end of this week.</p>
      ) : (
        <form onSubmit={submit} className="flex flex-col gap-2">
          <input type="email" inputMode="email" autoComplete="email" name="email" placeholder="you@email.com" aria-invalid={mode === "error"}
            className={`w-full rounded-full px-3.5 py-2.5 text-[13.5px] text-ink bg-white outline-none border ${mode === "error" ? "border-red-400 ring-2 ring-red-400/30" : "border-transparent focus:ring-2 focus:ring-white/40"}`} />
          <button type="submit" disabled={mode === "sending"} className="rh-btn-primary !py-2.5 !text-[13px] inline-flex items-center justify-center gap-1.5 disabled:opacity-70">
            {mode === "sending" ? "Sending…" : "Send me the top 10"} {mode !== "sending" && <ArrowRight size={14} />}
          </button>
          {mode === "error" && <span className="text-[11.5px] text-red-300">That email does not look right.</span>}
        </form>
      )}
    </div>
  );
};

const Home = () => {
  const { country: cParam, account: aParam } = useParams();
  const { user } = useAuth();
  const [finds, setFinds] = useState<IG[]>([]);
  const [country, setCountry] = useState("All");
  const [beach, setBeach] = useState(false);
  const [maxP, setMaxP] = useState<number>(0);
  const [q, setQ] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [limit, setLimit] = useState(PAGE);
  const [favs, setFavs] = useState<Set<string>>(new Set());
  const [auth, setAuth] = useState(false);
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [alert, setAlert] = useState({ email: "", country: "Any", max: 50000 });
  const [alertSent, setAlertSent] = useState(false);
  const sentinel = useRef<HTMLDivElement>(null);
  const [pref, setPref] = useState<{ country?: string | null; budget?: number | null }>({});
  const [drops, setDrops] = useState<Set<string>>(new Set());
  const [loaded, setLoaded] = useState(false);
  const headline = useExperiment("home_headline", [{ id: "A", text: "Real homes under €100,000." }]);
  const ebcCta = useExperiment("ebc_hero_cta", [{ id: "A", text: "Featured" }]);

  useEffect(() => {
    // 1. Instant paint from the last feed we saw (stale-while-revalidate), then refresh from the DB.
    try { const c = JSON.parse(localStorage.getItem(FEED_KEY) || "null"); if (c && Array.isArray(c.rows) && c.rows.length && Date.now() - c.t < 7 * 86400e3) { setFinds(c.rows); setLoaded(true); } } catch {}
    db.from("ig_finds").select(FEED_COLS).neq("status", "hidden").or(`price_eur.is.null,price_eur.lte.${MAX_PRICE}`).order("rank_score", { ascending: false, nullsFirst: false }).limit(400)
      .then(({ data, error }: any) => {
        if (error && !data) { setLoaded(true); return; }
        const rows = (data || []).filter((f: IG) => f.image_urls && f.image_urls.length).map((f: IG) => ({ ...f, image_urls: [f.image_urls![0]] })).sort((a: IG, b: IG) => score(b) - score(a));
        setFinds(rows); setLoaded(true);
        try { localStorage.setItem(FEED_KEY, JSON.stringify({ t: Date.now(), rows })); } catch {}
      });
    track("home_view");
    try { const ref = new URLSearchParams(location.search).get("ref"); if (ref) localStorage.setItem("rh_ref", ref); } catch {}
    // 2. Non-critical data after first paint.
    const idle = (window as any).requestIdleCallback || ((cb: () => void) => setTimeout(cb, 1200));
    idle(() => { db.from("price_history").select("find_id,price_eur,created_at").order("created_at", { ascending: false }).limit(2000).then(({ data }: any) => { const by: Record<string, number[]> = {}; (data || []).forEach((r: any) => { (by[r.find_id] = by[r.find_id] || []).push(r.price_eur); }); setDrops(new Set(Object.entries(by).filter(([, v]) => v.length > 1 && v[0] < Math.max(...v)).map(([k]) => k))); }); });
  }, []);
  useEffect(() => {
    if (!user) { setFavs(new Set()); setPref({}); return; }
    db.from("profiles").select("interest_country,budget_max,referred_by").eq("user_id", user.id).maybeSingle().then(({ data }: any) => { if (!data) return; setPref({ country: data.interest_country, budget: data.budget_max }); try { const ref = localStorage.getItem("rh_ref"); if (ref && !data.referred_by) db.from("profiles").update({ referred_by: ref }).eq("user_id", user.id).then(() => {}); } catch {} });
    db.from("find_events").select("find_id").eq("user_id", user.id).eq("event", "favorite").then(({ data }: any) => setFavs(new Set((data || []).map((r: any) => r.find_id))));
  }, [user]);

  const allCountries = useMemo(() => { const m: Record<string, number> = { Indonesia: 1 }; finds.forEach((f) => { const c = norm(f.country_guess); m[c] = (m[c] || 0) + 1; }); return Object.entries(m).sort((a, b) => b[1] - a[1]).map(([c]) => c); }, [finds]);
  useEffect(() => { if (cParam) setCountry(unslug(cParam, allCountries)); }, [cParam, allCountries]);
  useEffect(() => {
    const t = aParam ? `Cheap homes spotted by @${aParam}` : country !== "All" ? `Cheap houses in ${country} under €100,000` : "Real homes under €100,000";
    document.title = `${t} · RealHunt`;
    const m = document.querySelector('meta[name="description"]'); if (m) m.setAttribute("content", `${t}. Real listings under €100k, ranked by how cheap they are for where they are. Beach, countryside, villages.`);
  }, [country, aParam]);

  const shown = useMemo(() => {
    const qq = q.trim().toLowerCase();
    const boost = (f: IG) => (pref.country && pref.country !== "Any" && norm(f.country_guess) === pref.country ? 1 : 0) + (pref.budget && f.price_eur && f.price_eur <= pref.budget ? 0.5 : 0);
    let l = finds.filter((f) => (country === "All" || norm(f.country_guess) === country) && (!beach || f.is_beach) && (!maxP || (f.price_eur != null && f.price_eur <= maxP)) && (!aParam || f.source_account === aParam) && (!qq || `${f.hook || ""} ${f.location_name || ""} ${f.country_guess || ""}`.toLowerCase().includes(qq)));
    const ebcOk = !aParam && (country === "All" || country === "Indonesia") && (!maxP || EBC.price_eur! <= maxP) && (!qq || "sumba indonesia beach cabin ecobeachcity".includes(qq));
    if (pref.country || pref.budget) l = [...l].sort((a, b) => boost(b) - boost(a) || score(b) - score(a));
    if (!loaded) return [];
    // Feature EBC (Mamboro, Sumba, €11,500) as a big hero card up top, and again further down as
    // traffic scrolls through the feed — high-traffic days deserve more than one shot at it.
    if (ebcOk) {
      const hero = { ...EBC, id: "ebc-hero" } as IG;
      const repeat = { ...EBC, id: "ebc-2" } as IG;
      l = l.length >= 16 ? [hero, ...l.slice(0, 16), repeat, ...l.slice(16)] : [hero, ...l, repeat];
    }
    // One "leave your email" card woven into the grid, wherever there is enough of a feed for it to feel earned.
    const capture = { id: "capture" } as unknown as IG;
    l = l.length > 7 ? [...l.slice(0, 7), capture, ...l.slice(7)] : [...l, capture];
    return l;
  }, [finds, country, beach, maxP, q, aParam, pref, loaded]);
  useEffect(() => { setLimit(PAGE); }, [country, beach, maxP, q, aParam]);
  useEffect(() => {
    const el = sentinel.current; if (!el) return;
    const io = new IntersectionObserver((e) => { if (e[0].isIntersecting) setLimit((n) => n + PAGE); }, { rootMargin: "600px" });
    io.observe(el); return () => io.disconnect();
  }, []);
  const min = useMemo(() => finds.reduce((a, f) => (f.price_eur && f.price_eur < a ? f.price_eur : a), EBC.price_eur!), [finds]);

  const toggleFav = async (e: React.MouseEvent, f: IG) => {
    e.preventDefault(); e.stopPropagation();
    if (!user) { track("fav_gate", { find: f.shortcode }); setAuth(true); return; }
    if (f.id.startsWith("ebc")) return;
    const on = favs.has(f.id); const n = new Set(favs); on ? n.delete(f.id) : n.add(f.id); setFavs(n);
    if (on) await db.from("find_events").delete().eq("user_id", user.id).eq("find_id", f.id).eq("event", "favorite");
    else { await db.from("find_events").insert({ user_id: user.id, find_id: f.id, event: "favorite" }); track("favorite", { find: f.shortcode }); }
  };
  const subscribe = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const el = e.currentTarget.querySelector<HTMLInputElement>("input[type=email]");
    const v = (el?.value ?? email).trim();
    if (!VALID_EMAIL.test(v)) return;
    setSent(true); await subscribeEmail(v, "home_bottom", user?.id);
  };
  const saveAlert = async (e: React.FormEvent) => { e.preventDefault(); if (!/.+@.+\..+/.test(alert.email)) return; setAlertSent(true); track("alert", { meta: alert }); try { await db.from("alerts").insert({ email: alert.email, country: alert.country === "Any" ? null : alert.country, max_price: alert.max, beach, user_id: user?.id || null }); } catch {} };

  const chip = (on: boolean) => `shrink-0 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border text-[13px] transition-colors ${on ? "bg-sky-500 text-white border-sky-500" : "border-hairline hover:border-ink bg-white"}`;

  return (
    <div className="min-h-screen bg-paper text-ink">
      <RHNav />

      <section className="max-w-[1240px] mx-auto px-4 md:px-6 pt-8 md:pt-12 pb-4">
        <h1 className="font-display text-[clamp(30px,5vw,54px)] leading-[1.02] tracking-tight max-w-[22ch]">{aParam ? <>Spotted by <span className="text-ink-muted">@{aParam}</span></> : country !== "All" ? <>Cheap homes in {country}.</> : <>{headline.text || "Real homes under €100,000."}</>}</h1>
        <p className="mt-3 text-[15px] md:text-[17px] text-ink-muted">{loaded ? shown.length : "…"} homes{isFinite(min) && <> · cheapest <b className="text-ink">{eur(min)}</b></>}{aParam && <> · <a href={`https://instagram.com/${aParam}`} target="_blank" rel="noreferrer" className="underline">follow them on Instagram</a></>}</p>
      </section>

      <section className="sticky top-16 z-30 bg-paper/90 backdrop-blur border-b border-hairline">
        <div className="max-w-[1240px] mx-auto px-4 md:px-6 py-3 flex gap-2 overflow-x-auto scrollbar-none items-center">
          <button onClick={() => setShowSearch((v) => !v)} aria-label="Search" className={chip(showSearch || !!q)}><Search size={14} />{q ? q : ""}</button>
          <button onClick={() => setBeach((v) => !v)} aria-pressed={beach} className={chip(beach)}><Waves size={14} /> Beach</button>
          {PRICE_CHIPS.map(([l, v]) => <button key={v} onClick={() => setMaxP(maxP === v ? 0 : v)} aria-pressed={maxP === v} className={chip(maxP === v)}>{l}</button>)}
          <Link to="/map" className={chip(false)}><MapIcon size={14} /> Map</Link>
          <Link to="/swipe" className={chip(false) + " md:hidden"}><Layers size={14} /> Swipe</Link>
          <span className="w-px bg-hairline shrink-0 self-stretch my-1" />
          {["All", ...allCountries].map((k) => (
            <Link key={k} to={k === "All" ? "/" : `/country/${slug(k)}`} onClick={() => setCountry(k)} aria-pressed={country === k} className={chip(country === k)}>{k !== "All" && <span>{FLAG[k] || "🌍"}</span>}{k}</Link>
          ))}
        </div>
        {showSearch && <div className="max-w-[1240px] mx-auto px-4 md:px-6 pb-3"><input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="castle, lake, ocean, Tuscany, land…" className="w-full md:w-96 border border-hairline rounded-full px-4 py-2.5 text-[14px] bg-white outline-none focus:border-ink" /></div>}
      </section>

      <section className="max-w-[1240px] mx-auto px-4 md:px-6 py-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
          {shown.slice(0, limit).map((f, i) => {
            if (f.id === "capture") return <CaptureCard key="capture" />;
            const c = norm(f.country_guess);
            const hero = f.id === "ebc-hero";
            const to = f.id.startsWith("ebc") ? "/ecobeachcity" : `/find/${f.shortcode}`;
            const u = f.image_urls![0];
            return (
              <Link key={f.id} to={to} onClick={() => track("card_click", { find: f.shortcode })}
                className={`group relative block rounded-2xl overflow-hidden bg-hairline/30 shadow-sm hover:shadow-xl transition-shadow [content-visibility:auto] ${hero ? "col-span-2 aspect-[8/5]" : "aspect-[4/5]"}`}>
                <img src={u} srcSet={srcSet(u)} sizes={hero ? "(min-width:1024px) 620px, 100vw" : "(min-width:1024px) 300px, (min-width:768px) 33vw, 50vw"} alt="" loading={i < 8 ? "eager" : "lazy"} {...((i < 4 ? { fetchpriority: "high" } : {}) as any)} decoding="async" className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]" />
                <div className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent ${hero ? "h-1/2" : "h-1/3"}`} />
                {hero && <span className="absolute top-3 left-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500 text-white text-[12px] md:text-[13px] font-semibold shadow"><Sparkles size={13} /> {ebcCta.text || "Featured"}</span>}
                <span className={`absolute top-2.5 right-2.5 px-2 py-1 rounded-full bg-white/90 text-ink font-medium shadow ${hero ? "text-[13px]" : "text-[11px]"}`}>{FLAG[c] || "🌍"} {c}</span>
                <div className={`absolute left-2.5 flex gap-1 flex-wrap max-w-[70%] ${hero ? "top-[52px] md:top-14" : "top-2.5"}`}>
                  {f.price_eur && <span className={`px-2 py-1 rounded-full bg-white text-ink font-semibold tabular-nums shadow ${hero ? "text-[16px] md:text-[18px]" : "text-[12px]"}`}>{eur(f.price_eur)}</span>}
                  {f.is_beach && <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full bg-sky-500/90 text-white font-medium shadow ${hero ? "text-[12px]" : "text-[11px]"}`}><Waves size={hero ? 13 : 11} /> Beach</span>}
                  {isNew(f.posted_at) && <span className="px-2 py-1 rounded-full bg-emerald-500/90 text-white text-[11px] font-medium shadow">New</span>}
                  {drops.has(f.id) && <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-amber-500/90 text-white text-[11px] font-medium shadow"><TrendingDown size={11} /> Price drop</span>}
                  {(f as any).verified && <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-ink/90 text-white text-[11px] font-medium shadow"><BadgeCheck size={11} /> Verified</span>}
                  {((f as any).status === "sold" || (f as any).status === "reserved") && <span className="px-2 py-1 rounded-full bg-red-600/90 text-white text-[11px] font-medium shadow uppercase">{(f as any).status}</span>}
                </div>
                {!f.id.startsWith("ebc") && <button onClick={(e) => toggleFav(e, f)} aria-label="Save" className={`absolute bottom-3 right-3 h-9 w-9 rounded-full bg-white/90 shadow inline-flex items-center justify-center ${favs.has(f.id) ? "text-red-500" : "text-ink"}`}><Heart size={16} fill={favs.has(f.id) ? "currentColor" : "none"} /></button>}
                <div className={`absolute inset-x-0 bottom-0 text-white ${hero ? "p-4 md:p-5 pr-16 md:max-w-[70%]" : "p-3 md:p-4 pr-14"}`}>
                  <p className={`opacity-95 leading-snug ${hero ? "text-[15px] md:text-[19px] line-clamp-2 font-medium" : "text-[12px] md:text-[13px] line-clamp-2"}`}>{f.hook || f.location_name || (f.caption ? cleanCap(f.caption).slice(0, 48) : "") || c}</p>
                </div>
              </Link>
            );
          })}
        </div>
        {!loaded && <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">{[...Array(8)].map((_, i) => <div key={i} className="aspect-[4/5] rounded-2xl bg-hairline/50 animate-pulse" />)}</div>}
        {loaded && shown.length === 0 && <p className="text-ink-muted py-10 text-center">Nothing matches. Try another filter.</p>}
        <div ref={sentinel} className="h-2" />
      </section>

      <section className="max-w-[1240px] mx-auto px-4 md:px-6 pb-6 grid md:grid-cols-2 gap-4">
        <div className="border border-hairline rounded-2xl bg-white p-6 md:p-8 flex flex-col gap-3">
          <p className="font-display text-[22px] tracking-tight inline-flex items-center gap-2"><Bell size={18} /> Tell me when a home like this appears</p>
          {alertSent ? <p className="inline-flex items-center gap-2 text-[15px]"><Check size={18} /> Alert on. We only email when there is a match.</p> : (
            <form onSubmit={saveAlert} className="flex flex-col gap-2">
              <div className="flex gap-2">
                <select value={alert.country} onChange={(e) => setAlert({ ...alert, country: e.target.value })} className="flex-1 border border-hairline rounded-full px-4 py-3 text-[14px] bg-paper">{["Any", ...allCountries].map((c) => <option key={c}>{c}</option>)}</select>
                <select value={alert.max} onChange={(e) => setAlert({ ...alert, max: Number(e.target.value) })} className="flex-1 border border-hairline rounded-full px-4 py-3 text-[14px] bg-paper">{PRICE_CHIPS.map(([l, v]) => <option key={v} value={v}>{l}</option>)}</select>
              </div>
              <div className="flex gap-2"><input required type="email" value={alert.email} onChange={(e) => setAlert({ ...alert, email: e.target.value })} placeholder="you@email.com" className="flex-1 border border-hairline rounded-full px-4 py-3 text-[15px] bg-paper outline-none focus:border-ink" /><button className="rh-btn-primary !px-5">Alert me</button></div>
            </form>
          )}
        </div>
        <div className="border border-hairline rounded-2xl bg-white p-6 md:p-8 flex flex-col gap-3">
          <p className="font-display text-[22px] tracking-tight inline-flex items-center gap-2"><Mail size={18} /> Get the best deals we find, in your inbox.</p>
          <p className="text-[14px] text-ink-muted -mt-2">Free. Only homes under €100k worth talking about.</p>
          {sent ? <p className="inline-flex items-center gap-2 text-[15px]"><Check size={18} /> Received. Your top 10 lands in your inbox by the end of this week.</p> : (
            <form onSubmit={subscribe} className="flex gap-2"><input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" aria-label="Email" className="flex-1 border border-hairline rounded-full px-4 py-3 text-[15px] bg-paper outline-none focus:border-ink" /><button type="submit" className="rh-btn-primary !px-5">Send</button></form>
          )}
        </div>
      </section>

      <section className="max-w-[1240px] mx-auto px-4 md:px-6 pb-10 text-[13px] text-ink-muted flex flex-wrap gap-x-4 gap-y-1">
        <span>Browse by country:</span>{allCountries.map((c) => <Link key={c} to={`/country/${slug(c)}`} className="underline hover:text-ink">{c}</Link>)}
      </section>

      <footer className="border-t border-hairline"><div className="max-w-[1240px] mx-auto px-4 md:px-6 py-8 flex flex-wrap gap-x-8 gap-y-3 text-[13px] text-ink-muted"><Link to="/sell" className="hover:text-ink">Sell your home here</Link><Link to="/map" className="hover:text-ink">Map</Link><Link to="/network" className="hover:text-ink">For developers</Link><Link to="/fit" className="hover:text-ink">Can I afford it?</Link><Link to="/score" className="hover:text-ink">Score a listing</Link><Link to="/method" className="hover:text-ink">Method</Link><Link to="/legal/terms" className="hover:text-ink">Terms</Link><Link to="/legal/privacy" className="hover:text-ink">Privacy</Link><Link to="/legal/cookies" className="hover:text-ink">Cookies</Link><Link to="/legal/takedown" className="hover:text-ink">Content removal</Link><span className="ml-auto">© Equinox Investment Group LLC. Listings belong to their original posters. We link, we do not sell.</span></div></footer>
      {user && <Suspense fallback={null}><Onboarding /></Suspense>}
      <AuthModal open={auth} onClose={() => setAuth(false)} title="Save this home" subtitle="Free. Sign in and we email you everything about the homes you save." />
    </div>
  );
};
export default Home;
